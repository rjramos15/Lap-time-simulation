classdef MSFEUP_LapTool < handle
%MSFEUP_LAPTOOL  Programmatic MATLAB UI for the MSFEUP lap simulator.
%
% Launch with:
%   launch_MSFEUP
%
% This is intentionally written as ordinary MATLAB code instead of a binary
% .mlapp file, so the interface can be version-controlled and modified.

    properties
        Project
        LastOutput

        UIFigure
        HeaderLogo
        StatusArea
        ProgressGauge
        ProgressPanel
        ProgressFill
        ProgressLabel
        ProgressValue = 0
        ProgressMessage = 'idle'
        RunButton
        StopButton
        ModeDropDown
        PresetDropDown
        ResultsTable
        ResultsAxes
        ResultPlotDropDown
        ResultsInfoArea
        ExportButton
        TrackLimitModeDropDown
        HeaderGrid
        MainGrid
        BodyGrid
        FooterGrid
        MainTabs
        InputsPageGrid
        AdvancedPanel

        FileFields
        VehicleFields
        OperatingFields
        TrackFields
        OptimFields
        StopRequested = false
        PauseRequested = false
        IsRunning = false
        StatusPanel
        StatusToggleButton
        ShowAdvancedCheckBox
        StudyControls
        LastProgressPct = -Inf
        LastProgressMessage = ''
    end

    properties (Constant)
        Green = [0 154 0] / 255
        Dark = [8 10 12] / 255
        Soft = [12 13 14] / 255
        Card = [18 20 22] / 255
        Card2 = [25 27 30] / 255
        Text = [240 240 240] / 255
        Muted = [195 200 205] / 255
        Font = 'Segoe UI'
        BaseFontSize = 14
        LabelFontSize = 14
        DefaultRadiusThreshold = 2000
        DefaultKappaThreshold = 1/2000
        TitleFontSize = 19
        UiMaxMapPoints = 1400
        UiMaxLinePoints = 2500
        UiMaxScatterPoints = 6000
        % Relative column-width weights for tables that must stay responsive.
        % uitable is not governed by uigridlayout column rules, so Results
        % keeps explicit resize handling. The Study setup no longer uses a
        % uitable; it is built from native controls inside the scrollable
        % Inputs page.
        ResultsTableColumnWeights = [0.45 0.55]
        ResultsTableColumnMinWidths = [130 130]
    end

    methods
        function app = MSFEUP_LapTool()
            app.Project = msfeup_default_project();
            app.buildUI();
            app.refreshUI();
            % Reveal only now: window is already maximized, all grids were
            % recalculated against their real final size, and every field
            % has its value. This removes the startup race (seen only under
            % MATLAB Runtime / non-100% display scaling) where the window
            % was shown mid-layout, with panels and fields still sized for
            % the small pre-maximize canvas.
            app.UIFigure.Visible = 'on';
            app.log('MSFEUP Lap Simulation Tool ready.');
        end

        function buildUI(app)
            % Do NOT size the window from get(0,'ScreenSize') pixel math.
            % Physical vs. logical pixel mismatches under Windows display
            % scaling != 100% (and under MATLAB Runtime, which does not
            % always report scaling the same way the MATLAB Desktop does)
            % made this app open clipped/oversized depending on the
            % deployment machine's scaling setting. A small fixed neutral
            % size + WindowState='maximized' is immune to that mismatch,
            % because the OS/window manager (not our arithmetic) decides
            % the final usable area.
            safeW = 1000;
            safeH = 650;
            % Create UIFigure.
            % Do not attach SizeChangedFcn in the constructor. MATLAB warns
            % that SizeChangedFcn will not execute while AutoResizeChildren
            % is still on. The callback is attached only after
            % AutoResizeChildren is switched off below.
            %
            % Accessibility policy:
            % Windows Accessibility > Text size above 100% can make MATLAB
            % force UIFigure.Scrollable='on'. The app must not fight that OS
            % accessibility decision. Instead it creates the top-level figure
            % as scrollable-compatible and keeps the internal canvas sized by
            % onAppResized(). This makes startup robust whether MATLAB keeps
            % Scrollable='off' or forces it to 'on'.
            try
                app.UIFigure = uifigure('Name','MSFEUP Lap Simulation Tool', ...
                    'Position',[80 80 safeW safeH], ...
                    'Color',app.Dark, ...
                    'Scrollable','on', ...
                    'Visible','off');
            catch ME
                % Older MATLAB releases may not accept Scrollable in the
                % constructor. Fall back to a plain uifigure and apply the
                % property after creation when possible.
                if contains(lower(ME.message),'scrollable')
                    app.UIFigure = uifigure('Name','MSFEUP Lap Simulation Tool', ...
                        'Position',[80 80 safeW safeH], ...
                        'Color',app.Dark, ...
                        'Visible','off');
                else
                    rethrow(ME)
                end
            end

            % Ensure SizeChangedFcn runs even when MATLAB's auto-resize behavior differs.
            try
                app.UIFigure.AutoResizeChildren = 'off';
            catch
                % Older releases may not expose this property; ignore silently.
            end

            % Keep the top-level figure compatible with OS accessibility scaling.
            % This is intentional: when text-size accessibility is active,
            % scrollability is safer than clipped controls.
            try
                app.UIFigure.Scrollable = 'on';
            catch
                % Some MATLAB/runtime combinations won't allow changing it; ignore.
            end

            app.UIFigure.SizeChangedFcn = @(~,~) app.onAppResized();

            main = uigridlayout(app.UIFigure,[3 1]);
            app.MainGrid = main;
            main.RowHeight = {78,'1x',42};
            main.Padding = [0 0 0 0];
            main.RowSpacing = 0;

            app.buildHeader(main);
            app.buildBody(main);
            app.buildFooter(main);
            drawnow;

            maximized = false;
            try
                app.UIFigure.WindowState = 'maximized';
                drawnow;
                maximized = true;
            catch
                % Older MATLAB releases may not expose WindowState on uifigure.
            end
            if ~maximized
                % Fallback only: kept purely for releases without
                % WindowState support. Clamp to the logical screen size so
                % we never request a window bigger than what is reported
                % available, then center it.
                scr = get(0,'ScreenSize');
                margin = 60;
                w = min(1280, max(640, scr(3) - margin));
                h = min(740, max(500, scr(4) - margin));
                x = max(20, (scr(3)-w)/2);
                y = max(20, (scr(4)-h)/2);
                app.UIFigure.Position = [x y w h];
                drawnow;
            end
            app.onAppResized();
            app.forceDarkTheme();
        end

        function onAppResized(app)
            % Accessibility/runtime-safe layout sizing.
            %
            % MATLAB may force UIFigure.Scrollable='on' when the Windows
            % Accessibility text-size setting is greater than 100%. The app
            % must remain usable in both cases:
            %   - normal windows: the canvas fills the visible figure;
            %   - accessibility/small windows: the canvas keeps a safe
            %     minimum size and the top-level figure can scroll.
            try
                pos = app.UIFigure.Position;
                visibleW = max(1,pos(3));
                visibleH = max(1,pos(4));

                minCanvasW = 1000;
                minCanvasH = 660;
                layoutW = max(visibleW, minCanvasW);
                layoutH = max(visibleH, minCanvasH);

                if ~isempty(app.MainGrid) && isvalid(app.MainGrid)
                    app.MainGrid.Position = [1 1 layoutW layoutH];
                end

                if ~isempty(app.HeaderGrid) && isvalid(app.HeaderGrid)
                    if layoutW < 1100
                        app.HeaderGrid.ColumnWidth = {215,'1x',142};
                        app.HeaderGrid.Padding = [10 4 10 4];
                        app.HeaderGrid.ColumnSpacing = 8;
                    else
                        app.HeaderGrid.ColumnWidth = {280,'1x',158};
                        app.HeaderGrid.Padding = [14 5 14 5];
                        app.HeaderGrid.ColumnSpacing = 12;
                    end
                end

                if ~isempty(app.BodyGrid) && isvalid(app.BodyGrid)
                    statusVisible = false;
                    try
                        statusVisible = ~isempty(app.StatusPanel) && isvalid(app.StatusPanel) && strcmp(app.StatusPanel.Visible,'on');
                    catch
                    end
                    if statusVisible
                        if layoutW < 1040
                            app.BodyGrid.ColumnWidth = {'1x',210};
                            app.BodyGrid.Padding = [4 4 4 4];
                            app.BodyGrid.ColumnSpacing = 5;
                        elseif layoutW < 1180
                            app.BodyGrid.ColumnWidth = {'1x',235};
                            app.BodyGrid.Padding = [6 6 6 6];
                            app.BodyGrid.ColumnSpacing = 6;
                        else
                            app.BodyGrid.ColumnWidth = {'1x',275};
                            app.BodyGrid.Padding = [10 10 10 8];
                            app.BodyGrid.ColumnSpacing = 10;
                        end
                    else
                        app.BodyGrid.ColumnWidth = {'1x',0};
                        app.BodyGrid.Padding = [10 10 10 8];
                        app.BodyGrid.ColumnSpacing = 0;
                    end
                end

                if ~isempty(app.FooterGrid) && isvalid(app.FooterGrid)
                    if layoutW < 1040
                        app.FooterGrid.ColumnWidth = {'1x',150,170};
                    elseif layoutW < 1180
                        app.FooterGrid.ColumnWidth = {'1x',190,180};
                    else
                        app.FooterGrid.ColumnWidth = {'1x',290,220};
                    end
                end
            catch
            end
            % uitable does not participate in uigridlayout column rules, so
            % unlike every grid above it never shrinks/grows with the window
            % or with WindowState='maximized'. Without this, its native
            % 'auto' column sizing locks in widths that can exceed the
            % available pane. Re-apply on every resize so it always matches
            % the actual available width of its rendered container.
            drawnow limitrate;
            app.resizeInputsPage();
            app.applyAutoColumnWidths(app.ResultsTable, app.ResultsTableColumnWeights, app.ResultsTableColumnMinWidths);
        end

        function resizeInputsPage(app)
            % Native scrolling for the Inputs page.
            %
            % The Inputs page uses one scrollable uigridlayout as the only
            % scrolling container. Do not add an intermediate scrollable
            % wrapper containers or manual Position-based canvas offsets:
            % those approaches conflict with MATLAB Runtime,
            % Windows accessibility scaling and nested UI components.
            try
                if isempty(app.InputsPageGrid) || ~isvalid(app.InputsPageGrid)
                    return
                end

                try
                    app.InputsPageGrid.Scrollable = 'on';
                catch
                    % Older MATLAB releases may not expose Scrollable on
                    % uigridlayout. The app still builds, but native scroll
                    % support depends on the MATLAB release.
                end

                showAdvanced = ~isempty(app.AdvancedPanel) && isvalid(app.AdvancedPanel) && strcmp(app.AdvancedPanel.Visible,'on');
                studyHeight = app.computeStudySectionHeight();
                if showAdvanced
                    app.InputsPageGrid.RowHeight = {390,240,190,160,230,studyHeight};
                else
                    app.InputsPageGrid.RowHeight = {390,240,190,160,0,studyHeight};
                end
                drawnow limitrate
            catch ME
                try
                    app.log(['Inputs layout warning: ' ME.message]);
                catch
                end
            end
        end

        function h = computeStudySectionHeight(app)
            % Dynamic height for the Study setup block. The parameters are split
            % evenly over two columns where possible: left receives ceil(N/2),
            % right receives floor(N/2). The height follows the taller column so
            % controls cannot be clipped when the number of variables changes.
            try
                nVars = numel(app.availableStudyParameterIds());
                rows = max(1, ceil(nVars / max(1, 1 + double(nVars > 1))));
                rowH = 38;
                headerH = 24;
                rowSpacing = 7;
                buttonH = 46;
                mainSpacing = 10;
                mainPadding = 28;
                panelTitleAllowance = 34;
                tableH = headerH + rows*rowH + max(rows-1,0)*rowSpacing;
                h = max(470, tableH + buttonH + mainSpacing + mainPadding + panelTitleAllowance);
            catch
                h = 500;
            end
        end

        function scrollInputsToTop(app)
            % Best-effort reset to the top of the native scrollable Inputs grid.
            try
                if ~isempty(app.InputsPageGrid) && isvalid(app.InputsPageGrid)
                    scroll(app.InputsPageGrid,'top');
                end
            catch
            end
        end

        function applyAutoColumnWidths(app, tbl, weights, minWidths)
            % Responsive uitable columns.
            %
            % MATLAB uitable does not automatically redistribute columns to
            % fill its parent. Fixed ColumnWidth values therefore create the
            % exact Study Setup issue seen in practice: truncated columns on
            % the left and unused white space on the right.
            %
            % This method measures the rendered table/parent width, applies
            % safe minimums, then distributes the remaining width according
            % to weights. It is deliberately independent of physical model
            % logic and only affects UI presentation.
            try
                if isempty(tbl) || ~isvalid(tbl)
                    return
                end
                n = numel(weights);
                if n == 0
                    return
                end
                if nargin < 4 || isempty(minWidths) || numel(minWidths) ~= n
                    minWidths = repmat(45, 1, n);
                end

                candidates = [];

                try
                    p = tbl.Position;
                    if numel(p) >= 3 && isfinite(p(3)) && p(3) > 50
                        candidates(end+1) = p(3); %#ok<AGROW>
                    end
                catch
                end

                try
                    p = getpixelposition(tbl, true);
                    if numel(p) >= 3 && isfinite(p(3)) && p(3) > 50
                        candidates(end+1) = p(3); %#ok<AGROW>
                    end
                catch
                end

                try
                    parent = tbl.Parent;
                    p = getpixelposition(parent, true);
                    parentW = p(3);
                    if isprop(parent, 'Padding')
                        pad = parent.Padding;
                        if numel(pad) == 4
                            parentW = parentW - pad(1) - pad(3);
                        end
                    end
                    if isfinite(parentW) && parentW > 50
                        candidates(end+1) = parentW; %#ok<AGROW>
                    end
                catch
                end

                if isempty(candidates)
                    return
                end

                % Use the largest credible width. In uigridlayout-managed
                % tables, tbl.Position can be stale during startup/resize,
                % while the parent pixel width is usually already correct.
                availableW = max(candidates);

                rowHeaderAllowance = 42;
                scrollbarAllowance = 26;
                targetW = floor(availableW - rowHeaderAllowance - scrollbarAllowance);
                minWidths = max(1, round(minWidths(:)'));
                minTotal = sum(minWidths);

                if targetW <= minTotal
                    colW = minWidths;
                else
                    weights = max(0, weights(:)');
                    if sum(weights) <= 0
                        weights = ones(1,n) / n;
                    else
                        weights = weights / sum(weights);
                    end

                    extra = targetW - minTotal;
                    colW = minWidths + floor(extra * weights);

                    % Correct rounding so the columns use the full target
                    % width instead of leaving a visible blank area.
                    delta = targetW - sum(colW);
                    k = 1;
                    while delta > 0
                        colW(k) = colW(k) + 1;
                        delta = delta - 1;
                        k = k + 1;
                        if k > n
                            k = 1;
                        end
                    end
                end

                tbl.ColumnWidth = num2cell(colW);
            catch
                % Keep the app usable on older MATLAB releases or transient
                % render states. Failing to resize table columns must never
                % stop the simulator from opening.
            end
        end

        function buildHeader(app, parent)
            header = uipanel(parent, 'BorderType','none', 'BackgroundColor', app.Dark);
            grid = uigridlayout(header,[1 3]);
            app.HeaderGrid = grid;
            grid.ColumnWidth = {280,'1x',158};
            grid.Padding = [14 5 14 5];
            grid.ColumnSpacing = 12;
            app.setBg(grid, app.Dark);

            if isfile(app.Project.assets.logo_header)
                app.HeaderLogo = uiimage(grid, 'ImageSource', app.Project.assets.logo_header);
                app.HeaderLogo.ScaleMethod = 'fit';
            else
                uilabel(grid, 'Text','MSFEUP', 'FontName',app.Font, 'FontSize',24, ...
                    'FontWeight','bold', 'FontColor',app.Green);
            end

            titleGrid = uigridlayout(grid,[1 1]);
            titleGrid.Padding = [0 10 0 10];
            app.setBg(titleGrid, app.Dark);
            uilabel(titleGrid, 'Text','Motorcycle Lap Simulation Tool', ...
                'FontName',app.Font, 'FontSize',22, 'FontWeight','bold', ...
                'FontColor',[1 1 1]);

            helpBox = uigridlayout(grid,[3 2]);
            helpBox.RowHeight = {'1x',32,'1x'};
            helpBox.ColumnWidth = {'1x','1x'};
            helpBox.ColumnSpacing = 8;
            helpBox.Padding = [0 0 0 0];
            app.setBg(helpBox, app.Dark);
            helpBox.Layout.Column = 3;
            helpBox.Layout.Row = 1;
            app.StatusToggleButton = uibutton(helpBox, 'push', 'Text','Status', ...
                'FontName',app.Font, 'FontSize',12, 'FontWeight','bold', ...
                'BackgroundColor',app.Card2, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.toggleStatusPanel());
            app.StatusToggleButton.Layout.Row = 2;
            app.StatusToggleButton.Layout.Column = 1;
            helpBtn = uibutton(helpBox, 'push', 'Text','Help', ...
                'FontName',app.Font, 'FontSize',13, 'FontWeight','bold', ...
                'BackgroundColor',app.Green, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.openHelpWindow());
            helpBtn.Layout.Row = 2;
            helpBtn.Layout.Column = 2;
        end

        function buildBody(app, parent)
            body = uigridlayout(parent,[1 2]);
            app.BodyGrid = body;
            body.ColumnWidth = {'1x',0};
            body.Padding = [10 10 10 8];
            body.ColumnSpacing = 0;
            try
                body.BackgroundColor = app.Dark;
            catch
            end

            mainTabs = uitabgroup(body);
            app.MainTabs = mainTabs;
            app.setBg(mainTabs, app.Dark);
            app.buildProjectTab(mainTabs);
            app.buildInputsTab(mainTabs);
            app.buildResultsTab(mainTabs);
            app.buildStatusPanel(body);
        end

        function buildFooter(app, parent)
            footer = uipanel(parent, 'BorderType','none', 'BackgroundColor', app.Dark);
            grid = uigridlayout(footer,[1 3]);
            app.FooterGrid = grid;
            grid.ColumnWidth = {'1x',330,230};
            grid.Padding = [10 4 10 4];
            grid.ColumnSpacing = 10;
            app.setBg(grid, app.Dark);

            app.ProgressPanel = uipanel(grid, 'BorderType','line', ...
            'BackgroundColor',[0.10 0.10 0.10], 'ForegroundColor',app.Green, 'Tag','progressPanel');
        
            % Ensure SizeChangedFcn is respected
            try
                app.ProgressPanel.AutoResizeChildren = 'off';
            catch
                % Older releases may not expose this property
            end
            
            app.ProgressFill = uipanel(app.ProgressPanel, 'BorderType','none', ...
                'BackgroundColor',app.Green, 'Position',[1 1 1 28], 'Tag','progressFill');

            app.ProgressLabel = uilabel(app.ProgressPanel, 'Text','0% | idle', ...
                'FontName',app.Font, 'FontSize',12, 'FontWeight','bold', ...
                'FontColor',[1 1 1], ...
                'HorizontalAlignment','center', 'Position',[8 3 280 20]);
            app.ProgressPanel.SizeChangedFcn = @(~,~) app.setProgressVisual(app.ProgressValue, app.ProgressMessage);
            app.makeProgressLabelTransparent();

            uilabel(grid, 'Text','Author: Rafael Ramos  |  powered by GPT-5.5', ...
                'FontName',app.Font, 'FontSize',12, 'FontWeight','bold', ...
                'HorizontalAlignment','center', 'FontColor',[0.92 0.92 0.92]);

            buttons = uigridlayout(grid,[1 2]);
            buttons.ColumnWidth = {'1x','1x'};
            buttons.Padding = [0 0 0 0];
            buttons.ColumnSpacing = 10;
            app.setBg(buttons, app.Dark);

            app.RunButton = uibutton(buttons, 'push', 'Text','RUN', ...
                'FontName',app.Font, 'FontSize',13, 'FontWeight','bold', ...
                'BackgroundColor',app.Green, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.runSelectedMode());
            app.setTip(app.RunButton, 'run', 'Execute the selected simulation mode with the current project settings.');

            app.StopButton = uibutton(buttons, 'push', 'Text','STOP', ...
                'FontName',app.Font, 'FontSize',13, 'FontWeight','bold', ...
                'BackgroundColor',[0.86 0.18 0.18], 'FontColor',[1 1 1], ...
                'Enable','off', ...
                'ButtonPushedFcn',@(~,~) app.requestStop());
            app.setTip(app.StopButton, 'stop', 'Interrupts the current run at the next UI/progress call.');

            app.setProgressVisual(0, 'idle');
        end

        function buildProjectTab(app, tabs)
            tab = uitab(tabs, 'Title','Project');
            tab.BackgroundColor = app.Dark;
            app.enableScrollable(tab);
            grid = uigridlayout(tab,[7 3]);
            grid.RowHeight = {42,36,36,36,36,44,'1x'};
            grid.ColumnWidth = {130,'1x',74};
            grid.Padding = [14 14 14 14];
            grid.RowSpacing = 10;
            app.setBg(grid, app.Dark);

            app.addSectionTitle(grid, 'Project files and output folders', 1, [1 3]);

            app.FileFields.track = app.addFileRow(grid, 2, 'Track input MAT', 'track');
            app.FileFields.power = app.addFileRow(grid, 3, 'Power MAT', 'power');
            app.FileFields.figures = app.addFolderRow(grid, 4, 'Figures folder', 'figures');
            app.FileFields.results = app.addFolderRow(grid, 5, 'Results folder', 'results');

            actions = uigridlayout(grid,[1 4]);
            actions.Layout.Row = 6;
            actions.Layout.Column = [1 3];
            actions.ColumnWidth = {120,120,120,'1x'};
            actions.Padding = [0 0 0 0];
            app.setBg(actions, app.Dark);

            uibutton(actions,'push','Text','New default', 'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.newDefaultProject());
            uibutton(actions,'push','Text','Load project', 'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.loadProject());
            uibutton(actions,'push','Text','Save project', 'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.saveProject());
        end

        function buildInputsTab(app, tabs)
            tab = uitab(tabs, 'Title','Inputs');
            tab.BackgroundColor = app.Dark;

            outer = uigridlayout(tab,[1 1]);
            outer.RowHeight = {'1x'};
            outer.ColumnWidth = {'1x'};
            outer.Padding = [12 12 12 12];
            outer.RowSpacing = 0;
            outer.ColumnSpacing = 0;
            app.setBg(outer, app.Dark);

            app.InputsPageGrid = uigridlayout(outer,[6 1]);
            app.InputsPageGrid.Layout.Row = 1;
            app.InputsPageGrid.Layout.Column = 1;
            app.InputsPageGrid.RowHeight = {390,240,190,160,0,app.computeStudySectionHeight()};
            app.InputsPageGrid.ColumnWidth = {'1x'};
            app.InputsPageGrid.Padding = [14 14 14 14];
            app.InputsPageGrid.RowSpacing = 16;
            app.InputsPageGrid.ColumnSpacing = 0;
            app.setBg(app.InputsPageGrid, app.Dark);
            try
                app.InputsPageGrid.Scrollable = 'on';
            catch
                % Native Inputs-page scrolling requires MATLAB releases that
                % support Scrollable on uigridlayout. Do not substitute a
                % scrollable wrapper panel here; that was the source of the
                % broken Inputs-page scrolling behaviour.
            end

            app.buildVehicleSection(app.InputsPageGrid, 1);
            app.buildTrackSection(app.InputsPageGrid, 2);
            app.buildPowertrainSection(app.InputsPageGrid, 3);
            app.buildSimulationSection(app.InputsPageGrid, 4);
            app.buildAdvancedSection(app.InputsPageGrid, 5);
            app.buildStudySection(app.InputsPageGrid, 6);

            app.toggleAdvancedPanel();
            app.resizeInputsPage();
            app.scrollInputsToTop();
        end

        function panel = makeInputSection(app, parent, row, titleText)
            panel = app.makeCard(parent, titleText);
            panel.Layout.Row = row;
            panel.Layout.Column = 1;
        end

        function buildVehicleSection(app, parent, row)
            panel = app.makeInputSection(parent, row, 'Vehicle parameters');
            grid = uigridlayout(panel,[7 8]);
            grid.RowHeight = {38,38,38,38,38,38,38};
            grid.ColumnWidth = {125,260,32,90,125,260,32,'1x'};
            grid.Padding = [16 14 16 14];
            grid.RowSpacing = 10;
            grid.ColumnSpacing = 10;
            app.setBg(grid, app.Card);

            app.VehicleFields.mass    = app.addNumericRow(grid,1,1,'$m$ [kg]', 'mass'); app.addHelpButton(grid,1,3,'mass');
            app.VehicleFields.wb      = app.addNumericRow(grid,1,5,'$p$ [m]', 'wb'); app.addHelpButton(grid,1,7,'wb');
            app.VehicleFields.cgx     = app.addNumericRow(grid,2,1,'$b$ [m]', 'cgx'); app.addHelpButton(grid,2,3,'cgx');
            app.VehicleFields.cgh     = app.addNumericRow(grid,2,5,'$h$ [m]', 'cgh'); app.addHelpButton(grid,2,7,'cgh');
            app.VehicleFields.r_wheel = app.addNumericRow(grid,3,1,'$r_w$ [m]', 'r_wheel'); app.addHelpButton(grid,3,3,'r_wheel');
            app.VehicleFields.frontA  = app.addNumericRow(grid,3,5,'$A_f$ [m^2]', 'frontA'); app.addHelpButton(grid,3,7,'frontA');
            app.VehicleFields.Cd      = app.addNumericRow(grid,4,1,'$C_d$ [-]', 'Cd'); app.addHelpButton(grid,4,3,'Cd');
            app.VehicleFields.Cl      = app.addNumericRow(grid,4,5,'$C_L$ [-]', 'Cl'); app.addHelpButton(grid,4,7,'Cl');
            app.VehicleFields.mu      = app.addNumericRow(grid,5,1,'$\mu$ [-]', 'mu'); app.addHelpButton(grid,5,3,'mu');
            app.VehicleFields.fW      = app.addNumericRow(grid,5,5,'$f_W$ [-]', 'fW'); app.addHelpButton(grid,5,7,'fW');
            app.VehicleFields.eta     = app.addNumericRow(grid,6,1,'$\eta$ [-]', 'eta'); app.addHelpButton(grid,6,3,'eta');
            app.VehicleFields.maxrpm  = app.addNumericRow(grid,6,5,'$rpm_{max}$ [rpm]', 'maxrpm'); app.addHelpButton(grid,6,7,'maxrpm');
            app.VehicleFields.rho     = app.addNumericRow(grid,7,1,'$\rho$ [kg/m^3]', 'rho'); app.addHelpButton(grid,7,3,'rho');
        end

        function buildTrackSection(app, parent, row)
            panel = app.makeInputSection(parent, row, 'Track discretization and smoothing');
            grid = uigridlayout(panel,[4 8]);
            grid.RowHeight = {38,38,38,38};
            grid.ColumnWidth = {165,160,32,85,165,160,32,'1x'};
            grid.Padding = [16 14 16 14];
            grid.RowSpacing = 10;
            grid.ColumnSpacing = 10;
            app.setBg(grid, app.Card);

            app.TrackFields.ds = app.addNumericRow(grid,1,1,'$\Delta s$ [m]', 'ds'); app.addHelpButton(grid,1,3,'ds');
            app.TrackFields.smooth_len_xy = app.addNumericRow(grid,1,5,'XY smoothing [m]', 'smooth_len_xy'); app.addHelpButton(grid,1,7,'smooth_len_xy');
            app.TrackFields.curv_half_len = app.addNumericRow(grid,2,1,'Curv. half length [m]', 'curv_half_len'); app.addHelpButton(grid,2,3,'curv_half_len');
            app.TrackFields.smooth_len_k = app.addNumericRow(grid,2,5,'Curv. smoothing [m]', 'smooth_len_k'); app.addHelpButton(grid,2,7,'smooth_len_k');
            app.TrackFields.max_closure_warning_m = app.addNumericRow(grid,3,1,'Closure warning [m]', 'max_closure_warning_m'); app.addHelpButton(grid,3,3,'max_closure_warning_m');
            app.TrackFields.min_section_length = app.addNumericRow(grid,3,5,'Min section [m]', 'min_section_length'); app.addHelpButton(grid,3,7,'min_section_length');

            limitLab = uilabel(grid,'Text','Curve limit','FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            limitLab.Layout.Row = 4; limitLab.Layout.Column = 1;
            app.TrackLimitModeDropDown = uidropdown(grid, ...
                'Items',{'Radius threshold [m]','Curvature threshold [1/m]'}, ...
                'Value','Radius threshold [m]', 'FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                'ValueChangedFcn',@(~,~) app.onTrackLimitModeChanged());
            app.TrackLimitModeDropDown.Layout.Row = 4; app.TrackLimitModeDropDown.Layout.Column = 2;
            app.addHelpButton(grid,4,3,'curve_limit_mode');
            app.TrackFields.curve_limit_value = app.addNumericRow(grid,4,5,'Limit value', 'curve_limit_value'); app.addHelpButton(grid,4,7,'curve_limit_value');
            app.setTip(app.TrackLimitModeDropDown, 'curve_limit_mode', 'Curve/straight limiter type');
            app.setTip(app.TrackFields.curve_limit_value, 'curve_limit_value', 'Curve/straight limiter value');
        end

        function buildPowertrainSection(app, parent, row)
            panel = app.makeInputSection(parent, row, 'Powertrain and energy');
            grid = uigridlayout(panel,[3 8]);
            grid.RowHeight = {38,38,38};
            % Two compact input columns. The unused centre gap is intentional:
            % it keeps the block readable and prevents the third-row SF_E/energy
            % controls from being squeezed when the Status panel is open.
            grid.ColumnWidth = {130,170,32,100,130,170,32,'1x'};
            grid.Padding = [16 14 16 14];
            grid.RowSpacing = 10;
            grid.ColumnSpacing = 10;
            app.setBg(grid, app.Card);

            app.OperatingFields.gear_ratio = app.addNumericRow(grid,1,1,'$i_f$ [-]', 'gear_ratio'); app.addHelpButton(grid,1,3,'gear_ratio');
            app.OptimFields.n_laps = app.addNumericRow(grid,1,5,'$N_{laps}$ [-]', 'n_laps'); app.addHelpButton(grid,1,7,'n_laps');
            app.OptimFields.safety_coeff = app.addNumericRow(grid,2,1,'$SF_E$ [-]', 'safety_coeff'); app.addHelpButton(grid,2,3,'safety_coeff');
            app.OptimFields.usable_fraction = app.addNumericRow(grid,2,5,'Usable [-]', 'usable_fraction'); app.addHelpButton(grid,2,7,'usable_fraction');
            app.OptimFields.eta_regen = app.addNumericRow(grid,3,1,'$\eta_{regen}$ [-]', 'eta_regen'); app.addHelpButton(grid,3,3,'eta_regen');
        end

        function buildSimulationSection(app, parent, row)
            panel = app.makeInputSection(parent, row, 'Simulation setup');
            main = uigridlayout(panel,[2 1]);
            main.RowHeight = {38,38};
            main.ColumnWidth = {'1x'};
            main.Padding = [16 14 16 14];
            main.RowSpacing = 10;
            main.ColumnSpacing = 0;
            app.setBg(main, app.Card);

            top = uigridlayout(main,[1 8]);
            top.Layout.Row = 1;
            top.ColumnWidth = {75,260,32,90,260,32,40,'1x'};
            top.RowHeight = {38};
            top.Padding = [0 0 0 0];
            top.ColumnSpacing = 10;
            app.setBg(top, app.Card);

            modeLabel = uilabel(top,'Text','Mode','FontName',app.Font,'FontSize',app.LabelFontSize, ...
                'FontWeight','bold','FontColor',[1 1 1]);
            modeLabel.Layout.Row = 1; modeLabel.Layout.Column = 1;
            app.ModeDropDown = uidropdown(top, 'Items',{'Single Case','Sensitivity Analysis','Parametric / Optimization'}, ...
                'Value','Single Case', 'FontName',app.Font, 'FontSize',app.BaseFontSize);
            app.ModeDropDown.Layout.Row = 1; app.ModeDropDown.Layout.Column = 2;
            app.addHelpButton(top, 1, 3, 'mode');

            presetLabel = uilabel(top,'Text','Preset','FontName',app.Font,'FontSize',app.LabelFontSize, ...
                'FontWeight','bold','FontColor',[1 1 1]);
            presetLabel.Layout.Row = 1; presetLabel.Layout.Column = 4;
            app.PresetDropDown = uidropdown(top, 'Items',{'Fast','Balanced','Deep','Extreme','Custom'}, ...
                'Value','Balanced', 'FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                'ValueChangedFcn',@(~,~) app.applyPreset());
            app.PresetDropDown.Layout.Row = 1; app.PresetDropDown.Layout.Column = 5;
            app.addHelpButton(top, 1, 6, 'preset');

            actions = uigridlayout(main,[1 4]);
            actions.Layout.Row = 2;
            actions.ColumnWidth = {180,190,32,'1x'};
            actions.RowHeight = {38};
            actions.Padding = [0 0 0 0];
            actions.ColumnSpacing = 10;
            app.setBg(actions, app.Card);

            app.ShowAdvancedCheckBox = uicheckbox(actions, 'Text','Show advanced', ...
                'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'FontColor',[1 1 1], 'Value',false, ...
                'ValueChangedFcn',@(~,~) app.toggleAdvancedPanel());
            app.ShowAdvancedCheckBox.Layout.Row = 1; app.ShowAdvancedCheckBox.Layout.Column = 1;

            validateBtn = uibutton(actions, 'push', 'Text','Validate inputs', ...
                'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'BackgroundColor',app.Green, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.validateInputs());
            validateBtn.Layout.Row = 1; validateBtn.Layout.Column = 2;
            app.addHelpButton(actions, 1, 3, 'validation');
        end

        function buildAdvancedSection(app, parent, row)
            app.AdvancedPanel = app.makeInputSection(parent, row, 'Advanced controls');
            grid = uigridlayout(app.AdvancedPanel,[4 16]);
            % Use the same compact row height as the other input sections. The
            % previous nested 70 px rows made Advanced look visually unrelated
            % to Vehicle/Track/Powertrain and stretched controls vertically.
            grid.RowHeight = {38,38,38,38};
            grid.ColumnWidth = {125,105,32,28,125,105,32,28,125,105,32,28,125,105,32,'1x'};
            grid.Padding = [16 14 16 14];
            grid.RowSpacing = 10;
            grid.ColumnSpacing = 8;
            app.setBg(grid, app.Card);

            app.OptimFields.nIter = app.addNumericRow(grid,1,1,'$n_{iter}$ [-]', 'nIter'); app.addHelpButton(grid,1,3,'nIter');
            app.OptimFields.tol = app.addNumericRow(grid,1,5,'$\epsilon_v$ [-]', 'tol'); app.addHelpButton(grid,1,7,'tol');
            app.OptimFields.v_max_global = app.addNumericRow(grid,1,9,'$v_{max}$ [km/h]', 'v_max_global'); app.addHelpButton(grid,1,11,'v_max_global');
            app.OptimFields.rng_seed = app.addNumericRow(grid,1,13,'Seed [-]', 'rng_seed'); app.addHelpButton(grid,1,15,'rng_seed');

            app.OptimFields.grid_1d_points = app.addNumericRow(grid,2,1,'1D N', 'grid_1d_points'); app.addHelpButton(grid,2,3,'grid_1d_points');
            app.OptimFields.random_samples = app.addNumericRow(grid,2,5,'Random N', 'random_samples'); app.addHelpButton(grid,2,7,'random_samples');
            app.OptimFields.precision = app.addNumericRow(grid,2,9,'2D N', 'precision'); app.addHelpButton(grid,2,11,'precision');
            app.OptimFields.adaptive_rounds = app.addNumericRow(grid,2,13,'Adapt. rounds', 'adaptive_rounds'); app.addHelpButton(grid,2,15,'adaptive_rounds');

            app.OptimFields.adaptive_samples = app.addNumericRow(grid,3,1,'Adapt. N', 'adaptive_samples'); app.addHelpButton(grid,3,3,'adaptive_samples');
            app.OptimFields.top_starts = app.addNumericRow(grid,3,5,'Top starts', 'top_starts'); app.addHelpButton(grid,3,7,'top_starts');
            app.OptimFields.local_max_eval = app.addNumericRow(grid,3,9,'Local evals', 'local_max_eval'); app.addHelpButton(grid,3,11,'local_max_eval');
            app.OptimFields.simplex_max_eval = app.addNumericRow(grid,3,13,'Simplex evals', 'simplex_max_eval'); app.addHelpButton(grid,3,15,'simplex_max_eval');

            simplexLab = uilabel(grid,'Text','Simplex','FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            simplexLab.Layout.Row = 4; simplexLab.Layout.Column = 1;
            app.OptimFields.simplex_enabled = uidropdown(grid, ...
                'Items',{'On','Off'}, 'Value','On', 'FontName',app.Font, 'FontSize',app.BaseFontSize);
            app.OptimFields.simplex_enabled.Layout.Row = 4; app.OptimFields.simplex_enabled.Layout.Column = 2;
            app.addHelpButton(grid,4,3,'simplex_enabled');

            gridLab = uilabel(grid,'Text','2D grid','FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            gridLab.Layout.Row = 4; gridLab.Layout.Column = 5;
            app.OptimFields.use_grid_if_2d = uidropdown(grid, ...
                'Items',{'On','Off'}, 'Value','On', 'FontName',app.Font, 'FontSize',app.BaseFontSize);
            app.OptimFields.use_grid_if_2d.Layout.Row = 4; app.OptimFields.use_grid_if_2d.Layout.Column = 6;
            app.addHelpButton(grid,4,7,'use_grid_if_2d');

            app.bindSimulationCustomCallbacks();
        end

        function buildStudySection(app, parent, row)
            panel = app.makeInputSection(parent, row, 'Study parameters and bounds');
            main = uigridlayout(panel,[2 1]);
            main.RowHeight = {'1x',46};
            main.ColumnWidth = {'1x'};
            main.Padding = [16 14 16 14];
            main.RowSpacing = 10;
            app.setBg(main, app.Card);

            ids = app.availableStudyParameterIds();
            nVars = numel(ids);
            nCols = 1 + double(nVars > 1);
            nLeft = ceil(nVars/2);
            nRight = nVars - nLeft;
            rowsPerColumn = max(nLeft, nRight);
            if nCols == 2
                splitIds = {ids(1:nLeft), ids(nLeft+1:end)};
                cols = uigridlayout(main,[1 4]);
                cols.ColumnWidth = {460,80,460,'1x'};
                cols.ColumnSpacing = 0;
            else
                splitIds = {ids};
                cols = uigridlayout(main,[1 2]);
                cols.ColumnWidth = {460,'1x'};
                cols.ColumnSpacing = 0;
            end
            cols.Layout.Row = 1;
            cols.RowHeight = {'1x'};
            cols.Padding = [0 0 0 0];
            app.setBg(cols, app.Card);

            app.StudyControls = struct;
            for c = 1:nCols
                localIds = splitIds{c};
                g = uigridlayout(cols,[rowsPerColumn+1 6]);
                g.Layout.Row = 1;
                if nCols == 2
                    g.Layout.Column = 2*c - 1;
                else
                    g.Layout.Column = 1;
                end
                g.RowHeight = [{24}, repmat({38},1,rowsPerColumn)];
                g.ColumnWidth = {42,92,60,32,'1x','1x'};
                g.Padding = [0 0 0 0];
                g.RowSpacing = 7;
                g.ColumnSpacing = 8;
                app.setBg(g, app.Card);
                headers = {'Use','Symbol','Unit','','Min','Max'};
                for hIdx = 1:numel(headers)
                    h = uilabel(g, 'Text',headers{hIdx}, 'FontName',app.Font, 'FontSize',12, ...
                        'FontWeight','bold', 'FontColor',app.Muted);
                    h.Layout.Row = 1; h.Layout.Column = hIdx;
                end
                for i = 1:numel(localIds)
                    info = msfeup.study_parameter_registry(localIds{i});
                    rr = i + 1;
                    chk = uicheckbox(g, 'Text','', 'Value',false, ...
                        'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontColor',[1 1 1]);
                    chk.Layout.Row = rr; chk.Layout.Column = 1;
                    sym = uilabel(g, 'Text',app.prettyLabel(['$' info.symbol '$']), 'FontName',app.Font, 'FontSize',14, ...
                        'FontWeight','bold', 'FontColor',[1 1 1]);
                    try, sym.Interpreter = 'latex'; catch, sym.Text = app.prettySymbol(info.symbol); end
                    sym.Layout.Row = rr; sym.Layout.Column = 2;
                    unit = uilabel(g, 'Text',app.prettyUnit(info.unit), 'FontName',app.Font, 'FontSize',12, ...
                        'FontColor',app.Muted);
                    unit.Layout.Row = rr; unit.Layout.Column = 3;
                    app.addHelpButton(g, rr, 4, ['study_' info.id]);
                    minField = uieditfield(g,'numeric','FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                        'BackgroundColor',[0.96 0.97 0.98], 'FontColor',[0.03 0.05 0.07]);
                    minField.Layout.Row = rr; minField.Layout.Column = 5;
                    maxField = uieditfield(g,'numeric','FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                        'BackgroundColor',[0.96 0.97 0.98], 'FontColor',[0.03 0.05 0.07]);
                    maxField.Layout.Row = rr; maxField.Layout.Column = 6;
                    key = matlab.lang.makeValidName(info.id);
                    app.StudyControls.(key) = struct('id',info.id,'name',info.name, ...
                        'symbol',info.symbol,'unit',info.unit,'check',chk,'min',minField,'max',maxField);
                end
            end
            actions = uigridlayout(main,[1 2]);
            actions.Layout.Row = 2;
            actions.ColumnWidth = {180,'1x'};
            actions.Padding = [0 0 0 0];
            app.setBg(actions, app.Card);
            app.makeActionButton(actions, 'Enable/Disable all', @(~,~) app.toggleAllStudyParameters());
        end

        function buildResultsTab(app, tabs)
            tab = uitab(tabs, 'Title','Results');
            tab.BackgroundColor = app.Dark;
            app.enableScrollable(tab);
            grid = uigridlayout(tab,[3 2]);
            grid.RowHeight = {76,48,'1x'};
            grid.ColumnWidth = {320,'1x'};
            grid.Padding = [14 14 14 14];
            grid.RowSpacing = 12;
            grid.ColumnSpacing = 14;
            app.setBg(grid, app.Dark);

            tablePanel = app.makeCard(grid, 'Key metrics');
            tablePanel.Layout.Row = [1 3];
            tablePanel.Layout.Column = 1;
            tableGrid = uigridlayout(tablePanel,[1 1]);
            tableGrid.Padding = [10 10 10 10];
            app.setBg(tableGrid, app.Card);
            app.ResultsTable = uitable(tableGrid, 'FontName',app.Font, 'FontSize',14);
            app.ResultsTable.ColumnName = {'Metric','Value'};
            app.ResultsTable.ColumnEditable = [false false];
            try
                app.ResultsTable.BackgroundColor = [1 1 1; 0.96 0.96 0.96];
                app.ResultsTable.FontColor = [0 0 0];
            catch
            end

            actionsPanel = app.makeCard(grid, 'Output');
            actionsPanel.Layout.Row = 1;
            actionsPanel.Layout.Column = 2;
            actions = uigridlayout(actionsPanel,[1 4]);
            actions.ColumnWidth = {150,125,125,'1x'};
            actions.Padding = [12 10 12 10];
            actions.ColumnSpacing = 10;
            app.setBg(actions, app.Card);
            app.ExportButton = uibutton(actions,'push','Text','Export results','FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'BackgroundColor',app.Green,'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.exportResults());
            app.ExportButton.Layout.Column = 1;
            uibutton(actions,'push','Text','Open folder','FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.openFolder('results'));
            uibutton(actions,'push','Text','Clear view','FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.clearResults());
            app.ResultsInfoArea = uitextarea(actions, 'Editable','off', 'Visible','off', 'Value',{''});

            plotControls = uigridlayout(grid,[1 4]);
            plotControls.Layout.Row = 2;
            plotControls.Layout.Column = 2;
            plotControls.ColumnWidth = {105,280,120,'1x'};
            plotControls.Padding = [0 0 0 0];
            plotControls.ColumnSpacing = 10;
            app.setBg(plotControls, app.Dark);
            uilabel(plotControls, 'Text','Preview', 'FontName',app.Font, 'FontSize',15, ...
                'FontWeight','bold', 'FontColor',[1 1 1]);
            app.ResultPlotDropDown = uidropdown(plotControls, ...
                'Items',{'Track velocity map','Track longitudinal acceleration map','Track lateral acceleration map','Track curvature map','Track constraint regime map','RPM / power profile','Force profile','Baseline vs optimized velocity','Study samples','Parameter sensitivity'}, ...
                'Value','Track velocity map', 'FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                'ValueChangedFcn',@(~,~) app.previewSelectedResult());
            uibutton(plotControls, 'push', 'Text','Refresh', 'FontName',app.Font, 'FontSize',app.BaseFontSize, ...
                'FontWeight','bold', 'ButtonPushedFcn',@(~,~) app.previewSelectedResult());

            app.ResultsAxes = uiaxes(grid);
            app.ResultsAxes.Layout.Row = 3;
            app.ResultsAxes.Layout.Column = 2;
            title(app.ResultsAxes, 'Track preview');
            xlabel(app.ResultsAxes, 'X [m]');
            ylabel(app.ResultsAxes, 'Y [m]');
            app.ResultsAxes.FontName = 'Times';
            app.ResultsAxes.FontSize = 15;
            app.ResultsAxes.XGrid = 'on';
            app.ResultsAxes.YGrid = 'on';
            app.ResultsAxes.Color = app.Dark;
            app.ResultsAxes.XColor = [1 1 1];
            app.ResultsAxes.YColor = [1 1 1];
            app.ResultsAxes.GridColor = [0.45 0.45 0.45];
        end

        function buildStatusPanel(app, parent)
            panel = uipanel(parent, 'Title','Status / validation', ...
                'FontName',app.Font, 'FontSize',16, 'FontWeight','bold', ...
                'ForegroundColor',[1 1 1], 'BackgroundColor',app.Card, ...
                'BorderType','line');
            app.StatusPanel = panel;
            try
                panel.Layout.Row = 1;
                panel.Layout.Column = 2;
            catch
            end
            try
                panel.Visible = 'off';
            catch
            end
            grid = uigridlayout(panel,[2 1]);
            grid.RowHeight = {38,'1x'};
            grid.Padding = [8 8 8 8];
            grid.RowSpacing = 8;
            app.setBg(grid, app.Card);

            uibutton(grid,'push','Text','Validate inputs', 'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'BackgroundColor',app.Green, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.validateInputs());

            app.StatusArea = uitextarea(grid, 'Editable','off', ...
                'FontName','Consolas', 'FontSize',11, ...
                'FontColor',[0.94 0.94 0.94], 'BackgroundColor',[0.08 0.08 0.08], ...
                'Value',{''});
        end

        function label = addSectionTitle(app, grid, text, row, cols)
            label = uilabel(grid, 'Text',['  ' text], 'FontName',app.Font, 'FontSize',app.TitleFontSize, ...
                'FontWeight','bold', 'FontColor',[1 1 1], 'BackgroundColor',app.Card2);
            label.Layout.Row = row;
            label.Layout.Column = cols;
        end

        function field = addFileRow(app, grid, row, labelText, key)
            lab = uilabel(grid,'Text',labelText,'FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            lab.Layout.Row = row;
            lab.Layout.Column = 1;

            field = uieditfield(grid,'text','FontName',app.Font, ...
                'FontSize',12);
            field.Layout.Row = row;
            field.Layout.Column = 2;

            btn = uibutton(grid,'push','Text','Browse','FontName',app.Font, ...
                'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.browseFile(key));
            btn.Layout.Row = row;
            btn.Layout.Column = 3;

            app.setTip(lab, key, labelText);
            app.setTip(field, key, labelText);
            app.setTip(btn, key, labelText);
        end

        function field = addFolderRow(app, grid, row, labelText, key)
            lab = uilabel(grid,'Text',labelText,'FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            lab.Layout.Row = row;
            lab.Layout.Column = 1;

            field = uieditfield(grid,'text','FontName',app.Font, ...
                'FontSize',12);
            field.Layout.Row = row;
            field.Layout.Column = 2;

            btn = uibutton(grid,'push','Text','Select','FontName',app.Font, ...
                'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'ButtonPushedFcn',@(~,~) app.browseFolder(key));
            btn.Layout.Row = row;
            btn.Layout.Column = 3;

            app.setTip(lab, key, labelText);
            app.setTip(field, key, labelText);
            app.setTip(btn, key, labelText);
        end

        function field = addNumericRow(app, grid, row, col, labelText, key)
            labelDisplay = app.prettyLabel(labelText);
            lab = uilabel(grid,'Text',labelDisplay,'FontName',app.Font, ...
                'FontSize',app.LabelFontSize,'FontWeight','bold','FontColor',[1 1 1]);
            if contains(labelDisplay, '$')
                try
                    lab.Interpreter = 'latex';
                catch
                    lab.Text = app.prettySymbol(regexprep(labelText,'\$',''));
                end
            end
            lab.Layout.Row = row;
            lab.Layout.Column = col;

            field = uieditfield(grid,'numeric','FontName',app.Font, ...
                'FontSize',app.BaseFontSize, ...
                'BackgroundColor',[0.96 0.97 0.98], 'FontColor',[0.03 0.05 0.07]);
            field.Layout.Row = row;
            field.Layout.Column = col + 1;

            app.setTip(lab, key, labelText);
            app.setTip(field, key, labelText);
        end

        function btn = addHelpButton(app, grid, row, col, key)
            btn = uibutton(grid, 'push', 'Text','?', ...
                'FontName',app.Font, 'FontSize',12, 'FontWeight','bold', ...
                'BackgroundColor',app.Green, 'FontColor',[1 1 1], ...
                'ButtonPushedFcn',@(~,~) app.showHelpPopup(key));
            btn.Layout.Row = row;
            btn.Layout.Column = col;
            try
                btn.HorizontalAlignment = 'center';
            catch
            end
            app.setTip(btn, key, '?');
        end

        function tf = hasValidControl(~, s, key)
            tf = isstruct(s) && isfield(s,key) && ~isempty(s.(key));
            if tf
                try
                    tf = isvalid(s.(key));
                catch
                    tf = false;
                end
            end
        end

        function setNumericIfValid(app, s, key, value)
            try
                if app.hasValidControl(s, key)
                    s.(key).Value = value;
                end
            catch
            end
        end

        function value = getNumericIfValid(app, s, key, fallback)
            value = fallback;
            try
                if app.hasValidControl(s, key)
                    value = s.(key).Value;
                end
            catch
                value = fallback;
            end
        end

        function setDropdownIfValid(app, s, key, value)
            try
                if app.hasValidControl(s, key)
                    s.(key).Value = value;
                end
            catch
            end
        end

        function value = getDropdownIfValid(app, s, key, fallback)
            value = fallback;
            try
                if app.hasValidControl(s, key)
                    value = s.(key).Value;
                end
            catch
                value = fallback;
            end
        end

        function txt = prettyLabel(app, txt)
            txt = app.prettyUnit(txt);
            txt = char(string(txt));
            % Allow LaTeX labels where MATLAB supports uilabel.Interpreter.
            % The fallback still passes through prettySymbol/prettyUnit.
            if contains(txt, '$')
                return
            end
            txt = app.prettySymbol(txt);
        end

        function txt = prettySymbol(~, txt)
            txt = char(string(txt));
            txt = strrep(txt, '\mu', 'μ');
            txt = strrep(txt, '\eta', 'η');
            txt = strrep(txt, '\rho', 'ρ');
            txt = strrep(txt, 'x_{cg}', 'x_cg');
            txt = strrep(txt, 'y_{cg}', 'y_cg');
            txt = strrep(txt, 'RPM_{max}', 'rpm_max');
        end

        function txt = prettyUnit(~, txt)
            txt = char(string(txt));
            txt = strrep(txt, 'm^2', 'm²');
            txt = strrep(txt, 'm^3', 'm³');
        end

        function refreshUI(app)
            p = app.Project;

            p = app.ensureProjectCompatibility(p);
            app.Project = p;
            if isdeployed
                app.FileFields.track.Value = app.packagedPlaceholder('MSFEUP_track_input.mat');
                app.FileFields.power.Value = app.packagedPlaceholder('MSFEUP_power_curve.mat');
            else
                app.FileFields.track.Value = p.files.track;
                app.FileFields.power.Value = p.files.power;
            end
            app.FileFields.figures.Value = p.outputs.figures;
            app.FileFields.results.Value = p.outputs.results;

            fn = fieldnames(app.VehicleFields);
            for i = 1:numel(fn)
                app.VehicleFields.(fn{i}).Value = p.vehicle.(fn{i});
            end

            app.OperatingFields.gear_ratio.Value = p.operating.gear_ratio;

            tf = {'ds','smooth_len_xy','curv_half_len','smooth_len_k','max_closure_warning_m'};
            for i = 1:numel(tf)
                app.TrackFields.(tf{i}).Value = p.track.(tf{i});
            end
            if isfield(p.track, 'curve_limit_mode')
                app.TrackLimitModeDropDown.Value = p.track.curve_limit_mode;
            else
                app.TrackLimitModeDropDown.Value = 'Radius threshold [m]';
            end
            if strcmp(app.TrackLimitModeDropDown.Value, 'Curvature threshold [1/m]')
                app.TrackFields.curve_limit_value.Value = p.analysis.corner_kappa_threshold;
            else
                app.TrackFields.curve_limit_value.Value = p.track.straight_radius_threshold;
            end
            app.TrackFields.min_section_length.Value = p.analysis.min_section_length;
            app.updateTrackLimitTooltip();

            app.setNumericIfValid(app.OptimFields, 'v_max_global', 3.6 * p.sim.v_max_global);
            app.setNumericIfValid(app.OptimFields, 'nIter', p.sim.nIter);
            app.setNumericIfValid(app.OptimFields, 'tol', p.sim.tol);
            app.setNumericIfValid(app.OptimFields, 'n_laps', p.energy.n_laps);
            app.setNumericIfValid(app.OptimFields, 'safety_coeff', p.energy.safety_coeff);
            app.setNumericIfValid(app.OptimFields, 'usable_fraction', p.energy.usable_fraction);
            app.setNumericIfValid(app.OptimFields, 'eta_regen', p.energy.eta_regen);
            app.setNumericIfValid(app.OptimFields, 'random_samples', p.optim.random_samples);
            app.setNumericIfValid(app.OptimFields, 'grid_1d_points', p.optim.grid_1d_points);
            app.setNumericIfValid(app.OptimFields, 'top_starts', p.optim.top_starts);
            app.setNumericIfValid(app.OptimFields, 'local_max_eval', p.optim.local_max_eval);
            app.setNumericIfValid(app.OptimFields, 'adaptive_rounds', p.optim.adaptive_rounds);
            app.setNumericIfValid(app.OptimFields, 'adaptive_samples', p.optim.adaptive_samples);
            app.setNumericIfValid(app.OptimFields, 'simplex_max_eval', p.optim.simplex_max_eval);
            app.setNumericIfValid(app.OptimFields, 'rng_seed', p.optim.rng_seed);
            if isfield(p.optim, 'simplex_enabled') && ~p.optim.simplex_enabled
                app.setDropdownIfValid(app.OptimFields, 'simplex_enabled', 'Off');
            else
                app.setDropdownIfValid(app.OptimFields, 'simplex_enabled', 'On');
            end
            if isfield(p.optim, 'precision')
                app.setNumericIfValid(app.OptimFields, 'precision', p.optim.precision);
            else
                app.setNumericIfValid(app.OptimFields, 'precision', 36);
            end
            if isfield(p.optim, 'use_grid_if_2d') && ~p.optim.use_grid_if_2d
                app.setDropdownIfValid(app.OptimFields, 'use_grid_if_2d', 'Off');
            else
                app.setDropdownIfValid(app.OptimFields, 'use_grid_if_2d', 'On');
            end

            app.refreshStudyControls(p.study);
        end

        function readUI(app)
            p = app.Project;

            p = app.ensureProjectCompatibility(p);
            if ~(isdeployed && app.isPackagedPlaceholder(app.FileFields.track.Value))
                p.files.track = app.FileFields.track.Value;
            end
            if ~(isdeployed && app.isPackagedPlaceholder(app.FileFields.power.Value))
                p.files.power = app.FileFields.power.Value;
            end
            p.outputs.figures = app.FileFields.figures.Value;
            p.outputs.results = app.FileFields.results.Value;

            fn = fieldnames(app.VehicleFields);
            for i = 1:numel(fn)
                p.vehicle.(fn{i}) = app.VehicleFields.(fn{i}).Value;
            end

            p.operating.gear_ratio = app.OperatingFields.gear_ratio.Value;

            p.track.ds = app.TrackFields.ds.Value;
            p.track.smooth_len_xy = app.TrackFields.smooth_len_xy.Value;
            p.track.curv_half_len = app.TrackFields.curv_half_len.Value;
            p.track.smooth_len_k = app.TrackFields.smooth_len_k.Value;
            p.track.max_closure_warning_m = app.TrackFields.max_closure_warning_m.Value;
            p.track.curve_limit_mode = app.TrackLimitModeDropDown.Value;
            p.track.curve_limit_value = app.TrackFields.curve_limit_value.Value;
            [p.track.straight_radius_threshold, p.analysis.corner_kappa_threshold] = app.resolveTrackLimit(p.track.curve_limit_mode, p.track.curve_limit_value);
            p.analysis.min_section_length = app.TrackFields.min_section_length.Value;
            p.vehicle.g = 9.81;

            p.sim.v_max_global = max(eps, app.getNumericIfValid(app.OptimFields, 'v_max_global', 3.6*p.sim.v_max_global) / 3.6);
            p.sim.nIter = max(1, round(app.getNumericIfValid(app.OptimFields, 'nIter', p.sim.nIter)));
            p.sim.tol = max(eps, app.getNumericIfValid(app.OptimFields, 'tol', p.sim.tol));
            p.energy.n_laps = max(1, round(app.getNumericIfValid(app.OptimFields, 'n_laps', p.energy.n_laps)));
            p.energy.safety_coeff = max(eps, app.getNumericIfValid(app.OptimFields, 'safety_coeff', p.energy.safety_coeff));
            p.energy.usable_fraction = min(max(app.getNumericIfValid(app.OptimFields, 'usable_fraction', p.energy.usable_fraction), eps), 1);
            p.energy.eta_regen = min(max(app.getNumericIfValid(app.OptimFields, 'eta_regen', p.energy.eta_regen), 0), 1);
            p.optim.random_samples = max(1, round(app.getNumericIfValid(app.OptimFields, 'random_samples', p.optim.random_samples)));
            p.optim.grid_1d_points = max(2, round(app.getNumericIfValid(app.OptimFields, 'grid_1d_points', p.optim.grid_1d_points)));
            p.optim.top_starts = max(1, round(app.getNumericIfValid(app.OptimFields, 'top_starts', p.optim.top_starts)));
            p.optim.local_max_eval = max(1, round(app.getNumericIfValid(app.OptimFields, 'local_max_eval', p.optim.local_max_eval)));
            p.optim.adaptive_rounds = max(0, round(app.getNumericIfValid(app.OptimFields, 'adaptive_rounds', p.optim.adaptive_rounds)));
            p.optim.adaptive_samples = max(0, round(app.getNumericIfValid(app.OptimFields, 'adaptive_samples', p.optim.adaptive_samples)));
            p.optim.simplex_max_eval = max(1, round(app.getNumericIfValid(app.OptimFields, 'simplex_max_eval', p.optim.simplex_max_eval)));
            p.optim.rng_seed = round(app.getNumericIfValid(app.OptimFields, 'rng_seed', p.optim.rng_seed));
            p.optim.simplex_enabled = strcmp(app.getDropdownIfValid(app.OptimFields, 'simplex_enabled', app.onOffString(p.optim.simplex_enabled)), 'On');
            p.optim.precision = max(2, round(app.getNumericIfValid(app.OptimFields, 'precision', p.optim.precision)));
            p.optim.use_grid_if_2d = strcmp(app.getDropdownIfValid(app.OptimFields, 'use_grid_if_2d', app.onOffString(p.optim.use_grid_if_2d)), 'On');
            p.optim.checkpoint_enabled = false;
            p.sensitivity.points_per_variable = p.optim.grid_1d_points;
            p.sensitivity.include_bounds = true;

            p.study = app.studyControlsToStudy();

            app.Project = p;
        end

        function ids = availableStudyParameterIds(~)
            ids = {'gear_ratio','mass','mu','Cd','Cl','cgx','cgh', ...
                   'eta','frontA','r_wheel','wb','maxrpm','rho','fW'};
        end

        function refreshStudyControls(app, study)
            if isempty(app.StudyControls) || ~isstruct(app.StudyControls)
                return
            end
            ids = app.availableStudyParameterIds();
            enabledDefault = {'gear_ratio','mass'};
            for i = 1:numel(ids)
                id = ids{i};
                key = matlab.lang.makeValidName(id);
                if ~isfield(app.StudyControls, key)
                    continue
                end
                ctrl = app.StudyControls.(key);
                info = msfeup.study_parameter_registry(id);
                idx = [];
                for j = 1:numel(study)
                    if strcmp(char(string(study(j).id)), id)
                        idx = j;
                        break
                    end
                end
                if isempty(idx)
                    defaults = msfeup_default_project();
                    for j = 1:numel(defaults.study)
                        if strcmp(char(string(defaults.study(j).id)), id)
                            idxDefault = j;
                            break
                        end
                    end
                    if exist('idxDefault','var')
                        range = defaults.study(idxDefault).range;
                        clear idxDefault
                    else
                        base = 0;
                        try
                            base = msfeup.get_study_parameter_value(app.Project, id);
                        catch
                        end
                        range = [0.9*base 1.1*base];
                    end
                    enabled = any(strcmp(id, enabledDefault));
                else
                    range = study(idx).range;
                    if numel(study) < numel(ids)
                        enabled = true;
                    else
                        enabled = any(strcmp(id, enabledDefault));
                    end
                end
                try
                    ctrl.check.Value = enabled;
                    ctrl.min.Value = range(1);
                    ctrl.max.Value = range(2);
                catch
                end
            end
        end

        function study = studyControlsToStudy(app)
            study = msfeup_empty_study();
            if isempty(app.StudyControls) || ~isstruct(app.StudyControls)
                return
            end
            ids = app.availableStudyParameterIds();
            count = 0;
            for i = 1:numel(ids)
                id = ids{i};
                key = matlab.lang.makeValidName(id);
                if ~isfield(app.StudyControls, key)
                    continue
                end
                ctrl = app.StudyControls.(key);
                try
                    enabled = logical(ctrl.check.Value);
                    mn = double(ctrl.min.Value);
                    mx = double(ctrl.max.Value);
                catch
                    continue
                end
                if ~enabled
                    continue
                end
                info = msfeup.study_parameter_registry(id);
                if ~info.known
                    continue
                end
                count = count + 1;
                study(count) = msfeup_make_study(info.id, info.name, info.symbol, info.unit, [mn mx]); %#ok<AGROW>
            end
        end

        function toggleAllStudyParameters(app)
            if isempty(app.StudyControls) || ~isstruct(app.StudyControls)
                return
            end
            ids = app.availableStudyParameterIds();
            allOn = true;
            for i = 1:numel(ids)
                key = matlab.lang.makeValidName(ids{i});
                if isfield(app.StudyControls, key)
                    try
                        allOn = allOn && logical(app.StudyControls.(key).check.Value);
                    catch
                        allOn = false;
                    end
                end
            end
            newVal = ~allOn;
            for i = 1:numel(ids)
                key = matlab.lang.makeValidName(ids{i});
                if isfield(app.StudyControls, key)
                    try
                        app.StudyControls.(key).check.Value = newVal;
                    catch
                    end
                end
            end
            if newVal
                app.log('All study parameters enabled.');
            else
                app.log('All study parameters disabled.');
            end
        end

        function p = ensureProjectCompatibility(app, p)
            if ~isfield(p, 'root') || isempty(p.root)
                p.root = fileparts(mfilename('fullpath'));
            end
            if ~isfield(p, 'files') || isempty(p.files)
                p.files = struct;
            end
            if ~isfield(p.files, 'track') || isempty(p.files.track)
                p.files.track = fullfile(p.root, 'MSFEUP_track_input.mat');
            end
            if ~isfield(p.files, 'data') || isempty(p.files.data)
                p.files.data = fullfile(p.root, 'data.mat');
            end
            if ~isfield(p.files, 'theta') || isempty(p.files.theta)
                p.files.theta = fullfile(p.root, 'Theta.mat');
            end
            if ~isfield(p.files, 'radius') || isempty(p.files.radius)
                p.files.radius = fullfile(p.root, 'radius.mat');
            end
            if ~isfield(p.files, 'power') || isempty(p.files.power)
                p.files.power = fullfile(p.root, 'MSFEUP_power_curve.mat');
            end
            defaults = msfeup_default_project();
            if ~isfield(p, 'sim') || isempty(p.sim)
                p.sim = defaults.sim;
            else
                p.sim = app.fillMissingStructFields(p.sim, defaults.sim);
            end
            if ~isfield(p, 'optim') || isempty(p.optim)
                p.optim = defaults.optim;
            else
                p.optim = app.fillMissingStructFields(p.optim, defaults.optim);
            end
            if ~isfield(p, 'sensitivity') || isempty(p.sensitivity)
                p.sensitivity = defaults.sensitivity;
            else
                p.sensitivity = app.fillMissingStructFields(p.sensitivity, defaults.sensitivity);
            end
            if ~isfield(p, 'outputs') || isempty(p.outputs)
                p.outputs = defaults.outputs;
            else
                p.outputs = app.fillMissingStructFields(p.outputs, defaults.outputs);
            end
        end

        function s = fillMissingStructFields(~, s, defaults)
            names = fieldnames(defaults);
            for i = 1:numel(names)
                f = names{i};
                if ~isfield(s, f) || isempty(s.(f))
                    s.(f) = defaults.(f);
                end
            end
        end

        function txt = packagedPlaceholder(~, fileName)
            txt = ['Packaged default: ' char(string(fileName))];
        end

        function tf = isPackagedPlaceholder(~, value)
            tf = startsWith(char(string(value)), 'Packaged default:');
        end

        function validateInputs(app)
            app.readUI();
            app.log('Validating inputs...');
            report = msfeup.validate_project_inputs(app.Project);
            for i = 1:numel(report.messages)
                if report.ok
                    app.log(['OK   ' char(report.messages(i))]);
                else
                    app.log(['MISS ' char(report.messages(i))]);
                end
            end

            p = app.Project;
            p = app.ensureProjectCompatibility(p);
            if isfile(p.files.track)
                app.log(sprintf('OK   track   %s', p.files.track));
            elseif isfile(p.files.data) && isfile(p.files.theta) && isfile(p.files.radius)
                app.log(sprintf('BUILD track   %s from legacy files on first run', p.files.track));
            end
            if isfile(p.files.power)
                app.log(sprintf('OK   power   %s', p.files.power));
            end

            try
                [radiusThr, kappaThr] = app.resolveTrackLimit(p.track.curve_limit_mode, p.track.curve_limit_value);
                app.log(sprintf('Curve limiter: radius %.3f m | kappa %.6g 1/m.', radiusThr, kappaThr));
            catch ME
                app.log(['Track limiter check failed: ' ME.message]);
            end
        end

        function ok = inputsAreValid(app)
            app.readUI();
            report = msfeup.validate_project_inputs(app.Project);
            ok = report.ok;
            if ~ok
                for i = 1:numel(report.messages)
                    app.log(['MISS ' char(report.messages(i))]);
                end
            end
        end

        function runSelectedMode(app)
            app.readUI();
            if ~app.inputsAreValid()
                app.log('RUN blocked until required inputs are valid. Use Validate inputs for details.');
                return
            end

            modeLabel = string(app.ModeDropDown.Value);
            if modeLabel == "Single Case"
                mode = 'single';
            elseif modeLabel == "Sensitivity Analysis"
                mode = 'sensitivity';
            else
                mode = 'optimize';
            end

            app.clearLog();
            app.StopRequested = false;
            app.PauseRequested = false;
            app.IsRunning = true;
            app.LastProgressPct = -Inf;
            app.LastProgressMessage = '';
            if ~isempty(app.RunButton) && isvalid(app.RunButton)
                app.RunButton.Text = 'PAUSE';
                app.RunButton.Enable = 'on';
                app.RunButton.ButtonPushedFcn = @(~,~) app.togglePause();
                app.RunButton.BackgroundColor = app.Card2;
            end
            if ~isempty(app.StopButton) && isvalid(app.StopButton)
                app.StopButton.Enable = 'on';
            end
            cleanup = onCleanup(@() app.finishRunControls());
            app.setProgressVisual(0, 'starting');
            app.log(sprintf('Running mode: %s', mode));

            try
                progressFcn = @(v,msg) app.updateProgress(v,msg);
                app.LastOutput = msfeup_run_project(app.Project, mode, progressFcn);
                app.populateResults();
                if app.isSensitivityOutput(app.LastOutput)
                    if ~isempty(app.ResultPlotDropDown) && isvalid(app.ResultPlotDropDown)
                        app.ResultPlotDropDown.Value = 'Study samples';
                    end
                    app.previewSelectedResult();
                else
                    app.previewTrackVelocity();
                end
                app.logRunSummary();
                app.log('Run completed successfully.');
            catch ME
                if strcmp(ME.identifier, 'MSFEUP:UserStop')
                    app.setProgressVisual(app.ProgressValue, 'stopped by user');
                    app.log('Run stopped by user.');
                    return
                end
                app.log(['ERROR: ' ME.message]);
                rethrow(ME)
            end
        end

        function finishRunControls(app)
            app.IsRunning = false;
            app.PauseRequested = false;
            if ~isempty(app.RunButton) && isvalid(app.RunButton)
                app.RunButton.Text = 'RUN';
                app.RunButton.Enable = 'on';
                app.RunButton.BackgroundColor = app.Green;
                app.RunButton.ButtonPushedFcn = @(~,~) app.runSelectedMode();
            end
            if ~isempty(app.StopButton) && isvalid(app.StopButton)
                app.StopButton.Enable = 'off';
            end
        end

        function requestStop(app)
            app.StopRequested = true;
            app.PauseRequested = false;
            app.setProgressVisual(app.ProgressValue, 'stopping');
            app.log('Stop requested. The run will be interrupted immediately at the next UI/progress call.');
            drawnow
        end

        function togglePause(app)
            if ~app.IsRunning
                app.runSelectedMode();
                return
            end
            app.PauseRequested = ~app.PauseRequested;
            if app.PauseRequested
                app.RunButton.Text = 'RESUME';
                app.setProgressVisual(app.ProgressValue, 'paused');
                app.log('Run paused. Press RESUME to continue.');
            else
                app.RunButton.Text = 'PAUSE';
                app.setProgressVisual(app.ProgressValue, 'running');
                app.log('Run resumed.');
            end
            drawnow
        end

        function waitIfPaused(app)
            while app.PauseRequested && ~app.StopRequested
                pause(0.05);
                drawnow
            end
            if app.StopRequested
                error('MSFEUP:UserStop', 'Run stopped by user.');
            end
        end

        function updateProgress(app, value, message)
            app.waitIfPaused();
            if ~isfinite(value)
                drawnow
                if app.StopRequested
                    error('MSFEUP:UserStop', 'Run stopped by user.');
                end
                return
            end

            pct = max(0, min(100, 100*value));
            app.setProgressVisual(pct, message);
            drawnow
            app.waitIfPaused();
            if app.StopRequested
                error('MSFEUP:UserStop', 'Run stopped by user.');
            end

            msg = char(string(message));
            shouldLog = pct <= 0 || pct >= 100 || ...
                abs(pct - app.LastProgressPct) >= 4;
            if shouldLog
                app.log(msg);
                app.LastProgressPct = pct;
                app.LastProgressMessage = msg;
            end
        end

        function populateResults(app)
            if isempty(app.LastOutput) || ~isfield(app.LastOutput, 'summary')
                return
            end
            rows = app.summaryRows(app.LastOutput);
            app.ResultsTable.Data = rows;
        end

        function rows = summaryRows(app, output)
            s = output.summary;
            best = output.best;
            if app.isSensitivityOutput(output)
                rows = {
                    'Baseline/current lap time [s]', sprintf('%.6f', best.lap_time);
                    'Track length [m]', sprintf('%.3f', s.track_length_m);
                    'Mean speed [km/h]', sprintf('%.3f', s.mean_speed_kph);
                    'Max speed [km/h]', sprintf('%.3f', s.max_speed_kph);
                    'Min speed [km/h]', sprintf('%.3f', s.min_speed_kph);
                    'Max ax [g]', sprintf('%.4f', s.max_ax_g);
                    'Min ax [g]', sprintf('%.4f', s.min_ax_g);
                    'Max |ay| [g]', sprintf('%.4f', s.max_abs_ay_g);
                    'Energy/lap [kWh]', sprintf('%.6f', s.energy_per_lap_kWh)};

                [bestSweepJ, bestSweepX] = app.bestSampledPoint(output);
                if isfinite(bestSweepJ)
                    rows = [{'Best sweep sample [s]', sprintf('%.6f', bestSweepJ)}; rows]; %#ok<AGROW>
                    if isfield(output, 'sim') && isfield(output.sim, 'study') && ~isempty(output.sim.study) && ~isempty(bestSweepX)
                        for i = 1:min(numel(output.sim.study), numel(bestSweepX))
                            st = output.sim.study(i);
                            rows = [rows; {sprintf('Best sweep %s [%s]', char(string(st.id)), char(string(st.unit))), sprintf('%.12g', bestSweepX(i))}]; %#ok<AGROW>
                        end
                    end
                end

                if ~isempty(best.x) && isfield(output, 'sim') && isfield(output.sim, 'study') && ~isempty(output.sim.study)
                    for i = 1:min(numel(output.sim.study), numel(best.x))
                        st = output.sim.study(i);
                        rows = [rows; {sprintf('Baseline %s [%s]', char(string(st.id)), char(string(st.unit))), sprintf('%.12g', best.x(i))}]; %#ok<AGROW>
                    end
                end
                diagRows = app.diagnosticRows(output);
                if ~isempty(diagRows)
                    rows = [rows(1,:); diagRows; rows(2:end,:)]; %#ok<AGROW>
                end
                return
            end

            rows = {
                'Final optimum lap time [s]', sprintf('%.6f', best.lap_time);
                'Summary lap time [s]', sprintf('%.6f', s.lap_time_s);
                'Track length [m]', sprintf('%.3f', s.track_length_m);
                'Mean speed [km/h]', sprintf('%.3f', s.mean_speed_kph);
                'Max speed [km/h]', sprintf('%.3f', s.max_speed_kph);
                'Min speed [km/h]', sprintf('%.3f', s.min_speed_kph);
                'Max ax [g]', sprintf('%.4f', s.max_ax_g);
                'Min ax [g]', sprintf('%.4f', s.min_ax_g);
                'Max |ay| [g]', sprintf('%.4f', s.max_abs_ay_g);
                'Energy/lap [kWh]', sprintf('%.6f', s.energy_per_lap_kWh);
                'Total energy [kWh]', sprintf('%.6f', s.total_energy_kWh);
                'Battery capacity [kWh]', sprintf('%.6f', s.battery_capacity_kWh);
                'Peak wheel power [kW]', sprintf('%.3f', s.peak_power_kW);
                'Average wheel power [kW]', sprintf('%.3f', s.average_power_kW)};
            if isfield(output, 'sim') && isfield(output.sim, 'study') && ~isempty(output.sim.study) && ~isempty(best.x)
                for i = 1:min(numel(output.sim.study), numel(best.x))
                    st = output.sim.study(i);
                    rows = [rows; {sprintf('Best %s [%s]', char(string(st.id)), char(string(st.unit))), sprintf('%.12g', best.x(i))}]; %#ok<AGROW>
                end
            end
            if isfield(s, 'baseline_lap_time_s')
                rows = [rows; {
                    'Baseline lap time [s]', sprintf('%.6f', s.baseline_lap_time_s);
                    'Delta vs baseline [s]', sprintf('%.6f', s.delta_vs_baseline_s);
                    'Improvement vs baseline [%]', sprintf('%.4f', s.improvement_vs_baseline_pct)}];
            end
            diagRows = app.diagnosticRows(output);
            if ~isempty(diagRows)
                rows = [rows(1,:); diagRows; rows(2:end,:)]; %#ok<AGROW>
            end
        end

        function rows = diagnosticRows(app, output)
            rows = cell(0,2);
            if ~isfield(output, 'opt') || ~isfield(output.opt, 'diagnostics')
                return
            end

            d = output.opt.diagnostics;
            warningsCount = 0;
            if isfield(d, 'warnings')
                warningsCount = numel(d.warnings);
            end

            if app.isSensitivityOutput(output)
                rows = [rows; {'Sensitivity warnings', sprintf('%d', warningsCount)}]; %#ok<AGROW>
                return
            end

            boundaryCount = 0;
            if isfield(d, 'boundary')
                boundaryCount = numel(d.boundary);
            end

            confidence = "Medium";
            if boundaryCount > 0 || warningsCount > 0
                confidence = "Needs review";
            end
            if isfield(d, 'multistart') && isfield(d.multistart, 'confidence')
                msConfidence = string(d.multistart.confidence);
                if msConfidence == "high" && boundaryCount == 0 && warningsCount == 0
                    confidence = "High";
                elseif msConfidence == "low"
                    confidence = "Low";
                end
            end

            rows = [rows; {'Optimization confidence', char(confidence)}]; %#ok<AGROW>
            rows = [rows; {'Boundary flags', sprintf('%d', boundaryCount)}]; %#ok<AGROW>
            rows = [rows; {'Diagnostic warnings', sprintf('%d', warningsCount)}]; %#ok<AGROW>

            if isfield(d, 'improvement') && isfield(d.improvement, 'delta_s') && isfinite(d.improvement.delta_s)
                if d.improvement.delta_s < 0
                    status = 'Slower than baseline';
                elseif d.improvement.delta_s < 0.05 || d.improvement.improvement_pct < 0.10
                    status = 'Marginal';
                else
                    status = 'Conclusive';
                end
                rows = [rows; {'Improvement status', status}]; %#ok<AGROW>
            end

            if isfield(d, 'multistart') && isfield(d.multistart, 'available') && d.multistart.available
                rows = [rows; {'Multi-start agreement', ...
                    sprintf('%d/%d within %.4g s', d.multistart.n_converged, d.multistart.n_starts, d.multistart.epsilon_s)}]; %#ok<AGROW>
                rows = [rows; {'Refined spread [s]', sprintf('std %.4g | range %.4g', ...
                    d.multistart.refined_std_s, d.multistart.refined_range_s)}]; %#ok<AGROW>
            end
        end

        function tf = isSensitivityOutput(~, output)
            tf = isfield(output, 'mode') && any(strcmpi(char(string(output.mode)), {'sensitivity','sensitivity_analysis'}));
        end

        function [bestJ, bestX, bestPhase] = bestSampledPoint(~, output)
            bestJ = NaN;
            bestX = [];
            bestPhase = "";
            if ~isfield(output, 'opt') || ~isfield(output.opt, 'samples_J') || isempty(output.opt.samples_J) || ...
                    ~isfield(output.opt, 'samples_x') || isempty(output.opt.samples_x)
                return
            end
            J = output.opt.samples_J(:);
            X = output.opt.samples_x;
            valid = isfinite(J) & all(isfinite(X), 2);
            if ~any(valid)
                return
            end
            Jv = J(valid);
            Xv = X(valid,:);
            phasev = strings(size(Jv));
            if isfield(output.opt, 'samples_phase') && numel(output.opt.samples_phase) == numel(J)
                rawPhase = string(output.opt.samples_phase(:));
                phasev = rawPhase(valid);
            end
            [bestJ, idx] = min(Jv);
            bestX = Xv(idx,:);
            bestPhase = phasev(idx);
        end

        function resetResultsAxes(app)
            ax = app.ResultsAxes;
            if isempty(ax) || ~isvalid(ax)
                return
            end

            app.deleteResultsDecorations();

            % yyaxis leaves persistent secondary-axis labels if it is not
            % explicitly cleared. Clear both sides before drawing the next
            % view, otherwise one telemetry view can contaminate the next.
            try
                yyaxis(ax, 'right');
                cla(ax);
                ylabel(ax, '');
            catch
            end
            try
                yyaxis(ax, 'left');
            catch
            end
            try
                cla(ax, 'reset');
            catch
                cla(ax);
            end

            hold(ax, 'off');
            app.applyResultsAxesBaseStyle();
            try
                ax.XLimMode = 'auto';
                ax.YLimMode = 'auto';
                ax.ZLimMode = 'auto';
                ax.CLimMode = 'auto';
                view(ax, 2);
            catch
            end
            try
                if numel(ax.YAxis) > 1
                    ax.YAxis(2).Visible = 'off';
                    ax.YAxis(2).Color = [1 1 1];
                end
                ax.YAxis(1).Visible = 'on';
                ax.YAxis(1).Color = [1 1 1];
            catch
            end
            title(ax, '', 'Color',[1 1 1], 'Interpreter','none');
            xlabel(ax, '', 'Color',[1 1 1], 'Interpreter','none');
            ylabel(ax, '', 'Color',[1 1 1], 'Interpreter','none');
        end

        function deleteResultsDecorations(app)
            try
                objs = findall(app.UIFigure);
                for kk = 1:numel(objs)
                    cname = class(objs(kk));
                    if contains(cname, 'ColorBar') || contains(cname, 'Legend')
                        try, delete(objs(kk)); catch, end
                    end
                end
            catch
            end
        end

        function applyResultsAxesBaseStyle(app)
            ax = app.ResultsAxes;
            ax.FontName = 'Times';
            ax.FontSize = 15;
            ax.Color = app.Dark;
            ax.XColor = [1 1 1];
            ax.YColor = [1 1 1];
            ax.GridColor = [0.45 0.45 0.45];
            ax.XGrid = 'on';
            ax.YGrid = 'on';
            ax.Box = 'on';
        end

        function idx = uiPlotIndex(~, n, maxPts)
            n = double(n);
            maxPts = double(maxPts);
            if n <= 0
                idx = [];
            elseif n <= maxPts
                idx = (1:n).';
            else
                idx = unique(round(linspace(1, n, maxPts))).';
            end
        end

        function [lo, hi] = paddedLimits(~, values, padFrac, minPad)
            values = values(:);
            values = values(isfinite(values));
            if isempty(values)
                lo = 0;
                hi = 1;
                return
            end
            lo = min(values);
            hi = max(values);
            if lo == hi
                pad = max([abs(lo)*padFrac, minPad, 1e-9]);
            else
                pad = max((hi - lo) * padFrac, minPad);
            end
            lo = lo - pad;
            hi = hi + pad;
        end

        function applyProfileLimits(app, x, varargin)
            x = x(:);
            x = x(isfinite(x));
            if isempty(x)
                return
            end
            allY = [];
            for kk = 1:numel(varargin)
                y = varargin{kk};
                allY = [allY; y(:)]; %#ok<AGROW>
            end
            [xmin, xmax] = app.paddedLimits(x, 0.015, 0.05);
            [ymin, ymax] = app.paddedLimits(allY, 0.08, 0.05);
            xlim(app.ResultsAxes, [xmin xmax]);
            ylim(app.ResultsAxes, [ymin ymax]);
        end

        function applyTrackMapLimits(app, track)
            x = track.x(:);
            y = track.y(:);
            valid = isfinite(x) & isfinite(y);
            x = x(valid);
            y = y(valid);
            if isempty(x) || isempty(y)
                return
            end
            dx = max(x) - min(x);
            dy = max(y) - min(y);
            span = max([dx dy 1]);
            pad = 0.06 * span;
            xlim(app.ResultsAxes, [min(x)-pad max(x)+pad]);
            ylim(app.ResultsAxes, [min(y)-pad max(y)+pad]);
            daspect(app.ResultsAxes, [1 1 1]);
        end

        function applyScalarCLim(app, values)
            values = values(:);
            values = values(isfinite(values));
            if isempty(values)
                return
            end
            cmin = min(values);
            cmax = max(values);
            if cmin == cmax
                pad = max(abs(cmin)*0.05, 1e-9);
                cmin = cmin - pad;
                cmax = cmax + pad;
            end
            clim(app.ResultsAxes, [cmin cmax]);
        end

        function txt = parameterAxisLabel(~, st)
            symbol = '';
            unit = '';
            if isfield(st, 'symbol'); symbol = char(string(st.symbol)); end
            if isfield(st, 'unit'); unit = char(string(st.unit)); end
            if isempty(unit)
                txt = symbol;
            else
                txt = sprintf('%s [%s]', symbol, unit);
            end
        end

        function previewTrackVelocity(app)
            app.previewResult('Track velocity map');
        end

        function previewSelectedResult(app)
            if isempty(app.ResultPlotDropDown) || ~isvalid(app.ResultPlotDropDown)
                app.previewResult('Track velocity map');
            else
                app.previewResult(app.ResultPlotDropDown.Value);
            end
        end

        function previewResult(app, viewName)
            if isempty(app.LastOutput) || ~isfield(app.LastOutput, 'track') || ~isfield(app.LastOutput, 'best')
                return
            end

            viewName = char(string(viewName));
            switch viewName
                case {'Track velocity map','Track longitudinal acceleration map','Track lateral acceleration map','Track curvature map','Track constraint regime map'}
                    app.previewTrackScalar(viewName);
                case 'RPM / power profile'
                    app.previewRpmPowerProfile();
                case 'Force profile'
                    app.previewForceProfile();
                case 'Baseline vs optimized velocity'
                    app.previewBaselineComparison();
                case {'Study samples','Optimization samples'}
                    app.previewOptimizationSamples();
                case 'Parameter sensitivity'
                    app.previewParameterSensitivity();
                otherwise
                    app.previewTrackScalar('Track velocity map');
            end
        end

        function previewTrackScalar(app, scalarName)
            track = app.LastOutput.track;
            r = app.LastOutput.best.result;
            scalarName = char(string(scalarName));

            switch scalarName
                case 'Track velocity map'
                    values = r.v * 3.6;
                    label = 'Velocity [km/h]';
                    ttl = 'Track velocity map';
                case 'Track longitudinal acceleration map'
                    values = r.ax_g;
                    label = 'Longitudinal acceleration ax [g]';
                    ttl = 'Track longitudinal acceleration map';
                case 'Track lateral acceleration map'
                    values = abs(r.ay_g);
                    label = 'Lateral acceleration |ay| [g]';
                    ttl = 'Track lateral acceleration map';
                case 'Track curvature map'
                    values = abs(track.kappa);
                    label = 'Curvature |kappa| [1/m]';
                    ttl = 'Track curvature map';
                case 'Track constraint regime map'
                    values = double(r.constraint_code);
                    label = 'Constraint ID [-]';
                    ttl = 'Track constraint regime map';
                otherwise
                    values = r.v * 3.6;
                    label = 'Velocity [km/h]';
                    ttl = 'Track preview';
            end

            n = min([numel(track.x), numel(track.y), numel(values)]);
            idx = app.uiPlotIndex(n, app.UiMaxMapPoints);
            x_plot = track.x(idx);
            y_plot = track.y(idx);
            v_plot = values(idx);
            if ~isempty(idx)
                x_plot = [x_plot(:); x_plot(1)];
                y_plot = [y_plot(:); y_plot(1)];
                v_plot = [v_plot(:); v_plot(1)];
            end

            app.resetResultsAxes();
            surface(app.ResultsAxes, [x_plot x_plot], [y_plot y_plot], zeros(numel(x_plot),2), [v_plot v_plot], ...
                'FaceColor','none', 'EdgeColor','interp', 'LineWidth',3);
            app.applyTrackMapLimits(track);
            if strcmp(scalarName, 'Track constraint regime map')
                colormap(app.ResultsAxes, turbo(6));
                clim(app.ResultsAxes, [1 6]);
            else
                app.applyScalarCLim(v_plot);
                colormap(app.ResultsAxes, turbo);
            end
            app.formatResultsAxes(ttl, 'X [m]', 'Y [m]');
            cb = colorbar(app.ResultsAxes);
            cb.Label.String = label;
            cb.Label.Interpreter = 'none';
            cb.Label.Color = [1 1 1];
            cb.Color = [1 1 1];
            if strcmp(scalarName, 'Track constraint regime map')
                cb.Ticks = 1:6;
                cb.TickLabels = {'Motor','Traction','Wheelie','Brake','Corner','Redline'};
            end
            app.updateResultsInfo({sprintf('Showing: %s', scalarName), ...
                sprintf('Display points: %d / %d', numel(idx), n), ...
                sprintf('Lap time: %.6f s', app.LastOutput.summary.lap_time_s)});
            drawnow limitrate nocallbacks
        end

        function previewRpmPowerProfile(app)
            track = app.LastOutput.track;
            r = app.LastOutput.best.result;
            n = min([numel(track.s), numel(r.rpm), numel(r.P_wheel)]);
            idx = app.uiPlotIndex(n, app.UiMaxLinePoints);
            s = track.s(idx);
            rpm = r.rpm(idx);
            pkw = r.P_wheel(idx) / 1000;
            rpmScale = max(abs(rpm)); if ~isfinite(rpmScale) || rpmScale <= 0; rpmScale = 1; end
            pScale = max(abs(pkw)); if ~isfinite(pScale) || pScale <= 0; pScale = 1; end
            rpmN = rpm / rpmScale;
            pN = pkw / pScale;

            app.resetResultsAxes(); hold(app.ResultsAxes,'on');
            plot(app.ResultsAxes, s, rpmN, 'LineWidth',1.6, 'Color',app.Green);
            plot(app.ResultsAxes, s, pN, 'LineWidth',1.4, 'Color',[1 1 1]);
            legend(app.ResultsAxes, {'RPM / max RPM','Wheel power / max power'}, ...
                'TextColor',[1 1 1], 'Location','northeast', 'Box','off');
            app.formatResultsAxes('RPM and wheel power profile', 's [m]', 'Normalized value [-]');
            app.applyProfileLimits(s, rpmN, pN);
            app.updateResultsInfo({'Showing: normalized RPM / power profile', ...
                sprintf('Max RPM: %.0f', rpmScale), ...
                sprintf('Max wheel power: %.3f kW', pScale)});
            drawnow limitrate nocallbacks
        end

        function previewForceProfile(app)
            track = app.LastOutput.track;
            r = app.LastOutput.best.result;
            n = min([numel(track.s), numel(r.F_drive), numel(r.F_drag), numel(r.F_rr), numel(r.F_slope)]);
            idx = app.uiPlotIndex(n, app.UiMaxLinePoints);
            s = track.s(idx);
            fd = r.F_drive(idx);
            fdrag = r.F_drag(idx);
            frr = r.F_rr(idx);
            fs = r.F_slope(idx);

            app.resetResultsAxes(); hold(app.ResultsAxes,'on');
            plot(app.ResultsAxes, s, fd, 'LineWidth',1.2, 'Color',app.Green);
            plot(app.ResultsAxes, s, fdrag, 'LineWidth',1.0, 'Color',[1 1 1]);
            plot(app.ResultsAxes, s, frr, 'LineWidth',1.0, 'Color',app.Muted);
            plot(app.ResultsAxes, s, fs, 'LineWidth',1.0, 'Color',[0.55 0.55 0.55]);
            legend(app.ResultsAxes, {'F drive','F drag','F rolling','F slope'}, ...
                'TextColor',[1 1 1], 'Location','northeast', 'Box','off');
            app.formatResultsAxes('Longitudinal force profile', 's [m]', 'Force [N]');
            app.applyProfileLimits(s, fd, fdrag, frr, fs);
            app.updateResultsInfo({'Showing: force profile', ...
                sprintf('Display points: %d / %d', numel(idx), n)});
            drawnow limitrate nocallbacks
        end

        function previewBaselineComparison(app)
            track = app.LastOutput.track;
            bestV = app.LastOutput.best.result.v * 3.6;
            n = min([numel(track.s), numel(bestV)]);
            idx = app.uiPlotIndex(n, app.UiMaxLinePoints);
            s = track.s(idx);
            bestPlot = bestV(idx);

            app.resetResultsAxes(); hold(app.ResultsAxes,'on');
            if app.isSensitivityOutput(app.LastOutput)
                plot(app.ResultsAxes, s, bestPlot, 'LineWidth',1.8, 'Color',app.Green);
                app.applyProfileLimits(s, bestPlot);
                app.updateResultsInfo({'Sensitivity mode has no optimized velocity profile.', ...
                    sprintf('Showing baseline/current: %.6f s', app.LastOutput.best.lap_time)});
                app.formatResultsAxes('Baseline/current velocity', 's [m]', 'Velocity [km/h]');
                drawnow limitrate nocallbacks
                return
            end
            if isfield(app.LastOutput.sim, 'baseline') && isfield(app.LastOutput.sim.baseline, 'result')
                baseV = app.LastOutput.sim.baseline.result.v * 3.6;
                nBase = min([numel(track.s), numel(bestV), numel(baseV)]);
                idxBase = app.uiPlotIndex(nBase, app.UiMaxLinePoints);
                sBase = track.s(idxBase);
                basePlot = baseV(idxBase);
                bestBase = bestV(idxBase);
                plot(app.ResultsAxes, sBase, basePlot, '--', 'LineWidth',1.2, 'Color',app.Muted);
                plot(app.ResultsAxes, sBase, bestBase, 'LineWidth',1.8, 'Color',app.Green);
                legend(app.ResultsAxes, {'Baseline','Optimized'}, 'TextColor',[1 1 1], 'Location','northeast', 'Box','off');
                app.applyProfileLimits(sBase, basePlot, bestBase);
                app.updateResultsInfo({'Showing: baseline vs optimized velocity', ...
                    sprintf('Baseline: %.6f s', app.LastOutput.summary.baseline_lap_time_s), ...
                    sprintf('Optimized: %.6f s', app.LastOutput.summary.lap_time_s)});
            else
                plot(app.ResultsAxes, s, bestPlot, 'LineWidth',1.8, 'Color',app.Green);
                app.applyProfileLimits(s, bestPlot);
                app.updateResultsInfo({'Baseline unavailable for Single Case.', 'Showing current velocity only.'});
            end
            app.formatResultsAxes('Baseline vs optimized velocity', 's [m]', 'Velocity [km/h]');
            drawnow limitrate nocallbacks
        end

        function previewOptimizationSamples(app)
            opt = app.LastOutput.opt;
            isSensitivity = app.isSensitivityOutput(app.LastOutput);
            if isSensitivity
                viewTitle = 'Sensitivity sweep samples';
                emptyText = 'No sensitivity samples available';
                sampleLabel = 'Sweep samples';
                markerLabel = 'Baseline/current';
                finalLineLabel = 'Baseline/current lap time';
            else
                viewTitle = 'Optimization samples';
                emptyText = 'No optimization samples available';
                sampleLabel = 'Samples';
                markerLabel = 'Final optimum';
                finalLineLabel = 'Final optimum lap time';
            end
            app.resetResultsAxes(); hold(app.ResultsAxes,'on');
            if ~isfield(opt, 'samples_J') || isempty(opt.samples_J)
                text(app.ResultsAxes, 0.5, 0.5, emptyText, 'Color',[1 1 1], 'HorizontalAlignment','center');
                app.formatResultsAxes(viewTitle, 'Sample [-]', 'Lap time [s]');
                xlim(app.ResultsAxes, [0 1]); ylim(app.ResultsAxes, [0 1]);
                return
            end
            J = opt.samples_J(:);
            X = opt.samples_x;
            valid = isfinite(J) & all(isfinite(X),2);
            J = J(valid);
            X = X(valid,:);
            if isempty(J)
                text(app.ResultsAxes, 0.5, 0.5, 'No valid samples', 'Color',[1 1 1], 'HorizontalAlignment','center');
                app.formatResultsAxes(viewTitle, 'Sample [-]', 'Lap time [s]');
                xlim(app.ResultsAxes, [0 1]); ylim(app.ResultsAxes, [0 1]);
                return
            end

            sel = app.uiPlotIndex(numel(J), app.UiMaxScatterPoints);
            Jp = J(sel);
            Xp = X(sel,:);
            D = opt.dimension;
            [bestSweepJ, bestSweepX] = app.bestSampledPoint(app.LastOutput);
            if D == 1
                xlab = app.parameterAxisLabel(app.LastOutput.sim.study(1));
                scatter(app.ResultsAxes, Xp(:,1), Jp, 24, app.Green, 'filled');
                legendItems = {sampleLabel};
                limitX = Xp(:,1);
                limitY = Jp;
                if isSensitivity && isfinite(bestSweepJ) && numel(bestSweepX) >= 1
                    scatter(app.ResultsAxes, bestSweepX(1), bestSweepJ, ...
                        95, [1.0 0.82 0.20], 'd', 'filled', 'MarkerEdgeColor',[1 1 1], 'LineWidth',1.1);
                    legendItems{end+1} = 'Best sweep sample'; %#ok<AGROW>
                    limitX = [limitX; bestSweepX(1)];
                    limitY = [limitY; bestSweepJ];
                end
                if isfield(app.LastOutput, 'best') && numel(app.LastOutput.best.x) >= 1
                    scatter(app.ResultsAxes, app.LastOutput.best.x(1), app.LastOutput.best.lap_time, ...
                        90, [1 1 1], 'p', 'filled', 'MarkerEdgeColor', app.Green, 'LineWidth',1.3);
                    legendItems{end+1} = markerLabel; %#ok<AGROW>
                    limitX = [limitX; app.LastOutput.best.x(1)];
                    limitY = [limitY; app.LastOutput.best.lap_time];
                    legend(app.ResultsAxes, legendItems, 'TextColor',[1 1 1], 'Location','best', 'Box','off');
                end
                app.formatResultsAxes(viewTitle, xlab, 'Lap time [s]');
                app.applyProfileLimits(limitX, limitY);
            elseif D == 2
                xlab = app.parameterAxisLabel(app.LastOutput.sim.study(1));
                ylab = app.parameterAxisLabel(app.LastOutput.sim.study(2));
                scatter(app.ResultsAxes, Xp(:,1), Xp(:,2), 26, Jp, 'filled');
                legendItems = {sampleLabel};
                limitX = Xp(:,1);
                limitY = Xp(:,2);
                if isSensitivity && isfinite(bestSweepJ) && numel(bestSweepX) >= 2
                    scatter(app.ResultsAxes, bestSweepX(1), bestSweepX(2), ...
                        105, [1.0 0.82 0.20], 'd', 'filled', 'MarkerEdgeColor',[1 1 1], 'LineWidth',1.1);
                    legendItems{end+1} = 'Best sweep sample'; %#ok<AGROW>
                    limitX = [limitX; bestSweepX(1)];
                    limitY = [limitY; bestSweepX(2)];
                end
                if isfield(app.LastOutput, 'best') && numel(app.LastOutput.best.x) >= 2
                    scatter(app.ResultsAxes, app.LastOutput.best.x(1), app.LastOutput.best.x(2), ...
                        120, [1 1 1], 'p', 'filled', 'MarkerEdgeColor', app.Green, 'LineWidth',1.4);
                    legendItems{end+1} = markerLabel; %#ok<AGROW>
                    limitX = [limitX; app.LastOutput.best.x(1)];
                    limitY = [limitY; app.LastOutput.best.x(2)];
                    legend(app.ResultsAxes, legendItems, 'TextColor',[1 1 1], 'Location','best', 'Box','off');
                end
                cb = colorbar(app.ResultsAxes); cb.Label.String = 'Lap time [s]'; cb.Label.Color = [1 1 1]; cb.Color = [1 1 1];
                colormap(app.ResultsAxes, turbo);
                app.applyScalarCLim(Jp);
                app.formatResultsAxes(viewTitle, xlab, ylab);
                app.applyProfileLimits(limitX, limitY);
            else
                [~, idxBest] = sort(J, 'ascend');
                nShow = min(numel(idxBest), 80);
                idxBest = idxBest(1:nShow);
                denom = opt.ub - opt.lb;
                denom(abs(denom) <= eps) = 1;
                Z = (X(idxBest,:) - opt.lb) ./ denom;
                Z = min(max(Z,0),1);
                Jshow = J(idxBest);
                cmap = turbo(256);
                cmin = min(Jshow); cmax = max(Jshow) + eps;
                for k = nShow:-1:1
                    row = 1 + round(255*(Jshow(k)-cmin)/(cmax-cmin));
                    plot(app.ResultsAxes, 1:D, Z(k,:), 'Color', cmap(row,:), 'LineWidth',0.7);
                end
                app.ResultsAxes.XTick = 1:D;
                app.ResultsAxes.XTickLabel = {app.LastOutput.sim.study.symbol};
                app.ResultsAxes.XTickLabelRotation = 20;
                cb = colorbar(app.ResultsAxes); cb.Label.String = 'Lap time [s]'; cb.Label.Color = [1 1 1]; cb.Color = [1 1 1];
                colormap(app.ResultsAxes, turbo);
                clim(app.ResultsAxes, [cmin cmax]);
                app.formatResultsAxes(viewTitle, 'Study parameter', 'Normalized value [-]');
                xlim(app.ResultsAxes, [0.8 D+0.2]); ylim(app.ResultsAxes, [-0.05 1.05]);
            end
            infoLines = {sprintf('Showing: %s', lower(viewTitle)), ...
                sprintf('Display samples: %d / %d', numel(sel), numel(J)), ...
                sprintf('Best sampled lap time: %.6f s', min(J))};
            if isSensitivity
                infoLines{end+1} = sprintf('Baseline/current lap time: %.6f s', app.LastOutput.best.lap_time); %#ok<AGROW>
                infoLines{end+1} = 'Sensitivity does not choose an optimum; use Optimization mode to optimize.'; %#ok<AGROW>
            else
                infoLines{end+1} = sprintf('%s: %.6f s', finalLineLabel, app.LastOutput.best.lap_time); %#ok<AGROW>
            end
            app.updateResultsInfo(infoLines);
            drawnow limitrate nocallbacks
        end

        function previewParameterSensitivity(app)
            opt = app.LastOutput.opt;
            app.resetResultsAxes(); hold(app.ResultsAxes,'on');
            if ~isfield(opt, 'samples_J') || isempty(opt.samples_J)
                text(app.ResultsAxes, 0.5, 0.5, 'No sensitivity available for Single Case', 'Color',[1 1 1], 'HorizontalAlignment','center');
                app.formatResultsAxes('Parameter sensitivity', '|corr(parameter, lap time)| [-]', 'Study parameter');
                xlim(app.ResultsAxes, [0 1]); ylim(app.ResultsAxes, [0 1]);
                return
            end
            J = opt.samples_J(:);
            X = opt.samples_x;
            valid = isfinite(J) & all(isfinite(X),2);
            X = X(valid,:); J = J(valid);
            D = opt.dimension;
            influence = zeros(D,1);
            for d = 1:D
                if std(X(:,d)) <= eps || std(J) <= eps
                    influence(d) = 0;
                else
                    C = corrcoef(X(:,d), J);
                    influence(d) = abs(C(1,2));
                    if ~isfinite(influence(d)); influence(d) = 0; end
                end
            end
            [influence, idx] = sort(influence, 'ascend');
            barh(app.ResultsAxes, 1:D, influence, 'FaceColor',app.Green, 'EdgeColor','none');
            app.ResultsAxes.YTick = 1:D;
            app.ResultsAxes.YTickLabel = {app.LastOutput.sim.study(idx).symbol};
            app.formatResultsAxes('Parameter sensitivity', '|corr(parameter, lap time)| [-]', 'Study parameter');
            xlim(app.ResultsAxes, [0 max(1, max(influence)*1.08)]);
            ylim(app.ResultsAxes, [0.5 D+0.5]);
            app.updateResultsInfo({'Showing: parameter sensitivity', 'Correlation-based diagnostic; not a causal proof.'});
            drawnow limitrate nocallbacks
        end

        function formatResultsAxes(app, ttl, xlab, ylab)
            app.applyResultsAxesBaseStyle();
            title(app.ResultsAxes, ttl, 'FontWeight','bold', 'Color',[1 1 1], 'Interpreter','none');
            xlabel(app.ResultsAxes, xlab, 'Color',[1 1 1], 'Interpreter','none');
            ylabel(app.ResultsAxes, ylab, 'Color',[1 1 1], 'Interpreter','none');
            try
                if numel(app.ResultsAxes.YAxis) > 1
                    app.ResultsAxes.YAxis(1).Color = [1 1 1];
                    app.ResultsAxes.YAxis(2).Color = [1 1 1];
                end
            catch
            end
        end

        function updateResultsInfo(app, lines)
            if ~isempty(app.ResultsInfoArea) && isvalid(app.ResultsInfoArea)
                app.ResultsInfoArea.Value = lines;
            end
        end

        function [radius_threshold, kappa_threshold] = resolveTrackLimit(~, mode, value)
            value = double(value);
            if ~isfinite(value) || value <= 0
                error('Track curve/straight limit must be a positive finite value.');
            end
            if strcmp(char(string(mode)), 'Curvature threshold [1/m]')
                kappa_threshold = value;
                radius_threshold = 1 / value;
            else
                radius_threshold = value;
                kappa_threshold = 1 / value;
            end
        end

        function onTrackLimitModeChanged(app)
            value = app.TrackFields.curve_limit_value.Value;
            if isfinite(value) && value > 0
                app.TrackFields.curve_limit_value.Value = 1 / value;
            elseif strcmp(app.TrackLimitModeDropDown.Value, 'Curvature threshold [1/m]')
                app.TrackFields.curve_limit_value.Value = app.DefaultKappaThreshold;
            else
                app.TrackFields.curve_limit_value.Value = app.DefaultRadiusThreshold;
            end
            app.updateTrackLimitTooltip();
        end

        function updateTrackLimitTooltip(app)
            if isempty(app.TrackLimitModeDropDown) || ~isvalid(app.TrackLimitModeDropDown)
                return
            end
            if strcmp(app.TrackLimitModeDropDown.Value, 'Curvature threshold [1/m]')
                tip = app.helpText('curve_limit_value_kappa', 'Curvature threshold');
            else
                tip = app.helpText('curve_limit_value_radius', 'Radius threshold');
            end
            app.setTip(app.TrackFields.curve_limit_value, 'custom_tip', tip);
        end

        function browseFile(app, key)
            [f,p] = uigetfile('*.mat', ['Select ' key ' file']);
            if isequal(f,0)
                return
            end
            app.FileFields.(key).Value = fullfile(p,f);
        end

        function browseFolder(app, key)
            p = uigetdir(pwd, ['Select ' key ' folder']);
            if isequal(p,0)
                return
            end
            app.FileFields.(key).Value = p;
        end

        function newDefaultProject(app)
            app.Project = msfeup_default_project();
            app.refreshUI();
            app.log('Loaded default project.');
        end

        function saveProject(app)
            app.readUI();
            msfeup_save_project(app.Project, []);
            app.log('Project saved.');
        end

        function loadProject(app)
            p = msfeup_load_project([]);
            if isempty(p)
                return
            end
            app.Project = p;
            app.refreshUI();
            app.log('Project loaded.');
        end

        function applyPreset(app)
            value = string(app.PresetDropDown.Value);
            if value == "Custom"
                return
            end

            p = app.ensureProjectCompatibility(app.Project);
            switch value
                case "Fast"
                    vals = struct('grid_1d_points',30,'random_samples',450,'top_starts',4, ...
                        'local_max_eval',80,'adaptive_rounds',1,'adaptive_samples',160, ...
                        'simplex_max_eval',80,'simplex_enabled',true,'precision',18);
                case "Balanced"
                    vals = struct('grid_1d_points',80,'random_samples',1800,'top_starts',12, ...
                        'local_max_eval',260,'adaptive_rounds',3,'adaptive_samples',560, ...
                        'simplex_max_eval',180,'simplex_enabled',true,'precision',36);
                case "Deep"
                    vals = struct('grid_1d_points',140,'random_samples',3200,'top_starts',18, ...
                        'local_max_eval',380,'adaptive_rounds',4,'adaptive_samples',900, ...
                        'simplex_max_eval',260,'simplex_enabled',true,'precision',50);
                case "Extreme"
                    vals = struct('grid_1d_points',240,'random_samples',6500,'top_starts',28, ...
                        'local_max_eval',560,'adaptive_rounds',5,'adaptive_samples',1400, ...
                        'simplex_max_eval',360,'simplex_enabled',true,'precision',70);
                otherwise
                    return
            end

            p.optim.grid_1d_points = vals.grid_1d_points;
            p.optim.random_samples = vals.random_samples;
            p.optim.top_starts = vals.top_starts;
            p.optim.local_max_eval = vals.local_max_eval;
            p.optim.adaptive_rounds = vals.adaptive_rounds;
            p.optim.adaptive_samples = vals.adaptive_samples;
            p.optim.simplex_max_eval = vals.simplex_max_eval;
            p.optim.simplex_enabled = vals.simplex_enabled;
            p.optim.precision = vals.precision;
            p.sensitivity.points_per_variable = vals.grid_1d_points;
            app.Project = p;
            app.refreshUI();
            app.log(sprintf('Preset applied: %s', value));
        end

        function bindSimulationCustomCallbacks(app)
            keys = {'nIter','tol','v_max_global','rng_seed','grid_1d_points','random_samples','top_starts', ...
                'local_max_eval','adaptive_rounds','adaptive_samples','precision','simplex_max_eval'};
            for i = 1:numel(keys)
                key = keys{i};
                if isfield(app.OptimFields, key) && ~isempty(app.OptimFields.(key)) && isvalid(app.OptimFields.(key))
                    app.OptimFields.(key).ValueChangedFcn = @(~,~) app.markPresetCustom();
                end
            end
            if isfield(app.OptimFields, 'use_grid_if_2d') && ~isempty(app.OptimFields.use_grid_if_2d) && isvalid(app.OptimFields.use_grid_if_2d)
                app.OptimFields.use_grid_if_2d.ValueChangedFcn = @(~,~) app.markPresetCustom();
            end
            if isfield(app.OptimFields, 'simplex_enabled') && ~isempty(app.OptimFields.simplex_enabled) && isvalid(app.OptimFields.simplex_enabled)
                app.OptimFields.simplex_enabled.ValueChangedFcn = @(~,~) app.markPresetCustom();
            end
        end

        function markPresetCustom(app)
            if isempty(app.PresetDropDown) || ~isvalid(app.PresetDropDown)
                return
            end
            if ~strcmp(app.PresetDropDown.Value, 'Custom')
                app.PresetDropDown.Value = 'Custom';
                app.log('Preset changed to Custom after manual Simulation edit.');
            end
        end

        function openFolder(app, whichFolder)
            app.readUI();
            if strcmp(whichFolder, 'figures')
                folder = app.Project.outputs.figures;
            else
                folder = app.Project.outputs.results;
            end
            if ~exist(folder, 'dir')
                mkdir(folder);
            end
            if ispc
                winopen(folder);
            elseif ismac
                system(['open "' folder '"']);
            else
                system(['xdg-open "' folder '" &']);
            end
        end

        function exportResults(app)
            if isempty(app.LastOutput) || ~isfield(app.LastOutput, 'summary')
                app.log('EXPORT blocked: run a simulation first.');
                return
            end

            app.readUI();
            cfg = app.LastOutput.cfg;
            cfg.output_folder = app.Project.outputs.figures;
            cfg.results_folder = app.Project.outputs.results;
            cfg.outputs.auto_export = true;
            cfg.outputs.write_summary = true;
            cfg.outputs.write_csv = true;
            cfg.outputs.write_archive = false;
            cfg.outputs.write_diagnostics_files = false;
            cfg.outputs.export_figures = true;
            cfg.outputs.export_force_profile = true;
            cfg.outputs.export_velocity_profile = false;
            cfg.visual.figure_visible = 'off';
            cfg.energy.plot_capacity_kWh = app.LastOutput.summary.battery_capacity_kWh;

            app.log('EXPORT started: figures + full_results.csv + summary.txt.');
            msfeup.write_msfeup_outputs(app.LastOutput.summary, app.LastOutput.sections, ...
                app.LastOutput.best, app.LastOutput.opt, app.LastOutput.sim, cfg, ...
                app.Project, app.LastOutput.mode);
            msfeup.plot_standard_output_set(app.LastOutput.track, app.LastOutput.best, ...
                app.LastOutput.opt, app.LastOutput.sim, cfg, app.LastOutput.mode);
            app.log(sprintf('EXPORT completed: %s', cfg.results_folder));
        end

        function clearResults(app)
            app.ResultsTable.Data = {};
            app.resetResultsAxes();
            app.formatResultsAxes('Track preview', 'X [m]', 'Y [m]');
            app.setProgressVisual(0, 'idle');
            app.log('Results view cleared.');
        end


        function btn = makeActionButton(app, parent, text, callback)
            btn = uibutton(parent,'push','Text',text, ...
                'FontName',app.Font, 'FontSize',app.BaseFontSize, 'FontWeight','bold', ...
                'BackgroundColor',[0.92 0.92 0.92], 'FontColor',[0 0 0], ...
                'ButtonPushedFcn',callback);
        end

        function panel = makeCard(app, parent, titleText)
            panel = uipanel(parent, 'Title',titleText, ...
                'FontName',app.Font, 'FontSize',16, 'FontWeight','bold', ...
                'ForegroundColor',[1 1 1], 'BackgroundColor',app.Card, ...
                'BorderType','line');
        end

        function makeProgressLabelTransparent(app)
            if isempty(app.ProgressLabel) || ~isvalid(app.ProgressLabel)
                return
            end
            try
                app.ProgressLabel.BackgroundColor = 'none';
            catch
                % Older MATLAB releases may not accept 'none' for uilabel.
                % Fallback: remove the black box and blend the label with the
                % progress panel background as closely as the component allows.
                try
                    app.ProgressLabel.BackgroundColor = app.ProgressPanel.BackgroundColor;
                catch
                end
            end
        end

        function setProgressVisual(app, pct, message)
            if nargin < 3
                message = '';
            end
            pct = max(0, min(100, pct));
            app.ProgressValue = pct;
            app.ProgressMessage = char(string(message));

            try
                drawnow limitrate
                pos = app.ProgressPanel.Position;
                w = max(40, pos(3) - 2);
                h = max(20, pos(4) - 2);
                fillW = max(1, w * pct / 100);
                app.ProgressFill.BackgroundColor = app.Green;
                app.ProgressFill.Position = [1 1 fillW h];
                app.ProgressLabel.Text = sprintf('%3.0f%% | %s', pct, app.ProgressMessage);
                labelW = min(max(260, 0.80*w), w - 16);
                app.ProgressLabel.Position = [max(8, (w-labelW)/2) max(3, (h-22)/2) labelW 22];
                app.makeProgressLabelTransparent();
                if pct >= 55
                    app.ProgressLabel.FontColor = [0 0 0];
                else
                    app.ProgressLabel.FontColor = [1 1 1];
                end
                try
                    uistack(app.ProgressFill, 'bottom');
                    uistack(app.ProgressLabel, 'top');
                catch
                end
            catch
                if ~isempty(app.ProgressGauge) && isvalid(app.ProgressGauge)
                    app.ProgressGauge.Value = pct;
                end
            end
        end

        function setTip(app, component, key, fallback)
            if nargin < 4
                fallback = key;
            end
            tip = app.helpText(key, fallback);
            try
                component.Tooltip = tip;
            catch
                % Older MATLAB releases may not expose Tooltip for every UI component.
            end
        end

        function showHelpPopup(app, key)
            txt = app.helpText(key, key);
            titleText = char(string(key));
            titleText = strrep(titleText, '_', ' ');
            if ~isempty(titleText)
                titleText(1) = upper(titleText(1));
            end
            try
                uialert(app.UIFigure, txt, titleText, 'Icon','info');
            catch
                app.log([titleText ': ' txt]);
            end
        end

        function txt = helpText(~, key, fallback)
            key = char(string(key));
            if startsWith(key, 'study_')
                id = extractAfter(string(key), 'study_');
                info = msfeup.study_parameter_registry(id);
                if info.known
                    txt = sprintf('%s (%s [%s]). Select it to include this parameter in the study and define physically credible lower/upper bounds.', info.name, info.symbol, info.unit);
                    return
                end
            end
            switch key
                case 'data'
                    txt = 'MAT file with GPS/track data, normally including LATITUDE and LONGITUDE. Typical check: closed lap, ordered samples, no repeated GPS blocks.';
                case 'theta'
                    txt = 'MAT file with longitudinal slope theta versus distance. Theta is slope/inclination, not heading. Typical values are small: roughly -0.20 to +0.20 rad.';
                case 'radius'
                    txt = 'Legacy radius/curvature MAT file. Kept for compatibility and checks; GPS-derived curvature remains the active source unless the backend is changed.';
                case 'power'
                    txt = 'MAT file with motor torque versus RPM. Typical columns: RPM/speed and torque in N.m. Wrong units strongly corrupt acceleration.';
                case 'figures'
                    txt = 'Folder where exported PDF figures and visual maps are written.';
                case 'results'
                    txt = 'Folder used only by manual export. Export results writes summary.txt and one full_results.csv; MAT archives stay disabled by default.';
                case 'mass'
                    txt = 'Total vehicle plus rider mass [kg]. Typical MotoStudent electric order: 170-270 kg including rider. Affects inertia, load transfer, grip demand and energy.';
                case 'wb'
                    txt = 'Wheelbase [m]. Typical racing motorcycle order: 1.2-1.5 m. Affects load transfer, wheelie and stoppie limits.';
                case 'cgx'
                    txt = 'Longitudinal CG position [m] measured from the front contact patch. Must remain between 0 and wheelbase. Typical value near 45-55% of wheelbase.';
                case 'cgh'
                    txt = 'CG height [m] above ground. Typical order: 0.35-0.65 m. Higher CG increases load transfer and wheelie/stoppie sensitivity.';
                case 'r_wheel'
                    txt = 'Effective rear wheel rolling radius [m]. Typical order: 0.28-0.33 m. Used for RPM, tractive force and redline speed.';
                case 'frontA'
                    txt = 'Reference frontal area [m²]. Typical motorcycle+rider order: 0.35-0.60 m². Used in drag and aero vertical-force terms.';
                case 'Cd'
                    txt = 'Drag coefficient [-]. Typical motorcycle+rider order: 0.35-0.75. Higher values increase drag and reduce straight speed.';
                case 'Cl'
                    txt = 'Lift coefficient [-]. Current sign convention: negative creates downforce, positive creates lift. Typical early estimate: -0.30 to +0.10.';
                case 'mu'
                    txt = 'Tyre-road friction coefficient [-]. Typical dry racing range may be about 0.9-1.3, but it must be calibrated, not freely optimized.';
                case 'fW'
                    txt = 'Rolling resistance coefficient [-]. Typical order: 0.010-0.020 for motorcycle tyres. Adds speed-independent resistive force.';
                case 'eta'
                    txt = 'Drivetrain efficiency [-]. Typical chain/drivetrain order: 0.90-0.98. Multiplies motor torque at the wheel.';
                case 'maxrpm'
                    txt = 'Maximum motor RPM. Used with wheel radius and gear ratio to compute redline vehicle-speed limit.';
                case 'rho'
                    txt = 'Air density [kg/m³]. Typical near sea level: 1.16-1.23. Used in drag and aerodynamic vertical-force calculations.';
                case 'g'
                    txt = 'Fixed constant: g = 9.81 m/s². It is not exposed as a tunable input because it is not a vehicle parameter.';
                case 'ds'
                    txt = 'Track discretization step [m]. Typical: 0.25-1.0 m. Smaller gives higher resolution but slower optimization.';
                case 'smooth_len_xy'
                    txt = 'GPS XY smoothing length [m]. Typical: 5-25 m. Too low keeps GPS noise; too high erases real corner geometry.';
                case 'curv_half_len'
                    txt = 'Half-window length [m] for local curvature estimation. Typical: 5-20 m. Larger windows smooth curvature but may understate tight corners.';
                case 'smooth_len_k'
                    txt = 'Curvature smoothing length [m]. Typical: 5-25 m. Larger values reduce GPS noise but may blunt tight corners.';
                case 'curve_limit_mode'
                    txt = 'Select the input form for the same curve/straight limiter: radius threshold [m] or curvature threshold [1/m]. Internally both are kept synchronized.';
                case 'curve_limit_value'
                    txt = 'Single curve/straight limiter value. Use the dropdown to choose radius [m] or curvature [1/m]. Typical radius: 300-6000 m; equivalent curvature: 0.00017-0.00333 1/m.';
                case 'curve_limit_value_radius'
                    txt = 'Radius threshold [m]. Segments with larger equivalent radius are treated as straight. Typical: 300-6000 m; default 4000 m.';
                case 'curve_limit_value_kappa'
                    txt = 'Curvature threshold [1/m]. Segments below this absolute curvature are treated as straight. Typical: 0.00017-0.00333 1/m; 1/4000 = 0.00025.';
                case 'g_fixed'
                    txt = 'Gravity is fixed at 9.81 m/s² in the backend. It is deliberately not exposed as a user input.';
                case 'straight_radius_threshold'
                    txt = 'Radius threshold [m] above which a segment is treated as straight. This is now linked to the single curve/straight limiter.';
                case 'max_closure_warning_m'
                    txt = 'Warning threshold for the GPS lap closure correction.';
                case 'corner_kappa_threshold'
                    txt = 'Curvature threshold [1/m] used to classify corners. This is now linked to the single curve/straight limiter.';
                case 'min_section_length'
                    txt = 'Minimum section length [m] retained in automatic track section analysis. Typical: 10-30 m to avoid tiny noisy sections.';
                case 'gear_ratio'
                    txt = 'Final drive ratio [-]. Typical sweep: 3.0-4.5. Higher ratio increases wheel force but lowers redline speed.';
                case 'v_max_global'
                    txt = 'Global vehicle speed cap [km/h]. It is converted internally to m/s. Numerical upper bound, not a target.';
                case 'nIter'
                    txt = 'Maximum circular forward/backward solver passes. Typical: 50-100. Increase only if convergence warnings appear.';
                case 'tol'
                    txt = 'Velocity convergence tolerance [m/s]. Typical: 1e-4 to 1e-3. Smaller is stricter but may be slower.';
                case 'n_laps'
                    txt = 'Number of laps used for total energy and battery sizing estimates.';
                case 'safety_coeff'
                    txt = 'Energy sizing safety coefficient applied to battery-capacity estimates.';
                case 'usable_fraction'
                    txt = 'Fraction of nominal battery capacity assumed usable.';
                case 'eta_regen'
                    txt = 'Regeneration efficiency during negative wheel-power phases.';
                case 'mode'
                    txt = 'Single Case evaluates one configuration. Sensitivity Analysis varies one enabled study variable at a time. Parametric / Optimization jointly searches enabled study variables.';
                case 'preset'
                    txt = 'Optimization-effort preset. Higher presets use more samples and deeper refinement.';
                case 'sampling_quality'
                    txt = 'Presets are the normal user-facing quality control. Use Balanced for ordinary work, Fast for quick checks, and Deep/Extreme only when you need denser maps or more confidence.';
                case 'run_export_policy'
                    txt = 'RUN only computes and updates the app. It does not write CSV, PDF or TXT files. Use Results > Export results when you deliberately want output files.';
                case 'recommended_workflow'
                    txt = 'Recommended flow: validate inputs, run Single Case, inspect maps/log warnings, test one or two variables, then expand the study only with credible physical bounds.';
                case 'advanced_sampling_guide'
                    txt = 'One active variable uses 1D grid points. Two active variables use 2D grid resolution when 2D grid search is On. Three or more variables use random samples plus adaptive samples.';
                case 'advanced_policy'
                    txt = 'Advanced controls change computational effort and numerical confidence, not the physical equations. If increasing sampling changes the result, treat the previous optimum as under-sampled.';
                case 'grid_1d_points'
                    txt = 'Sampling density for one-variable optimization and for Sensitivity Analysis. With several sensitivity variables, this is the number of sweep points per variable.';
                case 'random_samples'
                    txt = 'Number of global design samples used before local refinement in 3D+ studies, or when 2D grid search is Off.';
                case 'top_starts'
                    txt = 'Number of best global candidates used as starting points for local refinement.';
                case 'local_max_eval'
                    txt = 'Maximum objective evaluations allowed per local pattern-search refinement.';
                case 'adaptive_rounds'
                    txt = 'Number of elite-zoom sampling rounds after the first global exploration stage.';
                case 'adaptive_samples'
                    txt = 'Number of new samples per adaptive zoom round. Higher values improve local map density but increase runtime.';
                case 'precision'
                    txt = '2D grid resolution when two study parameters are active and 2D grid search is enabled. Fast=18, Balanced=36, Deep=50, Extreme=70 points per axis.';
                case 'use_grid_if_2d'
                    txt = 'When On, two-parameter studies use a full grid (resolution^2 simulations) before local refinement. Turn Off to use global sampling only.';
                case 'simplex_enabled'
                    txt = 'Enables final simplex refinement after pattern search. Usually keep On for optimization, Off only for faster diagnostics.';
                case 'simplex_max_eval'
                    txt = 'Maximum objective evaluations for simplex refinement. Higher values may improve final polishing but increase runtime.';
                case 'rng_seed'
                    txt = 'Random seed for reproducible global/adaptive sampling. Change it to test whether an optimum is sampling-dependent.';
                case 'study_table'
                    txt = 'Study setup controls. Enabled parameters define which variables are studied and their bounds.';
                case 'run'
                    txt = 'Runs the selected mode using the current project configuration.';
                case 'stop'
                    txt = 'Interrupts the active run at the next UI/progress call. MATLAB cannot safely kill a numeric function mid-line without risking the session.';
                otherwise
                    txt = char(string(fallback));
            end
        end

        function openHelpWindow(app)
            try
                if isdeployed
                    root = ctfroot;
                else
                    root = fileparts(mfilename('fullpath'));
                end
                guideFile = fullfile(root, 'docs', 'MSFEUP_LapTool_User_Guide.pdf');
                if ~isfile(guideFile) && ~isdeployed
                    guideFile = fullfile(app.Project.root, 'docs', 'MSFEUP_LapTool_User_Guide.pdf');
                end
                if ~isfile(guideFile)
                    uialert(app.UIFigure, ['Documentation file not found: ' guideFile], 'Help unavailable');
                    return
                end
                if ispc
                    winopen(guideFile);
                else
                    open(guideFile);
                end
            catch ME
                uialert(app.UIFigure, ME.message, 'Help unavailable');
            end
        end

        function toggleStatusPanel(app)
            try
                if isempty(app.StatusPanel) || ~isvalid(app.StatusPanel)
                    return
                end
                if strcmp(app.StatusPanel.Visible,'on')
                    app.StatusPanel.Visible = 'off';
                    if ~isempty(app.BodyGrid) && isvalid(app.BodyGrid)
                        app.BodyGrid.ColumnWidth = {'1x',0};
                        app.BodyGrid.ColumnSpacing = 0;
                    end
                    if ~isempty(app.StatusToggleButton) && isvalid(app.StatusToggleButton)
                        app.StatusToggleButton.BackgroundColor = app.Card2;
                    end
                else
                    app.StatusPanel.Visible = 'on';
                    if ~isempty(app.BodyGrid) && isvalid(app.BodyGrid)
                        app.BodyGrid.ColumnWidth = {'1x',275};
                        app.BodyGrid.ColumnSpacing = 8;
                    end
                    if ~isempty(app.StatusToggleButton) && isvalid(app.StatusToggleButton)
                        app.StatusToggleButton.BackgroundColor = app.Green;
                    end
                end
                drawnow limitrate
                app.onAppResized();
            catch
            end
        end

        function toggleAdvancedPanel(app)
            try
                show = ~isempty(app.ShowAdvancedCheckBox) && isvalid(app.ShowAdvancedCheckBox) && app.ShowAdvancedCheckBox.Value;
                if ~isempty(app.AdvancedPanel) && isvalid(app.AdvancedPanel)
                    if show
                        app.AdvancedPanel.Visible = 'on';
                    else
                        app.AdvancedPanel.Visible = 'off';
                    end
                    app.resizeInputsPage();
                end
            catch ME
                try
                    app.log(['Advanced layout warning: ' ME.message]);
                catch
                end
            end
        end

        function out = onOffString(~, tf)
            if tf
                out = 'On';
            else
                out = 'Off';
            end
        end

        function setBg(~, obj, color)
            try
                obj.BackgroundColor = color;
            catch
            end
        end

        function enableScrollable(~, obj)
            try
                obj.Scrollable = 'on';
            catch
                % Older MATLAB releases do not expose Scrollable for every UI container.
            end
        end

        function forceDarkTheme(app)
            try
                objs = findall(app.UIFigure);
                for k = 1:numel(objs)
                    obj = objs(k);
                    cname = class(obj);
                    if contains(cname, 'GridLayout')
                        try
                            if isprop(obj.Parent, 'BackgroundColor')
                                obj.BackgroundColor = obj.Parent.BackgroundColor;
                            else
                                obj.BackgroundColor = app.Dark;
                            end
                        catch
                            try, obj.BackgroundColor = app.Dark; catch, end
                        end
                    elseif contains(cname, 'Tab')
                        try, obj.BackgroundColor = app.Dark; catch, end
                    end
                end
                if ~isempty(app.ResultsAxes) && isvalid(app.ResultsAxes)
                    app.ResultsAxes.Color = app.Dark;
                    app.ResultsAxes.XColor = [1 1 1];
                    app.ResultsAxes.YColor = [1 1 1];
                    app.ResultsAxes.GridColor = [0.45 0.45 0.45];
                end
                if ~isempty(app.ResultsTable) && isvalid(app.ResultsTable)
                    try
                        app.ResultsTable.BackgroundColor = [1 1 1; 0.96 0.96 0.96];
                        app.ResultsTable.FontColor = [0 0 0];
                    catch
                    end
                end
            catch
            end
        end

        function log(app, message)
            if isempty(app.StatusArea) || ~isvalid(app.StatusArea)
                return
            end
            old = app.StatusArea.Value;
            if ischar(old)
                old = {old};
            end
            stamp = datestr(now,'HH:MM:SS');
            newLine = sprintf('[%s] %s', stamp, message);
            app.StatusArea.Value = [old; {newLine}];
            drawnow limitrate
        end

        function clearLog(app)
            if isempty(app.StatusArea) || ~isvalid(app.StatusArea)
                return
            end
            app.StatusArea.Value = {''};
            drawnow limitrate
        end

        function logRunSummary(app)
            if isempty(app.LastOutput) || ~isfield(app.LastOutput, 'summary')
                return
            end
            s = app.LastOutput.summary;
            if app.isSensitivityOutput(app.LastOutput)
                app.log(sprintf('SUMMARY baseline/current lap %.6f s | mean %.2f km/h | energy %.4f kWh/lap', ...
                    s.lap_time_s, s.mean_speed_kph, s.energy_per_lap_kWh));
                [bestSweepJ, bestSweepX, bestPhase] = app.bestSampledPoint(app.LastOutput);
                if isfinite(bestSweepJ)
                    if isfield(app.LastOutput, 'sim') && isfield(app.LastOutput.sim, 'study') && ...
                            numel(app.LastOutput.sim.study) == 1 && ~isempty(bestSweepX)
                        st = app.LastOutput.sim.study(1);
                        app.log(sprintf('SENS best sweep sample %.6f s at %s = %.12g', ...
                            bestSweepJ, char(string(st.id)), bestSweepX(1)));
                    elseif ~isempty(bestSweepX)
                        app.log(sprintf('SENS best sweep sample %.6f s | phase %s | x = [%s]', ...
                            bestSweepJ, char(bestPhase), strjoin(compose('%.12g', bestSweepX), ', ')));
                    else
                        app.log(sprintf('SENS best sweep sample %.6f s', bestSweepJ));
                    end
                end
            else
                app.log(sprintf('SUMMARY lap %.6f s | mean %.2f km/h | energy %.4f kWh/lap', ...
                    s.lap_time_s, s.mean_speed_kph, s.energy_per_lap_kWh));
            end

            if isfield(app.LastOutput, 'opt') && isfield(app.LastOutput.opt, 'diagnostics') && ...
                    isfield(app.LastOutput.opt.diagnostics, 'warnings')
                d = app.LastOutput.opt.diagnostics;
                if isfield(d, 'multistart') && isfield(d.multistart, 'available') && d.multistart.available
                    app.log(sprintf('OPT confidence multi-start %s | %d/%d within %.4g s | refined range %.4g s', ...
                        char(string(d.multistart.confidence)), d.multistart.n_converged, ...
                        d.multistart.n_starts, d.multistart.epsilon_s, d.multistart.refined_range_s));
                end
                w = app.LastOutput.opt.diagnostics.warnings;
                for i = 1:numel(w)
                    app.log(['WARN ' char(w(i))]);
                end
            end

            if isfield(app.LastOutput, 'opt') && isfield(app.LastOutput.opt, 'sensitivity') && ...
                    isfield(app.LastOutput.opt.sensitivity, 'summary')
                S = app.LastOutput.opt.sensitivity.summary;
                for i = 1:height(S)
                    app.log(sprintf('SENS %s | effect %.4g s (%.4g%%) | %s', ...
                        char(S.variable(i)), S.range_effect_s(i), S.range_effect_pct(i), char(S.note(i))));
                end
            end
        end
    end
end
