function app = launch_MSFEUP()
%LAUNCH_MSFEUP  Launch the MSFEUP Motorcycle Lap Simulation Tool.
% Compatible with MATLAB and MATLAB Compiler deployed applications.

    if ~isdeployed
        root = fileparts(mfilename('fullpath'));
        addpath(root);
        addpath(genpath(root));
    end

    % Accessibility compatibility:
    % Some MATLAB/Windows combinations emit a startup warning and force
    % figures to Scrollable='on' when Windows Accessibility > Text size is
    % greater than 100%. During app construction, align MATLAB's default
    % with that behavior, then restore the user's session defaults.
    scrollableDefaultCleanup = localTemporaryScrollableDefault('on');

    app = MSFEUP_LapTool();

    delete(scrollableDefaultCleanup);
end

function cleanup = localTemporaryScrollableDefault(value)
% Temporarily set supported figure scrollable defaults.
% Unsupported properties are ignored to keep older MATLAB releases working.

    restore = {};
    props = {'defaultFigureScrollable','defaultUifigureScrollable'};

    for k = 1:numel(props)
        prop = props{k};
        try
            oldValue = get(groot, prop);
            set(groot, prop, value);
            restore(end+1,:) = {prop, oldValue}; %#ok<AGROW>
        catch
            % Property is not supported by this MATLAB release.
        end
    end

    cleanup = onCleanup(@() localRestoreScrollableDefaults(restore));
end

function localRestoreScrollableDefaults(restore)
    for k = 1:size(restore,1)
        try
            set(groot, restore{k,1}, restore{k,2});
        catch
            % Ignore restore failures during MATLAB shutdown/deployed exit.
        end
    end
end
