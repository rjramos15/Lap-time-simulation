function output = msfeup_run_project(project, mode, progressFcn)
%MSFEUP_RUN_PROJECT  Run MSFEUP lap simulation from a project structure.
%
%   output = msfeup_run_project(project, 'single')
%   output = msfeup_run_project(project, 'optimize')
%
% Thin facade over the +msfeup package. Physical model and I/O live in
% msfeup.* modules so the backend can be tested and extended independently.

    if nargin < 1 || isempty(project)
        project = msfeup_default_project();
    end
    if nargin < 2 || isempty(mode)
        mode = 'single';
    end
    if nargin < 3
        progressFcn = [];
    end

    mode = lower(string(mode));
    msfeup.reset_poll_abort();
    notify_progress(progressFcn, 0.02, 'Preparing configuration');

    project_preflight = project;
    if mode == "single"
        project_preflight.study = msfeup_empty_study();
    end

    preflight_report = msfeup.validate_project_inputs(project_preflight);
    emit_preflight_report(preflight_report);
    if ~preflight_report.ok
        error('MSFEUP:PreflightFailed', 'Project preflight validation failed. Inspect report.messages for details.');
    end

    cfg = msfeup.default_config();
    cfg = msfeup.apply_project_to_cfg(cfg, project);
    cfg.progressFcn = progressFcn;
    cfg.optim.waitbar = false;

    if mode == "single"
        cfg.study = msfeup_empty_study();
        cfg.optim.checkpoint_enabled = false;
    else
        cfg.study = project.study;
    end

    if should_auto_export(cfg)
        msfeup.ensure_output_folders(cfg);
    end

    notify_progress(progressFcn, 0.08, 'Loading combined track input MAT');
    trackInput = msfeup.load_track_input(project);

    M = msfeup.fetch_required_field(trackInput, 'M', trackInput.source_file);
    thetadata = msfeup.fetch_required_field(trackInput, 'thetadata', trackInput.source_file);
    teste = msfeup.fetch_required_field(trackInput, 'teste', trackInput.source_file);

    notify_progress(progressFcn, 0.18, 'Building GPS track');
    [xpos, R_file, theta] = msfeup.distance(M.LATITUDE, M.LONGITUDE, teste.distance, ...
        teste.rad, thetadata.xPosition_m_, thetadata.Theta_rad_, cfg.ds);

    track = msfeup.build_gps_track(M.LATITUDE, M.LONGITUDE, xpos, theta, R_file, cfg);

    notify_progress(progressFcn, 0.32, 'Loading power curve');
    vehicle = project.vehicle;
    operating = project.operating;
    power = msfeup.load_power_curve(project.files.power, vehicle.maxrpm);

    notify_progress(progressFcn, 0.42, 'Building simulation context');
    sim = msfeup.build_simulation_context(cfg, track, vehicle, operating, power);

    fprintf('\nMSFEUP LAP SIMULATION TOOL\n');
    fprintf('=======================================================================\n');
    fprintf('Mode:                   %s\n', upper(mode));
    fprintf('Track length:           %.2f m\n', track.length);
    fprintf('Track points:           %d\n', track.N);
    fprintf('Maximum |kappa|:        %.5f 1/m\n', max(abs(track.kappa)));
    fprintf('=======================================================================\n');

    switch mode
        case "single"
            notify_progress(progressFcn, 0.55, 'Running single-case simulation');
            [lap_time, result] = msfeup.simulate_lap_case([], sim, true);

            best = struct;
            best.x = [];
            best.lap_time = lap_time;
            best.result = result;

            opt = msfeup.empty_optimizer_output();

        case {"optimize", "optimization", "parametric", "study"}
            if isempty(sim.study)
                error('Optimization mode requires at least one active study parameter.');
            end

            msfeup.validate_study(sim.study, sim.vehicle, sim.operating, 'optimization');

            notify_progress(progressFcn, 0.50, 'Evaluating baseline');
            sim.baseline = evaluate_baseline_local(sim);

            notify_progress(progressFcn, 0.58, 'Running global optimization');
            [best, opt] = msfeup.optimize_lap(sim, cfg);

        case {"sensitivity", "sensitivity_analysis"}
            if isempty(sim.study)
                error('Sensitivity mode requires at least one active study parameter.');
            end

            msfeup.validate_study(sim.study, sim.vehicle, sim.operating, 'sensitivity');

            notify_progress(progressFcn, 0.50, 'Running one-at-a-time sensitivity study');
            [best, opt, baseline] = msfeup.run_sensitivity(sim, cfg);
            sim.baseline = baseline;

        otherwise
            error('Unknown run mode: %s.', mode);
    end

    notify_progress(progressFcn, 0.82, 'Post-processing results');
    summary = msfeup.build_summary(best, sim, cfg);
    sections = msfeup.build_section_analysis(track, best.result, cfg);

    if should_auto_export(cfg)
        notify_progress(progressFcn, 0.90, 'Exporting configured outputs');
        msfeup.write_msfeup_outputs(summary, sections, best, opt, sim, cfg, project, mode);

        if should_export_figures(cfg)
            notify_progress(progressFcn, 0.94, 'Generating figures');
            cfg.energy.plot_capacity_kWh = summary.battery_capacity_kWh;
            msfeup.plot_standard_output_set(track, best, opt, sim, cfg, mode);
        end
    else
        notify_progress(progressFcn, 0.94, 'Automatic export skipped');
    end

    output = struct;
    output.mode = char(mode);
    output.summary = summary;
    output.sections = sections;
    output.best = best;
    output.opt = opt;
    output.sim = sim;
    output.track = track;
    output.cfg = cfg;
    output.project = project;
    output.preflight_report = preflight_report;

    notify_progress(progressFcn, 1.00, 'Done');
end

function baseline = evaluate_baseline_local(sim)
    x0 = base_parameter_vector_local(sim);
    [lap_time, result] = msfeup.simulate_lap_case(x0, sim, true);
    baseline = struct;
    baseline.x = x0;
    baseline.lap_time = lap_time;
    baseline.result = result;
end

function x0 = base_parameter_vector_local(sim)
    D = numel(sim.study);
    x0 = zeros(1, D);
    for d = 1:D
        id = sim.study(d).id;
        x0(d) = msfeup.get_study_parameter_value(id, sim.vehicle, sim.operating, mean(sim.study(d).range));
    end
    for d = 1:D
        x0(d) = min(max(x0(d), sim.study(d).range(1)), sim.study(d).range(2));
    end
end

function notify_progress(progressFcn, value, message)
    if ~isa(progressFcn, 'function_handle')
        return
    end
    try
        progressFcn(value, message);
    catch ME
        if strcmp(ME.identifier, 'MSFEUP:UserStop')
            rethrow(ME);
        end
        warning('MSFEUP:ProgressCallback', 'Progress callback failed: %s', ME.message);
    end
end

function emit_preflight_report(report)
    if isfield(report, 'warnings')
        for i = 1:numel(report.warnings)
            warning('MSFEUP:PreflightWarning', '%s', char(report.warnings(i)));
        end
    end
end

function tf = should_export_figures(cfg)
    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'export_figures') && cfg.outputs.export_figures;
end

function tf = should_auto_export(cfg)
    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'auto_export') && cfg.outputs.auto_export;
end
