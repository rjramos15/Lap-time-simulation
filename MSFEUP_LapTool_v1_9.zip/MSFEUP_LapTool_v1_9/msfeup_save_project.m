function msfeup_save_project(project, file_name)
%MSFEUP_SAVE_PROJECT  Save project configuration to MAT file.

    if nargin < 2 || isempty(file_name)
        [f, p] = uiputfile('*.mat', 'Save MSFEUP project');
        if isequal(f,0)
            return
        end
        file_name = fullfile(p, f);
    end

    save(file_name, 'project');
end
