function [vehicle, operating] = set_study_parameter_value(id, value, vehicle, operating)
%SET_STUDY_PARAMETER_VALUE  Write a study parameter using canonical registry.

    info = msfeup.study_parameter_registry(id);
    if ~info.known
        error('Unknown study parameter id: %s.', char(string(id)));
    end

    switch info.owner
        case 'vehicle'
            vehicle.(info.field) = value;
        case 'operating'
            operating.(info.field) = value;
        otherwise
            error('Study parameter %s has no writable target.', char(string(id)));
    end
end
