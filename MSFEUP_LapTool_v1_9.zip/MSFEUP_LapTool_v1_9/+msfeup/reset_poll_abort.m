function reset_poll_abort()
%RESET_POLL_ABORT  Clear poll timing state before a new simulation run.

    poll_abort('reset');
end
