function [radius_threshold, kappa_threshold] = resolve_curve_limit(mode, value)

    value = double(value);
    if ~isfinite(value) || value <= 0
        error('Track curve/straight limit must be a positive finite value.');
    end

    if strcmp(char(string(mode)), 'Curvature threshold [1/m]')
        kappa_threshold = value;
        radius_threshold = 1 / value;
    else
        radius_threshold = value;
        kappa_threshold = 1 / value;
    end
end
