function notify_progress(progressFcn, value, message)

    if isa(progressFcn, 'function_handle')
        try
            progressFcn(value, message);
        catch ME
            if strcmp(ME.identifier, 'MSFEUP:UserStop')
                rethrow(ME)
            end
            warning('MSFEUP:ProgressCallback', 'Progress callback failed: %s', ME.message);
        end
    end
end
