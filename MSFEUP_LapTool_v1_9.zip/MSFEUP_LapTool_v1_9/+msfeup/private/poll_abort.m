function poll_abort(progressFcn)

    persistent lastPoll

    if ischar(progressFcn) && strcmp(progressFcn, 'reset')
        lastPoll = [];
        return
    end

    if ~isa(progressFcn, 'function_handle')
        return
    end

    if isempty(lastPoll)
        lastPoll = tic;
    elseif toc(lastPoll) < 0.15
        return
    end
    lastPoll = tic;

    try
        progressFcn(NaN, '');
    catch ME
        if strcmp(ME.identifier, 'MSFEUP:UserStop')
            rethrow(ME)
        end
    end
end
