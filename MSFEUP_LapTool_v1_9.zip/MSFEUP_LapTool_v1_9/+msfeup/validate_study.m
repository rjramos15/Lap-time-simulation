function validate_study(study, vehicle, operating, mode)
%VALIDATE_STUDY  Validate active study variables before sensitivity/optimization.

    if nargin < 4 || isempty(mode)
        mode = 'optimization';
    end

    if isempty(study)
        error('At least one study parameter must be defined.');
    end

    ids = strings(numel(study),1);

    for i = 1:numel(study)
        if ~isfield(study(i), 'id') || isempty(study(i).id)
            error('Study parameter %d has no id.', i);
        end

        ids(i) = string(study(i).id);

        if ~isfield(study(i), 'range') || ~isnumeric(study(i).range) || numel(study(i).range) ~= 2
            error('Invalid range for study parameter %s.', study(i).id);
        end

        range = double(study(i).range(:)');
        if any(~isfinite(range)) || range(2) <= range(1)
            error('Invalid range for study parameter %s.', study(i).id);
        end

        info = msfeup.study_parameter_registry(study(i).id);
        if ~info.known
            error('Unknown study parameter id: %s.', study(i).id);
        end
        baseline = msfeup.get_study_parameter_value(study(i).id, vehicle, operating, NaN);
        if ~isfinite(baseline)
            error('Baseline value for %s is missing or non-finite.', study(i).id);
        end

        if baseline < range(1) || baseline > range(2)
            error('Baseline value for %s is outside study range [%.6g, %.6g].', ...
                study(i).id, range(1), range(2));
        end

        validate_physical_range(study(i).id, range);
    end

    if numel(unique(ids)) ~= numel(ids)
        error('Repeated study parameter id.');
    end

    if any(ids == "mass") && numel(ids) > 1 && strcmpi(char(string(mode)), 'optimization')
        warning('MSFEUP:MassOptimization', ...
            ['mass is active in a multi-parameter optimization. Treat mass first as a sensitivity variable ', ...
             'unless a design-level optimization justification is documented.']);
    end
end

function validate_physical_range(id, range)

    info = msfeup.study_parameter_registry(id);
    if ~info.known
        error('Unknown study parameter id: %s.', id);
    end

    if info.positive_range && range(1) <= 0
        error('Study range for %s must remain positive.', id);
    end
    if isfinite(info.min_range) && range(1) < info.min_range
        error('Study range for %s must be >= %.6g.', id, info.min_range);
    end
    if isfinite(info.max_range) && range(2) > info.max_range
        error('Study range for %s must not exceed %.6g.', id, info.max_range);
    end
    if isfinite(info.warn_abs_range) && max(abs(range)) > info.warn_abs_range
        warning('MSFEUP:WideStudyRange', 'Study range for %s is unusually wide.', id);
    end
end
