function plot_standard_output_set(track, best, opt, sim, cfg, mode)

    set(groot,'defaultLegendTextColor','k')

    if ~isfield(cfg, 'outputs') || ~isfield(cfg.outputs, 'export_force_profile') || cfg.outputs.export_force_profile
        plot_force_profile(track, best.result, cfg);
    end

    if isfield(cfg, 'outputs') && isfield(cfg.outputs, 'export_velocity_profile') && cfg.outputs.export_velocity_profile
        plot_velocity_profile(track, best.result, cfg);
    end

    plot_soc(track, best.result, cfg);

    if is_sensitivity_mode(mode) && isfield(opt, 'samples_J') && ~isempty(opt.samples_J)
        plot_parameter_sensitivity(opt, sim, cfg);
    elseif mode ~= "single" && isfield(opt, 'samples_J') && ~isempty(opt.samples_J)
        plot_parameter_map(opt, sim, best, cfg);
        plot_laptime_distribution(opt, cfg);
        plot_design_projection(opt, sim, best, cfg);
        plot_best_design_profile(opt, sim, best, cfg);
        plot_convergence(opt, cfg);
    end

    plot_track_scalar(track, best.result.v, 'Track Velocity Map', 'Velocity [m/s]', ...
        'track_velocity_map.pdf', cfg, [min(best.result.v) max(best.result.v)]);

    plot_track_scalar(track, abs(track.kappa), 'GPS Curvature Map', '|\kappa| [1/m]', ...
        'track_curvature_map.pdf', cfg, [0 local_percentile(abs(track.kappa), 99)]);

    plot_track_scalar(track, abs(best.result.ay_g), 'Track Lateral Acceleration Map', '|a_y| [g]', ...
        'track_lateral_acceleration_map.pdf', cfg, [0 local_percentile(abs(best.result.ay_g), 99)]);

    ax_lim_plot = local_percentile(abs(best.result.ax_g), 99);
    if ~isfinite(ax_lim_plot) || ax_lim_plot <= 0
        ax_lim_plot = max(abs(best.result.ax_g));
    end
    if ~isfinite(ax_lim_plot) || ax_lim_plot <= 0
        ax_lim_plot = 1;
    end

    plot_track_scalar(track, best.result.ax_g, 'Track Longitudinal Acceleration Map', 'a_x [g]', ...
        'track_longitudinal_acceleration_map.pdf', cfg, [-ax_lim_plot ax_lim_plot]);

    plot_constraint_map(track, best.result, cfg);
    plot_rpm_power(track, best.result, cfg);
end

%% =========================================================
% LOCAL FUNCTION: write project outputs
% =========================================================

function tf = is_sensitivity_mode(mode)

    mode = lower(string(mode));
    tf = mode == "sensitivity" || mode == "sensitivity_analysis";
end

%% =========================================================
% LOCAL FUNCTION: velocity profile
% =========================================================

function plot_velocity_profile(track, r, cfg)

    fig = figure('Name', 'Velocity Profile', 'Color', 'w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    plot(track.s, r.v_lim_curve*3.6, '--', 'LineWidth', 0.8, 'Color', [0.45 0.45 0.45]);
    plot(track.s, r.v*3.6, 'LineWidth', 1.2, 'Color', cfg.visual.primary_green);

    ax.XGrid = 'off';
    ax.GridAlpha = 0.35;

    xlabel('s [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('v [km/h]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    leg1 = legend('v_{lim,curve}','v_{final}','Location','northeast','Box','off');
    leg1.FontSize = cfg.visual.font_size;
    leg1.FontName = cfg.visual.font_name;
    set(findall(leg1,'Type','text'),'Color',[0 0 0]);

    save_figure(fig, 'velocity_profile.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: force profile
% =========================================================

function plot_force_profile(track, r, cfg)

    fig = figure('Name', 'Force Profile', 'Color', 'w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    plot(track.s, r.F_available, '--', 'LineWidth', 0.8, 'Color', [0.2 0.2 0.2]);
    plot(track.s, r.F_drive,     'LineWidth', 1.1, 'Color', [0.1 0.7 0.2]);
    plot(track.s, r.F_drag,      'LineWidth', 1.0, 'Color', [0.0 0.45 0.75]);
    plot(track.s, r.F_down,      'LineWidth', 1.0, 'Color', [0.0 0.25 0.45]);
    plot(track.s, r.F_rr,        'LineWidth', 1.0, 'Color', [0.75 0.2 0.75]);
    plot(track.s, r.F_slope,     'LineWidth', 1.0, 'Color', [0.9 0.6 0.1]);

    ax.XGrid = 'off';
    ax.GridAlpha = 0.35;

    xlabel('s [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Force [N]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    leg2 = legend('F_{available}','F_{drive}','F_{drag}',...
        'F_{down}','F_{rr}','F_{slope}','Location','northeast','Box','off');
    leg2.FontSize = 18.5;
    leg2.FontName = cfg.visual.font_name;
    set(findall(leg2,'Type','text'),'Color',[0 0 0]);

    save_figure(fig, 'force_profile.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: SOC plot
% =========================================================

function plot_soc(track, r, cfg)

    E_cum_J = cumsum(r.E_seg);
    E_battery_J = cfg.energy.plot_capacity_kWh * 3.6e6;

    SOC = 100 * (1 - E_cum_J ./ E_battery_J);
    SOC(SOC > 100) = 100;
    SOC(SOC < 0) = 0;

    fig = figure('Name','State of Charge Profile','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    plot(track.s, SOC, 'LineWidth', 2.0, 'Color', [0.8500 0.3250 0.0980]);

    ax.XGrid = 'off';
    ax.GridAlpha = 0.35;

    pbaspect(ax,[1.4 1 1])
    ax.YLim = [min(SOC) 100];

    xlabel('s [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('SOC [%]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    leg = legend(sprintf('State of Charge for %.1f kWh capacity', round(cfg.energy.plot_capacity_kWh,1)),...
        'Location','northeast','Box','off');
    leg.FontSize = cfg.visual.label_size;
    leg.FontName = cfg.visual.font_name;
    leg.TextColor = [0 0 0];
    leg.EdgeColor = 'none';
    set(findall(leg,'Type','text'),'Color',[0 0 0]);

    save_figure(fig, 'soc_profile.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: parameter study maps
% =========================================================

function plot_parameter_map(opt, sim, best, cfg)

    if opt.dimension == 1
        plot_parameter_1d(opt, sim, best, cfg);
        plot_parameter_sensitivity(opt, sim, cfg);
    elseif opt.dimension == 2 && ~isempty(opt.grid)
        plot_parameter_surface(opt, sim, best, cfg);
    else
        plot_parameter_parallel(opt, sim, best, cfg);
        plot_parameter_sensitivity(opt, sim, cfg);
    end
end

%% =========================================================
% LOCAL FUNCTION: 1D parameter sweep plot
% =========================================================

function plot_parameter_1d(opt, sim, best, cfg)

    X = opt.samples_x;
    J = opt.samples_J(:);
    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);
    if isempty(J)
        return
    end

    [x_sorted, idx] = sort(X(:,1), 'ascend');
    J_sorted = J(idx);

    fig = figure('Name','One-Dimensional Parameter Sweep','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    scatter(x_sorted, J_sorted, 32, J_sorted, 'filled');
    plot(best.x(1), best.lap_time, 'ko', 'MarkerSize', 9, 'MarkerFaceColor','w','LineWidth',1.5);
    colormap(cfg.visual.colormap)

    xlabel(sprintf('%s [%s]', sim.study(1).symbol, sim.study(1).unit), ...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Lap Time [s]', 'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    title('1D parameter sweep', 'FontName',cfg.visual.font_name, 'FontSize',cfg.visual.font_size, 'Color','k');

    save_figure(fig, 'parameter_1d_sweep.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: 2D parameter surface
% =========================================================

function plot_parameter_surface(opt, sim, best, cfg)

    [X,Y] = meshgrid(opt.grid.x1, opt.grid.x2);

    xq = linspace(min(opt.grid.x1), max(opt.grid.x1), 175);
    yq = linspace(min(opt.grid.x2), max(opt.grid.x2), 175);
    [Xq,Yq] = meshgrid(xq,yq);

    Zq = interp2(X,Y,opt.grid.J,Xq,Yq,'pchip');

    fig = figure('Name','Parameter Map','Color','w','Visible',cfg.visual.figure_visible);
    ax = gca; hold on
    apply_axes_identity(ax, cfg);

    contourf(Xq,Yq,Zq,35,'LineStyle','none');
    colormap(cfg.visual.colormap)
    contour(Xq,Yq,Zq,14,'LineColor',[0.2 0.2 0.2],'LineWidth',0.5);

    J_valid = opt.grid.J(isfinite(opt.grid.J));
    apply_safe_clim(J_valid, 2, 98);

    cb = colorbar;
    cb.Color = 'k';
    cb.FontName = cfg.visual.font_name;
    cb.FontSize = cfg.visual.font_size;
    cb.Label.String = 'Lap Time [s]';
    cb.Label.FontName = cfg.visual.font_name;
    cb.Label.FontSize = cfg.visual.label_size;

    xlabel(sim.study(1).symbol,'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel(sprintf('%s [%s]',sim.study(2).symbol,sim.study(2).unit),...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    plot(best.x(1), best.x(2), 'ko', 'MarkerSize', 6, 'MarkerFaceColor','w','LineWidth',1);

    axis tight
    pbaspect([1 1 1])
    xlim(sim.study(1).range)
    ylim(sim.study(2).range)

    save_figure(fig, 'parameter_map.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: multidimensional parameter parallel map
% =========================================================

function plot_parameter_parallel(opt, sim, best, cfg)

    X = opt.samples_x;
    J = opt.samples_J(:);

    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);

    if isempty(J)
        return
    end

    D = opt.dimension;
    Z = (X - opt.lb) ./ (opt.ub - opt.lb);
    Z = min(max(Z, 0), 1);

    [~, idx_sort] = sort(J, 'ascend');
    n_show = min(numel(J), 240);
    idx_show = idx_sort(1:n_show);

    J_show = J(idx_show);
    Z_show = Z(idx_show,:);

    fig = figure('Name','Parameter Parallel Map','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    cmap = feval(cfg.visual.colormap, 256);
    colormap(cmap)
    cmin = local_percentile(J_show, 2);
    cmax = local_percentile(J_show, 98);
    if ~isfinite(cmin) || ~isfinite(cmax) || cmax <= cmin
        cmin = min(J_show);
        cmax = max(J_show) + eps;
    end
    clim([cmin cmax])

    for k = n_show:-1:1
        row = color_index(J_show(k), cmin, cmax, size(cmap,1));
        plot(1:D, Z_show(k,:), 'LineWidth', 0.75, 'Color', cmap(row,:));
    end

    z_best = normalize_x(best.x, opt.lb, opt.ub);
    z_best = min(max(z_best, 0), 1);
    plot(1:D, z_best, 'ko-', 'MarkerSize', 6, 'MarkerFaceColor','w','LineWidth',2.0);

    xlim([1 D]);
    ylim([-0.03 1.03]);
    xticks(1:D);
    xticklabels({sim.study.symbol});
    ax.XGrid = 'off';

    ylabel('Normalized Parameter Value [-]',...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    cb = colorbar;
    cb.Color = 'k';
    cb.FontName = cfg.visual.font_name;
    cb.FontSize = cfg.visual.font_size;
    cb.Label.String = 'Lap Time [s]';
    cb.Label.FontName = cfg.visual.font_name;
    cb.Label.FontSize = cfg.visual.label_size;

    title(sprintf('Best %d/%d sampled cases', n_show, numel(J)),...
        'FontName',cfg.visual.font_name,'FontSize',cfg.visual.font_size,'Color','k');

    save_figure(fig, 'parameter_parallel_map.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: multidimensional parameter sensitivity
% =========================================================

function plot_parameter_sensitivity(opt, sim, cfg)

    X = opt.samples_x;
    J = opt.samples_J(:);

    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);

    if isempty(J)
        return
    end

    D = opt.dimension;
    influence = zeros(D,1);
    direction = zeros(D,1);

    for d = 1:D
        xd = X(:,d);
        if std(xd) <= eps || std(J) <= eps
            influence(d) = 0;
            direction(d) = 0;
        else
            C = corrcoef(xd, J);
            c = C(1,2);
            if ~isfinite(c)
                c = 0;
            end
            influence(d) = abs(c);
            direction(d) = sign(c);
        end
    end

    [influence_sorted, idx] = sort(influence, 'ascend');
    labels = {sim.study(idx).symbol};

    fig = figure('Name','Parameter Sensitivity','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    barh(1:D, influence_sorted, 'FaceColor',[0.25 0.25 0.25], 'EdgeColor','none');

    yticks(1:D);
    yticklabels(labels);
    xlim([0 max(1, 1.05*max(influence_sorted))]);

    xlabel('|corr(parameter, lap time)| [-]',...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Study Parameter',...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    for k = 1:D
        d = idx(k);
        if direction(d) > 0
            txt = ' slower when increased';
        elseif direction(d) < 0
            txt = ' faster when increased';
        else
            txt = ' neutral';
        end

        text(influence_sorted(k) + 0.02, k, txt, ...
            'FontName',cfg.visual.font_name,'FontSize',max(12,round(0.65*cfg.visual.font_size)),...
            'Color','k','VerticalAlignment','middle');
    end

    save_figure(fig, 'parameter_sensitivity.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: lap-time distribution
% =========================================================

function plot_laptime_distribution(opt, cfg)

    J = opt.samples_J(:);
    J = J(isfinite(J));

    if numel(J) < 5
        return
    end

    fig = figure('Name','Lap Time Distribution','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    histogram(J, max(12, min(55, round(sqrt(numel(J))))), ...
        'FaceColor',[0.25 0.25 0.25], 'EdgeColor','none');

    xlabel('Lap Time [s]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Count [-]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    save_figure(fig, 'lap_time_distribution.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: design projection plot
% =========================================================

function plot_design_projection(opt, sim, best, cfg)

    X = opt.samples_x;
    J = opt.samples_J(:);

    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);

    if isempty(J) || opt.dimension < 2
        return
    end

    [~, idx] = sort(J, 'ascend');
    n_show = min(numel(J), 800);
    idx = idx(1:n_show);

    fig = figure('Name','Design Space Projection','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    scatter(X(idx,1), X(idx,2), 42, J(idx), 'filled', ...
        'MarkerFaceAlpha',0.75, 'MarkerEdgeColor','none');
    colormap(cfg.visual.colormap)
    apply_safe_clim(J(idx), 2, 98);

    plot(best.x(1), best.x(2), 'ko', 'MarkerSize', 9, ...
        'MarkerFaceColor','w','LineWidth',1.5);

    cb = colorbar;
    cb.Color = 'k';
    cb.FontName = cfg.visual.font_name;
    cb.FontSize = cfg.visual.font_size;
    cb.Label.String = 'Lap Time [s]';
    cb.Label.FontName = cfg.visual.font_name;
    cb.Label.FontSize = cfg.visual.label_size;

    xlabel(sprintf('%s [%s]', sim.study(1).symbol, sim.study(1).unit), ...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel(sprintf('%s [%s]', sim.study(2).symbol, sim.study(2).unit), ...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    title(sprintf('Best %d sampled project candidates', n_show), ...
        'FontName',cfg.visual.font_name,'FontSize',cfg.visual.font_size,'Color','k');

    axis tight
    save_figure(fig, 'design_space_projection.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: best design normalized profile
% =========================================================

function plot_best_design_profile(opt, sim, best, cfg)

    D = opt.dimension;
    if D < 2
        return
    end

    z_best = normalize_x(best.x, opt.lb, opt.ub);
    z_best = min(max(z_best, 0), 1);

    if isfield(sim, 'baseline')
        z_base = normalize_x(sim.baseline.x, opt.lb, opt.ub);
        z_base = min(max(z_base, 0), 1);
    else
        z_base = 0.5*ones(size(z_best));
    end

    fig = figure('Name','Best Design Profile','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    plot(1:D, z_base, 'k--', 'LineWidth', 1.2);
    plot(1:D, z_best, 'ko-', 'MarkerFaceColor','w', 'MarkerSize',7, 'LineWidth',2.0);

    xlim([1 D]);
    ylim([-0.05 1.05]);
    xticks(1:D);
    xticklabels({sim.study.symbol});
    ax.XGrid = 'off';

    ylabel('Normalized Parameter Value [-]', ...
        'FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    leg = legend('Baseline','Optimized','Location','best','Box','off');
    leg.FontSize = cfg.visual.font_size;
    leg.FontName = cfg.visual.font_name;
    set(findall(leg,'Type','text'),'Color',[0 0 0]);

    save_figure(fig, 'best_design_profile.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: color index
% =========================================================

function plot_convergence(opt, cfg)

    J = opt.samples_J(:);
    J_best = cummin(J);

    fig = figure('Name','Optimization Convergence','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on'); box(ax,'on');
    apply_axes_identity(ax, cfg);

    plot((1:numel(J_best))', J_best, 'LineWidth', 1.5, 'Color', [0.1 0.35 0.85]);

    if ~isempty(opt.local_trace)
        Jloc = opt.local_trace(:,2);
        Jloc = Jloc(isfinite(Jloc));
        if ~isempty(Jloc)
            offset = numel(J_best);
            Jloc_best = cummin([J_best(end); Jloc]);
            plot(offset + (0:numel(Jloc))', Jloc_best, ...
                'LineWidth', 1.5, 'Color', [0.85 0.1 0.1]);
        end
    end

    ax.XGrid = 'off';
    xlabel('Evaluation [-]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Best Lap Time [s]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    leg = legend('Coarse search','Local refinement','Location','northeast','Box','off');
    leg.FontSize = cfg.visual.font_size;
    leg.FontName = cfg.visual.font_name;
    set(findall(leg,'Type','text'),'Color',[0 0 0]);

    save_figure(fig, 'optimization_convergence.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: track scalar map
% =========================================================

function plot_track_scalar(track, scalar, fig_name, cb_label, file_name, cfg, limits)

    fig = figure('Name',fig_name,'Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on');
    apply_axes_identity(ax, cfg);

    x_plot = [track.x; track.x(1)];
    y_plot = [track.y; track.y(1)];
    c_plot = [scalar(:); scalar(1)];

    surface([x_plot x_plot],...
            [y_plot y_plot],...
            zeros(numel(x_plot),2),...
            [c_plot c_plot],...
            'FaceColor','none',...
            'EdgeColor','interp',...
            'LineWidth',cfg.visual.track_line_width);

    colormap(cfg.visual.colormap)

    if nargin >= 7 && all(isfinite(limits)) && limits(2) > limits(1)
        clim(limits)
    end

    cb = colorbar;
    cb.Color = 'k';
    cb.FontName = cfg.visual.font_name;
    cb.FontSize = cfg.visual.font_size;
    cb.Label.String = cb_label;
    cb.Label.FontName = cfg.visual.font_name;
    cb.Label.FontSize = cfg.visual.label_size;

    plot(track.x(1), track.y(1), 'ko',...
        'MarkerFaceColor','w',...
        'MarkerSize',10,...
        'LineWidth',1.5);

    text(track.x(1), track.y(1), '  Start',...
        'FontName',cfg.visual.font_name,...
        'FontSize',cfg.visual.font_size,...
        'Color','k');

    xlabel('X [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Y [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    axis equal
    grid on
    axis tight
    apply_map_margin(track, 0.05);

    save_figure(fig, file_name, cfg);
end

%% =========================================================
% LOCAL FUNCTION: constraint map
% =========================================================

function plot_constraint_map(track, r, cfg)

    fig = figure('Name','Track Constraint Regime Map','Color','w','Visible',cfg.visual.figure_visible);
    ax = axes(fig); hold(ax,'on');
    apply_axes_identity(ax, cfg);

    x_plot = [track.x; track.x(1)];
    y_plot = [track.y; track.y(1)];
    c_plot = [r.constraint_code(:); r.constraint_code(1)];

    surface([x_plot x_plot],...
            [y_plot y_plot],...
            zeros(numel(x_plot),2),...
            [c_plot c_plot],...
            'FaceColor','none',...
            'EdgeColor','interp',...
            'LineWidth',cfg.visual.track_line_width);

    colormap(turbo(6))
    clim([1 6])

    cb = colorbar;
    cb.Color = 'k';
    cb.FontName = cfg.visual.font_name;
    cb.FontSize = cfg.visual.font_size;
    cb.Ticks = 1:6;
    cb.TickLabels = {'Motor','Traction','Wheelie','Brake','Corner','Redline'};
    cb.Label.String = 'Constraint Regime';
    cb.Label.FontName = cfg.visual.font_name;
    cb.Label.FontSize = cfg.visual.label_size;

    xlabel('X [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('Y [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    axis equal
    grid on
    axis tight
    apply_map_margin(track, 0.05);

    save_figure(fig, 'track_constraint_regime_map.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: rpm and power plot
% =========================================================

function plot_rpm_power(track, r, cfg)

    fig = figure('Name','RPM and Wheel Power','Color','w','Visible',cfg.visual.figure_visible);

    subplot(2,1,1)
    ax1 = gca; hold(ax1,'on'); box(ax1,'on');
    apply_axes_identity(ax1, cfg);
    plot(track.s, r.rpm, 'LineWidth', 1.2, 'Color', cfg.visual.primary_green);
    ax1.XGrid = 'off';
    xlabel('s [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('RPM [-]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    subplot(2,1,2)
    ax2 = gca; hold(ax2,'on'); box(ax2,'on');
    apply_axes_identity(ax2, cfg);
    plot(track.s, r.P_wheel/1000, 'LineWidth', 1.2, 'Color', [0.15 0.15 0.15]);
    ax2.XGrid = 'off';
    xlabel('s [m]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);
    ylabel('P_{wheel} [kW]','FontSize',cfg.visual.label_size,'FontName',cfg.visual.font_name);

    save_figure(fig, 'rpm_power_profile.pdf', cfg);
end

%% =========================================================
% LOCAL FUNCTION: map margin
% =========================================================

function apply_axes_identity(ax, cfg)

    set(ax,'Color','w','FontName',cfg.visual.font_name,'FontSize',cfg.visual.font_size,...
        'LineWidth',cfg.visual.line_width,'XColor','k','YColor','k');

    grid(ax,'on');
    ax.GridColor = cfg.visual.grid_color;
    ax.GridAlpha = cfg.visual.grid_alpha;
end

%% =========================================================
% LOCAL FUNCTION: save figure
% =========================================================

function save_figure(fig, file_name, cfg)

    if ~exist(cfg.output_folder, 'dir')
        mkdir(cfg.output_folder);
    end
    content_type = 'vector';
    if isfield(cfg, 'outputs') && isfield(cfg.outputs, 'figure_content_type') && ~isempty(cfg.outputs.figure_content_type)
        content_type = char(string(cfg.outputs.figure_content_type));
    end
    exportgraphics(fig, fullfile(cfg.output_folder, file_name),...
        'ContentType',content_type,'BackgroundColor','white');
    try
        close(fig);
    catch
    end
end

%% =========================================================
% LOCAL FUNCTION: speed and forces plot
% =========================================================

function idx = color_index(value, cmin, cmax, n)

    if cmax <= cmin || ~isfinite(value)
        idx = 1;
    else
        idx = 1 + round((n-1) * min(max((value - cmin) / (cmax - cmin), 0), 1));
    end
end

%% =========================================================
% LOCAL FUNCTION: safe color limits
% =========================================================

function apply_safe_clim(values, pct_low, pct_high)

    values = values(isfinite(values));

    if isempty(values)
        return
    end

    cmin = local_percentile(values, pct_low);
    cmax = local_percentile(values, pct_high);

    if ~isfinite(cmin) || ~isfinite(cmax) || cmax <= cmin
        cmin = min(values);
        cmax = max(values) + eps;
    end

    clim([cmin cmax])
end

%% =========================================================
% LOCAL FUNCTION: convergence plot
% =========================================================

function apply_map_margin(track, margin)

    xr = max(track.x) - min(track.x);
    yr = max(track.y) - min(track.y);

    if xr <= 0
        xr = 1;
    end
    if yr <= 0
        yr = 1;
    end

    xlim([min(track.x) max(track.x)] + margin*[-1 1]*xr);
    ylim([min(track.y) max(track.y)] + margin*[-1 1]*yr);
end

%% =========================================================
% LOCAL FUNCTION: percentile without toolbox dependency
% =========================================================

function p = local_percentile(x, pct)

    x = x(:);
    x = x(isfinite(x));

    if isempty(x)
        p = NaN;
        return
    end

    x = sort(x);
    pct = min(max(pct, 0), 100);
    pos = 1 + (numel(x)-1)*pct/100;
    lo = floor(pos);
    hi = ceil(pos);

    if lo == hi
        p = x(lo);
    else
        p = x(lo) + (x(hi)-x(lo))*(pos-lo);
    end
end

function z = normalize_x(x, lb, ub)
    z = (x - lb) ./ (ub - lb);
end
