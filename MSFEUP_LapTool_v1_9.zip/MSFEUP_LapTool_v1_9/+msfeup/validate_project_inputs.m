function report = validate_project_inputs(project)
%VALIDATE_PROJECT_INPUTS  Preflight validation for MSFEUP LapTool projects.
%
%   report = msfeup.validate_project_inputs(project)
%
%   This function validates files, MAT payloads, study ranges, physical
%   parameters, power curve data and track data before simulation. It does
%   not change the physical model or any simulation equations.

    report = struct;
    report.ok = true;
    report.messages = strings(0, 1);
    report.errors = strings(0, 1);
    report.warnings = strings(0, 1);
    report.checks = struct;

    try
        project = normalize_local(project);
    catch ME
        report = add_error(report, "Project structure could not be normalized: " + string(ME.message));
        report = finalize_report(report);
        return
    end

    report = validate_required_blocks(report, project);
    if ~report.ok
        report = finalize_report(report);
        return
    end

    report = validate_file_presence(report, project);
    report = validate_physical_parameters(report, project);
    report = validate_track_settings(report, project);
    report = validate_study_definition(report, project);

    if isfile(project.files.power)
        report = validate_power_mat(report, project.files.power, project.vehicle.maxrpm);
    end

    track_available = isfile(project.files.track) || ...
        (isfile(project.files.data) && isfile(project.files.theta) && isfile(project.files.radius));
    if track_available
        report = validate_track_mat(report, project);
    end

    report = finalize_report(report);
end

%% =========================================================
% LOCAL FUNCTION: project normalization
% =========================================================

function project = normalize_local(project)

    if nargin < 1 || isempty(project)
        project = msfeup_default_project();
    end

    if ~isfield(project, 'root') || isempty(project.root)
        project.root = fileparts(fileparts(mfilename('fullpath')));
    end
    if ~isfield(project, 'files') || isempty(project.files)
        project.files = struct;
    end
    if ~isfield(project.files, 'track') || isempty(project.files.track)
        project.files.track = fullfile(project.root, 'MSFEUP_track_input.mat');
    end
    if ~isfield(project.files, 'data') || isempty(project.files.data)
        project.files.data = fullfile(project.root, 'data.mat');
    end
    if ~isfield(project.files, 'theta') || isempty(project.files.theta)
        project.files.theta = fullfile(project.root, 'Theta.mat');
    end
    if ~isfield(project.files, 'radius') || isempty(project.files.radius)
        project.files.radius = fullfile(project.root, 'radius.mat');
    end
    if ~isfield(project.files, 'power') || isempty(project.files.power)
        project.files.power = fullfile(project.root, 'MSFEUP_power_curve.mat');
    end
    if ~isfield(project, 'study')
        project.study = msfeup_empty_study();
    end
end

%% =========================================================
% LOCAL FUNCTION: required blocks
% =========================================================

function report = validate_required_blocks(report, project)

    required = ["files", "vehicle", "operating", "track", "sim", "energy", "analysis", "optim"];
    for i = 1:numel(required)
        block = char(required(i));
        if ~isfield(project, block) || ~isstruct(project.(block))
            report = add_error(report, "Missing or invalid project block: " + required(i));
        end
    end
    report.checks.required_blocks = report.ok;
end

%% =========================================================
% LOCAL FUNCTION: files
% =========================================================

function report = validate_file_presence(report, project)

    n_errors0 = numel(report.errors);

    if ~isfile(project.files.power)
        report = add_error(report, "Missing power MAT: " + string(project.files.power));
    end

    track_ok = isfile(project.files.track);
    legacy_ok = isfile(project.files.data) && isfile(project.files.theta) && isfile(project.files.radius);
    if ~track_ok && ~legacy_ok
        report = add_error(report, "Missing track input. Provide combined track MAT or legacy data/Theta/radius files.");
    elseif ~track_ok && legacy_ok
        report = add_warning(report, "Combined track MAT is missing; it will be rebuilt from legacy files if execution continues.");
    elseif track_ok && ~legacy_ok
        report = add_warning(report, "Legacy track source files are absent. This is acceptable only if the combined track MAT is frozen and valid.");
    end

    optional_assets = ["assets", "outputs"];
    for i = 1:numel(optional_assets)
        block = char(optional_assets(i));
        if ~isfield(project, block)
            report = add_warning(report, "Optional project block is absent: " + optional_assets(i));
        end
    end

    report.checks.files = numel(report.errors) == n_errors0;
end

%% =========================================================
% LOCAL FUNCTION: physical parameters
% =========================================================

function report = validate_physical_parameters(report, project)

    n_errors0 = numel(report.errors);
    v = project.vehicle;
    required = {'g','rho','mass','wb','cgx','cgh','r_wheel','frontA','Cd','Cl','mu','fW','eta','maxrpm'};
    missing = strings(0,1);

    for i = 1:numel(required)
        f = required{i};
        if ~isfield(v, f) || ~isnumeric(v.(f)) || ~isscalar(v.(f)) || ~isfinite(v.(f))
            missing(end+1,1) = string(f); %#ok<AGROW>
        end
    end

    if ~isempty(missing)
        report = add_error(report, "Vehicle fields missing, non-scalar or non-finite: " + strjoin(missing, ", "));
        report.checks.vehicle = false;
        return
    end

    if v.g <= 0 || v.rho <= 0
        report = add_error(report, "Gravity and air density must be positive.");
    end
    if v.mass <= 0
        report = add_error(report, "Vehicle mass must be positive.");
    end
    if v.wb <= 0 || v.r_wheel <= 0 || v.frontA <= 0 || v.cgh <= 0
        report = add_error(report, "Wheelbase, wheel radius, frontal area and CG height must be positive.");
    end
    if v.cgx <= 0 || v.cgx >= v.wb
        report = add_error(report, "cgx must be inside the wheelbase: 0 < cgx < wheelbase.");
    end
    if v.cgh >= v.wb
        report = add_warning(report, "cgh is larger than or comparable to wheelbase; check CG units and geometry.");
    end
    if v.mu <= 0
        report = add_error(report, "mu must be positive.");
    elseif v.mu > 2
        report = add_warning(report, "mu is very high for a tyre-road coefficient; check calibration.");
    end
    if v.Cd < 0
        report = add_error(report, "Cd must be non-negative.");
    elseif v.Cd > 2
        report = add_warning(report, "Cd is unusually high; check aerodynamic input.");
    end
    if abs(v.Cl) > 5
        report = add_warning(report, "Cl magnitude is unusually high; check sign convention and units.");
    end
    if v.eta <= 0 || v.eta > 1
        report = add_error(report, "eta must satisfy 0 < eta <= 1.");
    end
    if v.fW < 0
        report = add_error(report, "Rolling resistance coefficient fW must be non-negative.");
    end
    if v.maxrpm <= 0
        report = add_error(report, "maxrpm must be positive.");
    end

    if isfield(v, 'track_width')
        if ~isnumeric(v.track_width) || ~isscalar(v.track_width) || ~isfinite(v.track_width) || v.track_width <= 0
            report = add_error(report, "track_width is present but not a positive finite scalar.");
        end
    else
        report = add_warning(report, "Optional field vehicle.track_width is absent; lateral load-transfer checks are limited.");
    end

    if ~isfield(project.operating, 'gear_ratio') || ~isnumeric(project.operating.gear_ratio) || ...
            ~isscalar(project.operating.gear_ratio) || ~isfinite(project.operating.gear_ratio) || ...
            project.operating.gear_ratio <= 0
        report = add_error(report, "Operating gear_ratio must be a positive finite scalar.");
    end

    report.checks.vehicle = numel(report.errors) == n_errors0;
end

%% =========================================================
% LOCAL FUNCTION: track settings
% =========================================================

function report = validate_track_settings(report, project)

    n_errors0 = numel(report.errors);
    t = project.track;
    required = {'ds','smooth_len_xy','curv_half_len','smooth_len_k','straight_radius_threshold','max_closure_warning_m'};
    local_missing = false;

    for i = 1:numel(required)
        f = required{i};
        if ~isfield(t, f) || ~isnumeric(t.(f)) || ~isscalar(t.(f)) || ~isfinite(t.(f))
            report = add_error(report, "Track setting missing or non-finite: " + string(f));
            local_missing = true;
        end
    end

    if local_missing
        report.checks.track_settings = false;
        return
    end

    if t.ds <= 0
        report = add_error(report, "Track ds must be positive.");
    elseif t.ds > 2
        report = add_warning(report, "Track ds is coarse; lap-time and curvature resolution may degrade.");
    end

    if t.smooth_len_xy < 0 || t.curv_half_len <= 0 || t.smooth_len_k < 0
        report = add_error(report, "Track smoothing lengths must be non-negative, and curv_half_len must be positive.");
    end

    if t.straight_radius_threshold <= 0
        report = add_error(report, "straight_radius_threshold must be positive.");
    end

    if t.max_closure_warning_m < 0
        report = add_error(report, "max_closure_warning_m must be non-negative.");
    end

    report.checks.track_settings = numel(report.errors) == n_errors0;
end

%% =========================================================
% LOCAL FUNCTION: study definition
% =========================================================

function report = validate_study_definition(report, project)

    n_errors0 = numel(report.errors);
    study = project.study;
    if isempty(study)
        report.checks.study = true;
        return
    end

    ids = strings(numel(study), 1);
    baseline = zeros(numel(study), 1);

    for i = 1:numel(study)
        if ~isfield(study(i), 'id') || isempty(study(i).id)
            report = add_error(report, "Study entry " + string(i) + " has no id.");
            continue
        end

        ids(i) = string(study(i).id);

        if ~isfield(study(i), 'range') || ~isnumeric(study(i).range) || numel(study(i).range) ~= 2
            report = add_error(report, "Study range is invalid for parameter: " + ids(i));
            continue
        end

        range = double(study(i).range(:)');
        if any(~isfinite(range))
            report = add_error(report, "Study range contains NaN or Inf for parameter: " + ids(i));
            continue
        end
        if range(2) <= range(1)
            report = add_error(report, "Study range upper limit must be greater than lower limit for parameter: " + ids(i));
            continue
        end

        id = char(ids(i));
        if ~is_known_study_id(id, project.vehicle, project.operating)
            report = add_error(report, "Unknown study parameter id: " + ids(i));
            continue
        end

        baseline(i) = baseline_value_for_id(id, project.vehicle, project.operating, range);
        if baseline(i) < range(1) || baseline(i) > range(2)
            report = add_warning(report, "Baseline value for " + ids(i) + " is outside tested range.");
        end

        report = validate_range_plausibility(report, id, range);
    end

    valid_ids = ids(ids ~= "");
    if numel(unique(valid_ids)) ~= numel(valid_ids)
        report = add_error(report, "Repeated study parameter id.");
    end

    if any(valid_ids == "mass") && numel(valid_ids) > 1
        report = add_warning(report, "mass is included in a multi-parameter study. Treat mass first as sensitivity unless explicit optimisation justification is documented.");
    end

    if numel(valid_ids) == 1
        if ~isfield(project.optim, 'grid_1d_points')
            project.optim.grid_1d_points = project.optim.precision;
        end
        if project.optim.grid_1d_points < 5
            report = add_warning(report, "1D grid point count is low; boundary and sensitivity conclusions may be weak.");
        end
    elseif numel(valid_ids) == 2 && project.optim.use_grid_if_2d
        if project.optim.precision < 5
            report = add_warning(report, "2D grid precision is low; optimum location may be grid-limited.");
        end
    elseif numel(valid_ids) > 2
        min_samples = max(30, 8*numel(valid_ids));
        if project.optim.random_samples < min_samples
            report = add_warning(report, "Global sample count is low for study dimension " + string(numel(valid_ids)) + ".");
        end
    end

    report.checks.study = numel(report.errors) == n_errors0;
end

function tf = is_known_study_id(id, vehicle, operating)

    info = msfeup.study_parameter_registry(id);
    tf = info.known;
end

function value = baseline_value_for_id(id, vehicle, operating, range)

    value = msfeup.get_study_parameter_value(id, vehicle, operating, mean(range));
end

function report = validate_range_plausibility(report, id, range)

    info = msfeup.study_parameter_registry(id);
    if ~info.known
        return
    end

    if info.positive_range && range(1) <= 0
        report = add_error(report, "Study range for " + string(id) + " must remain positive.");
    end
    if isfinite(info.min_range) && range(1) < info.min_range
        report = add_error(report, "Study range for " + string(id) + " must be >= " + string(info.min_range) + ".");
    end
    if isfinite(info.max_range) && range(2) > info.max_range
        report = add_error(report, "Study range for " + string(id) + " must be <= " + string(info.max_range) + ".");
    end
    if isfinite(info.warn_abs_range) && max(abs(range)) > info.warn_abs_range
        report = add_warning(report, "Study range for " + string(id) + " is unusually wide.");
    end
end

%% =========================================================
% LOCAL FUNCTION: power MAT
% =========================================================

function report = validate_power_mat(report, file_name, maxrpm)

    n_errors0 = numel(report.errors);

    try
        raw = load(file_name);
    catch ME
        report = add_error(report, "Power MAT could not be loaded: " + string(ME.message));
        return
    end

    [rpm, torque, rpm_name, tq_name] = extract_power_columns(raw);
    if isempty(rpm) || isempty(torque)
        report = add_error(report, "Power MAT does not contain identifiable RPM and torque columns.");
        return
    end

    rpm = rpm(:);
    torque = torque(:);
    if numel(rpm) ~= numel(torque) || numel(rpm) < 3
        report = add_error(report, "Power curve must contain at least three matching RPM/torque points.");
        return
    end

    finite = isfinite(rpm) & isfinite(torque);
    if ~all(finite)
        report = add_error(report, "Power curve contains NaN or Inf values.");
        rpm = rpm(finite);
        torque = torque(finite);
    end

    if any(rpm < 0)
        report = add_error(report, "Power curve contains negative RPM values.");
    end
    if any(torque < 0)
        report = add_error(report, "Power curve contains negative torque values.");
    end
    if any(diff(rpm) <= 0)
        report = add_warning(report, "Power curve RPM is not strictly increasing in file order; loader will sort/unique it, but source data should be cleaned.");
    end

    [rpm_sorted, idx_sort] = sort(rpm);
    torque_sorted = torque(idx_sort);
    [rpm_unique, idx_unique] = unique(rpm_sorted, 'stable');
    torque_unique = torque_sorted(idx_unique);

    if numel(rpm_unique) < numel(rpm)
        report = add_warning(report, "Power curve contains repeated RPM points; repeated points will be discarded by the loader.");
    end
    if numel(rpm_unique) < 3 || any(diff(rpm_unique) <= 0)
        report = add_error(report, "Power curve does not provide a usable monotonic RPM axis.");
    end

    omega = rpm_unique * 2*pi/60;
    power = torque_unique .* omega;
    if any(power < 0) || any(~isfinite(power))
        report = add_error(report, "Derived power curve contains negative or non-finite power.");
    end

    if min(rpm_unique) > 0
        report = add_warning(report, "Power curve does not start at 0 rpm; interpolation below first point will be extrapolated/filled.");
    end
    if max(rpm_unique) < maxrpm
        report = add_warning(report, "Power curve maximum RPM is below vehicle.maxrpm; high-RPM region will have zero extrapolated torque.");
    end
    if ~contains(lower(string(rpm_name)), "rpm")
        report = add_warning(report, "Power speed column name does not explicitly document rpm units.");
    end
    if ~(contains(lower(string(tq_name)), "nm") || contains(lower(string(tq_name)), "torque"))
        report = add_warning(report, "Power torque column name does not clearly document Nm units.");
    end

    report.checks.power_mat = numel(report.errors) == n_errors0;
end

function [rpm, torque, rpm_name, tq_name] = extract_power_columns(raw)

    fn = fieldnames(raw);
    rpm = [];
    torque = [];
    rpm_name = '';
    tq_name = '';

    for i = 1:numel(fn)
        obj = raw.(fn{i});

        if istable(obj)
            names = obj.Properties.VariableNames;
            rpm_name = find_name(names, {'MotorSpeed_rpm_','Speed1','Speed','RPM','rpm'});
            tq_name  = find_name(names, {'Torque_Nm_','Torque1','Torque','Tq','torque'});
            if ~isempty(rpm_name) && ~isempty(tq_name)
                rpm = obj.(rpm_name);
                torque = obj.(tq_name);
                return
            end
        elseif isstruct(obj)
            names = fieldnames(obj);
            rpm_name = find_name(names, {'MotorSpeed_rpm_','Speed1','Speed','RPM','rpm'});
            tq_name  = find_name(names, {'Torque_Nm_','Torque1','Torque','Tq','torque'});
            if ~isempty(rpm_name) && ~isempty(tq_name)
                rpm = obj.(rpm_name);
                torque = obj.(tq_name);
                return
            end
        end
    end
end

function name = find_name(names, candidates)

    name = '';
    for i = 1:numel(candidates)
        idx = find(strcmp(names, candidates{i}), 1, 'first');
        if ~isempty(idx)
            name = names{idx};
            return
        end
    end
end

%% =========================================================
% LOCAL FUNCTION: track MAT
% =========================================================

function report = validate_track_mat(report, project)

    n_errors0 = numel(report.errors);

    try
        trackInput = msfeup.load_track_input(project);
    catch ME
        report = add_error(report, "Track MAT could not be loaded/rebuilt: " + string(ME.message));
        return
    end

    required = {'M','thetadata','teste'};
    local_missing = false;
    for i = 1:numel(required)
        if ~isfield(trackInput, required{i})
            report = add_error(report, "Track MAT missing required variable: " + string(required{i}));
            local_missing = true;
        end
    end
    if local_missing
        return
    end

    M = trackInput.M;
    thetadata = trackInput.thetadata;
    teste = trackInput.teste;

    if ~has_table_field(M, 'LATITUDE') || ~has_table_field(M, 'LONGITUDE')
        report = add_error(report, "Track M must contain LATITUDE and LONGITUDE.");
        return
    end
    if ~has_table_field(thetadata, 'xPosition_m_') || ~has_table_field(thetadata, 'Theta_rad_')
        report = add_error(report, "thetadata must contain xPosition_m_ and Theta_rad_.");
        return
    end
    if ~has_table_field(teste, 'distance') || ~has_table_field(teste, 'rad')
        report = add_error(report, "teste must contain distance and rad.");
        return
    end

    lat = M.LATITUDE(:);
    lon = M.LONGITUDE(:);
    theta_pos = thetadata.xPosition_m_(:);
    theta_rad = thetadata.Theta_rad_(:);
    radius_pos = teste.distance(:);
    radius_val = teste.rad(:);

    if numel(lat) < 5 || numel(lon) < 5
        report = add_error(report, "Track GPS data contains too few points.");
        return
    end

    local_bad_data = false;
    if any(~isfinite(lat)) || any(~isfinite(lon))
        report = add_error(report, "Track GPS data contains NaN or Inf.");
        local_bad_data = true;
    end
    if any(~isfinite(theta_pos)) || any(~isfinite(theta_rad))
        report = add_error(report, "Track theta data contains NaN or Inf.");
        local_bad_data = true;
    end
    if any(~isfinite(radius_pos)) || any(~isfinite(radius_val))
        report = add_error(report, "Track radius/curvature source data contains NaN or Inf.");
        local_bad_data = true;
    end

    if any(hypot(diff(lat), diff(lon)) == 0)
        report = add_warning(report, "Track GPS data contains consecutive duplicated points.");
    end
    if any(diff(theta_pos(isfinite(theta_pos))) <= 0)
        report = add_warning(report, "thetadata xPosition_m_ is not strictly increasing in file order.");
    end
    if any(diff(radius_pos(isfinite(radius_pos))) <= 0)
        report = add_warning(report, "teste.distance is not strictly increasing in file order.");
    end

    raw_length = approximate_gps_length(lat, lon);
    closure_gap = approximate_gps_closure(lat, lon);
    if raw_length <= 0 || ~isfinite(raw_length)
        report = add_error(report, "Raw GPS track length is not positive.");
        local_bad_data = true;
    elseif closure_gap > max(project.track.max_closure_warning_m, 0.03*raw_length)
        report = add_warning(report, "Track is not closed within tolerance; closure gap is " + string(sprintf('%.2f', closure_gap)) + " m.");
    end

    if local_bad_data
        report.checks.track_mat = false;
        return
    end

    try
        cfg = msfeup.default_config();
        cfg = msfeup.apply_project_to_cfg(cfg, project);
        [xpos, R_file, theta] = msfeup.distance(M.LATITUDE, M.LONGITUDE, teste.distance, ...
            teste.rad, thetadata.xPosition_m_, thetadata.Theta_rad_, cfg.ds);
        track = msfeup.build_gps_track(M.LATITUDE, M.LONGITUDE, xpos, theta, R_file, cfg);
    catch ME
        report = add_error(report, "Track preflight parametrization failed: " + string(ME.message));
        report.checks.track_mat = false;
        return
    end

    if track.length <= 0 || ~isfinite(track.length)
        report = add_error(report, "Parametrized track length is not positive.");
    end
    if any(~isfinite(track.kappa))
        report = add_error(report, "Parametrized track curvature contains NaN or Inf.");
    end
    if any(track.ds_vec <= 0) || any(~isfinite(track.ds_vec))
        report = add_error(report, "Parametrized track contains non-positive or non-finite segments.");
    end
    if min(track.ds_vec) < 1e-6
        report = add_warning(report, "Parametrized track contains almost-null segments.");
    end
    if track.N < 20
        report = add_warning(report, "Parametrized track has few points; results may be resolution-limited.");
    end

    report.checks.track_mat = numel(report.errors) == n_errors0;
end

function tf = has_table_field(obj, name)

    if istable(obj)
        tf = any(strcmp(obj.Properties.VariableNames, name));
    elseif isstruct(obj)
        tf = isfield(obj, name);
    else
        tf = false;
    end
end

function L = approximate_gps_length(lat, lon)

    lat = lat(:);
    lon = lon(:);
    valid = isfinite(lat) & isfinite(lon);
    lat = lat(valid);
    lon = lon(valid);

    if numel(lat) < 2
        L = NaN;
        return
    end

    rt_earth = 6371000;
    latr = deg2rad(lat);
    lonr = deg2rad(lon);
    dlat = diff(latr);
    dlon = diff(lonr);
    a = sin(dlat/2).^2 + cos(latr(1:end-1)).*cos(latr(2:end)).*sin(dlon/2).^2;
    c = 2 * asin(sqrt(a));
    L = sum(rt_earth*c);
end

function gap = approximate_gps_closure(lat, lon)

    lat = lat(:);
    lon = lon(:);
    valid = isfinite(lat) & isfinite(lon);
    lat = lat(valid);
    lon = lon(valid);

    if numel(lat) < 2
        gap = NaN;
        return
    end

    rt_earth = 6371000;
    lat1 = deg2rad(lat(1));
    lat2 = deg2rad(lat(end));
    lon1 = deg2rad(lon(1));
    lon2 = deg2rad(lon(end));
    dlat = lat2 - lat1;
    dlon = lon2 - lon1;
    a = sin(dlat/2)^2 + cos(lat1)*cos(lat2)*sin(dlon/2)^2;
    gap = rt_earth * 2 * asin(sqrt(a));
end

%% =========================================================
% LOCAL FUNCTION: report helpers
% =========================================================

function report = add_error(report, msg)

    report.ok = false;
    report.errors(end+1, 1) = string(msg);
end

function report = add_warning(report, msg)

    report.warnings(end+1, 1) = string(msg);
end

function report = finalize_report(report)

    report.messages = [report.errors; report.warnings];
    if report.ok
        report.messages(end+1, 1) = "Input validation passed.";
    end
end
