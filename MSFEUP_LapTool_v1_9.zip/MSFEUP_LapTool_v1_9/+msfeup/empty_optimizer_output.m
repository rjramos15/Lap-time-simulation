function opt = empty_optimizer_output()

    opt = struct;
    opt.dimension = 0;
    opt.lb = [];
    opt.ub = [];
    opt.samples_x = [];
    opt.samples_J = [];
    opt.samples_phase = strings(0,1);
    opt.local_trace = [];
    opt.grid = [];
    opt.method = 'single_case';
end
