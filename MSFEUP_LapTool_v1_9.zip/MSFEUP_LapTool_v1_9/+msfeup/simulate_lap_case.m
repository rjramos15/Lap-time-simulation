function [lap_time, result] = simulate_lap_case(x, sim, detailed)

    if nargin < 3
        detailed = false;
    end

    [veh, op] = apply_study_parameters(x, sim);
    validate_vehicle_physics(veh);

    N = sim.N;
    ds_vec = sim.ds_vec;
    theta = sim.theta;
    kappa = sim.kappa;

    g = veh.g;
    rho = veh.rho;
    m = veh.mass;
    wb = veh.wb;
    cgx = veh.cgx;
    cgh = veh.cgh;
    r_wheel = veh.r_wheel;
    frontA = veh.frontA;
    Cd = veh.Cd;
    Cl = veh.Cl;
    mu = veh.mu;
    fW = veh.fW;
    eta = veh.eta;
    maxrpm = veh.maxrpm;

    i_total = op.gear_ratio;

    rpm_step = sim.power.rpm_step;
    torque_grid = sim.power.torque_grid;
    v_max_global = sim.v_max_global;

    v_lim_curve = curve_speed_limit(m, mu, g, theta, kappa, rho, frontA, Cl, v_max_global);
    v_redline = maxrpm * (2*pi*r_wheel) / (60*i_total);

    v = min(v_lim_curve, v_redline);

    for it = 1:sim.nIter
        poll_abort(sim.cfg.progressFcn);
        v_old = v;

        for ii = 0:N-1
            i = N - ii;
            next = i + 1;
            if next > N
                next = 1;
            end

            ds_local = ds_vec(i);
            a_local = (v_old(next)^2 - v_old(i)^2) / (2*ds_local);

            a_brake = brake_acceleration(v(next), a_local, kappa(next), theta(next), veh);
            v_allowed = sqrt(max(v(next)^2 + 2*a_brake*ds_local, 0));

            v(i) = min(v(i), v_allowed);
            v(i) = min(v(i), v_lim_curve(i));
            v(i) = min(v(i), v_redline);
        end

        for i = 1:N
            next = i + 1;
            if next > N
                next = 1;
            end

            ds_local = ds_vec(i);
            a_local = (v_old(next)^2 - v_old(i)^2) / (2*ds_local);

            a_acc = drive_acceleration(v(i), a_local, kappa(i), theta(i), veh, i_total, rpm_step, torque_grid);
            v_allowed = sqrt(max(v(i)^2 + 2*a_acc*ds_local, 0));

            v(next) = min(v(next), v_allowed);
            v(next) = min(v(next), v_lim_curve(next));
            v(next) = min(v(next), v_redline);
        end

        if max(abs(v - v_old)) < sim.tol
            break
        end

        if it == sim.nIter
            error('Simulation did not converge.');
        end
    end

    dt = zeros(N,1);

    for i = 1:N
        next = i + 1;
        if next > N
            next = 1;
        end

        v_avg = 0.5 * (v(i) + v(next));

        if v_avg <= 0 || ~isfinite(v_avg)
            error('Non-positive average speed at segment %d.', i);
        end

        dt(i) = ds_vec(i) / v_avg;
    end

    lap_time = sum(dt);

    if detailed
        result = postprocess_lap(v, v_lim_curve, v_redline, dt, sim.track, veh, op, sim.power, sim.cfg);
    else
        result = [];
    end
end

%% =========================================================
% LOCAL FUNCTION: curve speed limit
% =========================================================

function [vehicle, operating] = apply_study_parameters(x, sim)

    vehicle = sim.vehicle;
    operating = sim.operating;

    for i = 1:numel(sim.study)
        id = sim.study(i).id;
        value = x(i);
        [vehicle, operating] = msfeup.set_study_parameter_value(id, value, vehicle, operating);
    end
end

%% =========================================================
% LOCAL FUNCTION: vehicle physics validation
% =========================================================

function validate_vehicle_physics(veh)

    if veh.mass <= 0 || veh.wb <= 0 || veh.cgh <= 0 || veh.r_wheel <= 0
        error('Invalid positive vehicle geometry/mass parameter.');
    end

    if veh.cgx <= 0 || veh.cgx >= veh.wb
        error('CG longitudinal position must remain inside the wheelbase.');
    end

    if veh.mu <= 0 || veh.frontA <= 0 || veh.Cd < 0 || veh.eta <= 0 || veh.maxrpm <= 0
        error('Invalid aerodynamic, tyre, efficiency or RPM parameter.');
    end
end

%% =========================================================
% LOCAL FUNCTION: lap simulation case
% =========================================================

function v_lim_curve = curve_speed_limit(m, mu, g, theta, kappa, rho, frontA, Cl, v_max_global)

    denom = m .* abs(kappa) + mu * 0.5 * rho * frontA * Cl;
    numer = mu * m * g .* cos(theta);

    v_lim_curve = v_max_global * ones(size(kappa));
    idx = denom > 1e-12 & numer > 0;

    v_lim_curve(idx) = sqrt(numer(idx) ./ denom(idx));
    v_lim_curve(~isfinite(v_lim_curve)) = v_max_global;
    v_lim_curve(v_lim_curve > v_max_global) = v_max_global;
    v_lim_curve(v_lim_curve < 0) = v_max_global;

    if any(~isreal(v_lim_curve))
        error('Complex values appeared in v_lim_curve.');
    end
end

%% =========================================================
% LOCAL FUNCTION: load transfer
% =========================================================

function [Nf, Nr] = compute_load_transfer(~, a_local, theta, veh, F_down)

    g = veh.g;
    m = veh.mass;
    wb = veh.wb;
    cgx = veh.cgx;
    cgh = veh.cgh;

    Nr = max(m*g*cos(theta)*(wb-cgx)/wb + m*a_local*cgh/wb ...
        + F_down*(wb-cgx)/wb, 0);
    Nf = max(m*g*cos(theta)*cgx/wb - m*a_local*cgh/wb ...
        + F_down*cgx/wb, 0);
end

%% =========================================================
% LOCAL FUNCTION: braking acceleration
% =========================================================

function a_brake = brake_acceleration(v, a_local, kappa, theta, veh)

    g = veh.g;
    rho = veh.rho;
    m = veh.mass;
    wb = veh.wb;
    cgx = veh.cgx;
    cgh = veh.cgh;
    frontA = veh.frontA;
    Cd = veh.Cd;
    Cl = veh.Cl;
    mu = veh.mu;
    fW = veh.fW;

    F_down = -0.5 * rho * frontA * Cl * v^2;

    [Nf, Nr] = compute_load_transfer(v, a_local, theta, veh, F_down);

    F_max_f = mu * Nf;
    F_max_r = mu * Nr;
    Ntot = max(Nf + Nr, eps);

    F_lat_total = m * v^2 * abs(kappa);
    F_lat_f = min(F_lat_total * Nf/Ntot, F_max_f);
    F_lat_r = min(F_lat_total * Nr/Ntot, F_max_r);

    F_long_tyre = sqrt(max(F_max_f^2 - F_lat_f^2, 0)) ...
                + sqrt(max(F_max_r^2 - F_lat_r^2, 0));

    F_drag  = 0.5 * rho * frontA * v^2 * Cd;
    F_rr    = fW * m * g * cos(theta);
    F_slope = m * g * sin(theta);

    a_brake_avail = max((F_long_tyre + F_drag + F_rr + F_slope) / m, 0);
    a_stoppie = max(g * (cos(theta) * (wb - cgx) / cgh + sin(theta)) ...
        + F_drag/m + F_rr/m + F_down*(wb-cgx)/(m*cgh), 0);

    a_brake = min(a_brake_avail, a_stoppie);
end

%% =========================================================
% LOCAL FUNCTION: drive acceleration
% =========================================================

function a_acc = drive_acceleration(v, a_local, kappa, theta, veh, i_total, rpm_step, torque_grid)

    g = veh.g;
    rho = veh.rho;
    m = veh.mass;
    wb = veh.wb;
    cgx = veh.cgx;
    cgh = veh.cgh;
    r_wheel = veh.r_wheel;
    frontA = veh.frontA;
    Cd = veh.Cd;
    Cl = veh.Cl;
    mu = veh.mu;
    fW = veh.fW;
    eta = veh.eta;

    F_down = -0.5 * rho * frontA * Cl * v^2;

    [Nf, Nr] = compute_load_transfer(v, a_local, theta, veh, F_down);

    F_max = max(mu * Nr, 0);
    Ntot = max(Nf + Nr, eps);

    F_lat = min((m * v^2 * abs(kappa)) * Nr/Ntot, F_max);
    F_long_tyre = sqrt(max(F_max^2 - F_lat^2, 0));

    rpm = v * i_total * 60 / (r_wheel * 2*pi);
    idx_rpm = round(rpm/rpm_step) + 1;

    if idx_rpm >= 1 && idx_rpm <= numel(torque_grid)
        torque_motor = torque_grid(idx_rpm);
    else
        torque_motor = 0;
    end

    F_motor = torque_motor * i_total * eta / r_wheel;

    F_drag  = 0.5 * rho * frontA * v^2 * Cd;
    F_rr    = fW * m * g * cos(theta);
    F_slope = m * g * sin(theta);

    F_drive = min(F_motor, F_long_tyre);

    a_drive = (F_drive - F_drag - F_rr - F_slope) / m;
    a_wheelie = g * ((cgx / cgh) * cos(theta) - sin(theta)) ...
        - F_drag/m - F_rr/m + F_down*cgx/(m*cgh);

    a_acc = min(a_drive, a_wheelie);
end

%% =========================================================
% LOCAL FUNCTION: detailed post-processing
% =========================================================

function result = postprocess_lap(v, v_lim_curve, v_redline, dt, track, veh, op, power, cfg)

    N = track.N;
    ds_vec = track.ds_vec;
    theta = track.theta;
    kappa = track.kappa;

    g = veh.g;
    rho = veh.rho;
    m = veh.mass;
    wb = veh.wb;
    cgx = veh.cgx;
    cgh = veh.cgh;
    r_wheel = veh.r_wheel;
    frontA = veh.frontA;
    Cd = veh.Cd;
    Cl = veh.Cl;
    mu = veh.mu;
    fW = veh.fW;
    eta = veh.eta;

    i_total = op.gear_ratio;
    rpm_step = power.rpm_step;
    torque_grid = power.torque_grid;

    ax = zeros(N,1);
    ay = zeros(N,1);
    rpm = zeros(N,1);
    torque_motor = zeros(N,1);
    F_motor = zeros(N,1);
    F_drive = zeros(N,1);
    F_available = zeros(N,1);
    F_drag = zeros(N,1);
    F_down = zeros(N,1);
    F_rr = zeros(N,1);
    F_slope = zeros(N,1);
    F_lat = zeros(N,1);
    F_max = zeros(N,1);
    P_wheel = zeros(N,1);
    E_seg = zeros(N,1);
    constraint_code = zeros(N,1);

    for i = 1:N
        next = i + 1;
        if next > N
            next = 1;
        end

        ds_local = ds_vec(i);
        ax(i) = (v(next)^2 - v(i)^2) / (2*ds_local);
        ay(i) = v(i)^2 * kappa(i);

        F_down(i) = -0.5 * rho * frontA * Cl * v(i)^2;

        [Nf, Nr] = compute_load_transfer(v(i), ax(i), theta(i), veh, F_down(i));

        rpm(i) = v(i) * i_total * 60 / (r_wheel * 2*pi);
        idx_rpm = round(rpm(i)/rpm_step) + 1;

        if idx_rpm >= 1 && idx_rpm <= numel(torque_grid)
            torque_motor(i) = torque_grid(idx_rpm);
        else
            torque_motor(i) = 0;
        end

        F_motor(i) = torque_motor(i) * i_total * eta / r_wheel;
        F_drag(i)  = 0.5 * rho * frontA * v(i)^2 * Cd;
        F_rr(i)    = fW * m * g * cos(theta(i));
        F_slope(i) = m * g * sin(theta(i));

        Ntot = max(Nf + Nr, eps);

        if ax(i) < 0
            F_max_f = mu * Nf;
            F_max_r = mu * Nr;
            F_lat_f = min((m * v(i)^2 * abs(kappa(i))) * Nf/Ntot, F_max_f);
            F_lat_r = min((m * v(i)^2 * abs(kappa(i))) * Nr/Ntot, F_max_r);

            F_available(i) = sqrt(max(F_max_f^2 - F_lat_f^2, 0)) ...
                + sqrt(max(F_max_r^2 - F_lat_r^2, 0));

            F_lat(i) = F_lat_f + F_lat_r;
            F_max(i) = F_max_f + F_max_r;
            F_drive(i) = 0;
            constraint_code(i) = 4; % braking
        else
            F_max(i) = max(mu * Nr, 0);
            F_lat(i) = min((m * v(i)^2 * abs(kappa(i))) * Nr/Ntot, F_max(i));
            F_available(i) = sqrt(max(F_max(i)^2 - F_lat(i)^2, 0));
            F_drive(i) = min(F_motor(i), F_available(i));

            a_drive = (F_drive(i) - F_drag(i) - F_rr(i) - F_slope(i)) / m;
            a_wheelie = g * ((cgx / cgh) * cos(theta(i)) - sin(theta(i))) ...
                - F_drag(i)/m - F_rr(i)/m + F_down(i)*cgx/(m*cgh);

            if abs(v(i) - v_redline) < 0.05
                constraint_code(i) = 6; % redline
            elseif abs(v(i) - v_lim_curve(i)) < 0.05
                constraint_code(i) = 5; % lateral/corner limit
            elseif a_wheelie <= a_drive
                constraint_code(i) = 3; % wheelie limited
            elseif F_motor(i) <= F_available(i)
                constraint_code(i) = 1; % motor limited
            else
                constraint_code(i) = 2; % traction limited
            end
        end

        P_wheel(i) = F_drive(i) * v(i);

        if F_drive(i) > 0
            E_seg(i) = F_drive(i) * ds_local;
        elseif ax(i) < 0
            E_seg(i) = -abs(F_available(i)) * ds_local * cfg.energy.eta_regen;
        end
    end

    result = struct;
    result.v = v;
    result.v_lim_curve = v_lim_curve;
    result.v_redline = v_redline;
    result.dt = dt;
    result.ax = ax;
    result.ay = ay;
    result.ax_g = ax / g;
    result.ay_g = ay / g;
    result.rpm = rpm;
    result.torque_motor = torque_motor;
    result.F_motor = F_motor;
    result.F_drive = F_drive;
    result.F_available = F_available;
    result.F_drag = F_drag;
    result.F_down = F_down;
    result.F_rr = F_rr;
    result.F_slope = F_slope;
    result.F_lat = F_lat;
    result.F_max = F_max;
    result.P_wheel = P_wheel;
    result.E_seg = E_seg;
    result.constraint_code = constraint_code;
    result.lap_time = sum(dt);
end

%% =========================================================
% LOCAL FUNCTION: summary
% =========================================================
