function cfg = default_config()

    cfg = struct;

    cfg.ds = 0.5;
    cfg.output_folder = 'plots';
    cfg.results_folder = 'results';
    cfg.progressFcn = [];

    cfg.outputs.export_level = 'light';
    cfg.outputs.auto_export = false;
    cfg.outputs.write_summary = false;
    cfg.outputs.export_velocity_profile = false;
    cfg.outputs.export_force_profile = true;
    cfg.outputs.export_figures = false;
    cfg.outputs.write_csv = false;
    cfg.outputs.write_archive = false;
    cfg.outputs.write_diagnostics_files = false;
    cfg.outputs.figure_content_type = 'vector';

    cfg.visual.font_name = 'Times';
    cfg.visual.font_size = 25;
    cfg.visual.label_size = 30;
    cfg.visual.line_width = 1;
    cfg.visual.track_line_width = 7;
    cfg.visual.grid_color = [0.82 0.82 0.82];
    cfg.visual.grid_alpha = 0.30;
    cfg.visual.colormap = 'turbo';
    cfg.visual.primary_green = [0 154 0] / 255;
    cfg.visual.figure_visible = 'off';

    cfg.optim.grid_1d_points = 80;
    cfg.optim.precision = 36;
    cfg.optim.use_grid_if_2d = true;
    cfg.optim.random_samples = 1800;
    cfg.optim.top_starts = 12;
    cfg.optim.local_initial_step = 0.18;
    cfg.optim.local_step_reduction = 0.52;
    cfg.optim.local_tol_step = 2.5e-4;
    cfg.optim.local_max_eval = 260;
    cfg.optim.simplex_enabled = true;
    cfg.optim.simplex_max_eval = 180;
    cfg.optim.rng_seed = 7;
    cfg.optim.waitbar = false;
    cfg.optim.adaptive_rounds = 3;
    cfg.optim.adaptive_samples = 560;
    cfg.optim.adaptive_elite_fraction = 0.08;
    cfg.optim.adaptive_radius = 0.22;
    cfg.optim.adaptive_radius_decay = 0.55;
    cfg.optim.halton_skip = 120;
    cfg.optim.checkpoint_enabled = false;
    cfg.optim.checkpoint_interval = 250;
    cfg.optim.debug_objective = false;

    cfg.sim.v_max_global = 300/3.6;
    cfg.sim.nIter = 70;
    cfg.sim.tol = 1e-4;

    cfg.track.smooth_len_xy = 14;
    cfg.track.curv_half_len = 10;
    cfg.track.smooth_len_k = 12;
    cfg.track.straight_radius_threshold = 4000;
    cfg.track.max_closure_warning_m = 30;

    cfg.energy.n_laps = 6;
    cfg.energy.safety_coeff = 1.25;
    cfg.energy.usable_fraction = 0.85;
    cfg.energy.eta_regen = 0;
    cfg.energy.plot_capacity_kWh = 6.5;

    cfg.analysis.corner_kappa_threshold = 1/4000;
    cfg.analysis.min_section_length = 15;

    cfg.sensitivity.points_per_variable = 80;
    cfg.sensitivity.include_bounds = true;

    cfg.study = msfeup_empty_study();
end
