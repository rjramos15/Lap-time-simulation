function trackInput = load_track_input(project)

    project = normalize_project_files(project);
    track_file = project.files.track;

    if isfile(track_file)
        raw = load(track_file);
        if isfield(raw, 'M') && isfield(raw, 'thetadata') && isfield(raw, 'teste')
            trackInput = raw;
            trackInput.source_file = track_file;
            return
        end
        warning('Combined track MAT exists but does not contain M, thetadata and teste. Rebuilding from legacy files.');
    end

    if isfile(project.files.data) && isfile(project.files.theta) && isfile(project.files.radius)
        build_file = track_file;
        if isdeployed
            build_file = fullfile(prefdir, 'MSFEUP_LapTool', 'MSFEUP_track_input.mat');
        end
        msfeup_build_track_input_mat(build_file, project.files.data, project.files.theta, project.files.radius);
        raw = load(build_file);
        trackInput = raw;
        trackInput.source_file = build_file;
        return
    end

    error(['Could not load combined track input MAT. Expected %s, or legacy files data.mat, Theta.mat and radius.mat ', ...
           'to rebuild it automatically.'], track_file);
end

%% =========================================================
% LOCAL FUNCTION: compatibility for old project structs
% =========================================================

function project = normalize_project_files(project)

    if ~isfield(project, 'root') || isempty(project.root)
        project.root = fileparts(fileparts(mfilename('fullpath')));
    end
    if ~isfield(project, 'files') || isempty(project.files)
        project.files = struct;
    end
    if ~isfield(project.files, 'track') || isempty(project.files.track)
        project.files.track = fullfile(project.root, 'MSFEUP_track_input.mat');
    end
    if ~isfield(project.files, 'data') || isempty(project.files.data)
        project.files.data = fullfile(project.root, 'data.mat');
    end
    if ~isfield(project.files, 'theta') || isempty(project.files.theta)
        project.files.theta = fullfile(project.root, 'Theta.mat');
    end
    if ~isfield(project.files, 'radius') || isempty(project.files.radius)
        project.files.radius = fullfile(project.root, 'radius.mat');
    end
end
