function write_msfeup_outputs(summary, sections, best, opt, sim, cfg, project, mode)

    if ~exist(cfg.results_folder, 'dir')
        mkdir(cfg.results_folder);
    end

    if should_write_csv(cfg)
        write_full_results_csv(summary, sections, best, opt, sim, cfg, mode);
    end

    if should_write_diagnostics_files(cfg)
        if is_sensitivity_mode(mode)
            write_diagnostics_file(opt, cfg, 'sensitivity_diagnostics.txt', 'MSFEUP SENSITIVITY DIAGNOSTICS');
        elseif mode ~= "single" && isfield(opt, 'diagnostics')
            write_optimizer_diagnostics(opt, cfg);
        end
    end

    if should_write_summary(cfg)
        write_summary_txt(summary, best, opt, sim, cfg, mode);
    end

    if should_write_archive(cfg)
        save(fullfile(cfg.results_folder, 'project_config.mat'), 'project');
        save(fullfile(cfg.results_folder, 'simulation_archive.mat'), ...
            'summary', 'sections', 'best', 'opt', 'sim', 'project', '-v7.3');
    end

    warn_large_outputs(cfg);
end

%% =========================================================
% LOCAL FUNCTION: lap profile table
% =========================================================

function tf = is_sensitivity_mode(mode)

    mode = lower(string(mode));
    tf = mode == "sensitivity" || mode == "sensitivity_analysis";
end

function tf = should_write_csv(cfg)

    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'write_csv') && cfg.outputs.write_csv;
end

function tf = should_write_summary(cfg)

    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'write_summary') && cfg.outputs.write_summary;
end

function tf = should_write_archive(cfg)

    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'write_archive') && cfg.outputs.write_archive;
end

function tf = should_write_diagnostics_files(cfg)

    tf = isfield(cfg, 'outputs') && isfield(cfg.outputs, 'write_diagnostics_files') && cfg.outputs.write_diagnostics_files;
end

function write_summary_txt(summary, best, opt, sim, cfg, mode)

    fid = fopen(fullfile(cfg.results_folder, 'summary.txt'), 'w');
    if fid < 0
        warning('MSFEUP:OutputWrite', 'Could not write summary.txt.');
        return
    end
    cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid, 'MSFEUP MOTORCYCLE LAP SIMULATION SUMMARY\n');
    fprintf(fid, '============================================================\n');
    fprintf(fid, 'Mode:                       %s\n', upper(mode));
    fprintf(fid, 'Final optimum lap-time [s]: %.6f\n', best.lap_time);
    fprintf(fid, 'Summary lap-time [s]:       %.6f\n', summary.lap_time_s);
    if isfield(summary, 'baseline_lap_time_s')
        fprintf(fid, 'Baseline lap-time [s]:      %.6f\n', summary.baseline_lap_time_s);
        fprintf(fid, 'Delta vs baseline [s]:      %.6f\n', summary.delta_vs_baseline_s);
        fprintf(fid, 'Improvement vs baseline:    %.4f %%\n', summary.improvement_vs_baseline_pct);
    end
    fprintf(fid, 'Track length [m]:           %.3f\n', summary.track_length_m);
    fprintf(fid, 'Mean speed [km/h]:          %.3f\n', summary.mean_speed_kph);
    fprintf(fid, 'Maximum speed [km/h]:       %.3f\n', summary.max_speed_kph);
    fprintf(fid, 'Minimum speed [km/h]:       %.3f\n', summary.min_speed_kph);
    fprintf(fid, 'Maximum ax [g]:             %.4f\n', summary.max_ax_g);
    fprintf(fid, 'Minimum ax [g]:             %.4f\n', summary.min_ax_g);
    fprintf(fid, 'Maximum |ay| [g]:           %.4f\n', summary.max_abs_ay_g);
    fprintf(fid, 'Energy per lap [kWh]:       %.6f\n', summary.energy_per_lap_kWh);
    fprintf(fid, 'Total energy [kWh]:         %.6f\n', summary.total_energy_kWh);
    fprintf(fid, 'Battery capacity [kWh]:     %.6f\n', summary.battery_capacity_kWh);
    fprintf(fid, 'Peak wheel power [kW]:      %.3f\n', summary.peak_power_kW);
    fprintf(fid, 'Average wheel power [kW]:   %.3f\n', summary.average_power_kW);

    if ~isempty(sim.study) && ~isempty(best.x)
        if is_sensitivity_mode(mode)
            fprintf(fid, '\nBASELINE STUDY PARAMETERS\n');
        else
            fprintf(fid, '\nFINAL OPTIMUM PARAMETERS\n');
        end
        for i = 1:min(numel(sim.study), numel(best.x))
            fprintf(fid, '%s [%s]: %.12g\n', sim.study(i).name, sim.study(i).unit, best.x(i));
        end
    end

    if isfield(opt, 'diagnostics') && isfield(opt.diagnostics, 'warnings') && ~isempty(opt.diagnostics.warnings)
        fprintf(fid, '\nDIAGNOSTIC WARNINGS\n');
        for i = 1:numel(opt.diagnostics.warnings)
            fprintf(fid, '- %s\n', char(opt.diagnostics.warnings(i)));
        end
    end
end

function write_full_results_csv(summary, sections, best, opt, sim, cfg, mode)

    record_type = strings(0,1);
    idx = zeros(0,1);
    metric = strings(0,1);
    value = nan(0,1);
    unit = strings(0,1);
    s_m = nan(0,1);
    x_m = nan(0,1);
    y_m = nan(0,1);
    curvature_1pm = nan(0,1);
    velocity_kph = nan(0,1);
    ax_g = nan(0,1);
    ay_g = nan(0,1);
    rpm = nan(0,1);
    wheel_power_kW = nan(0,1);
    constraint_code = nan(0,1);
    parameter = strings(0,1);
    parameter_value = nan(0,1);
    phase = strings(0,1);
    lap_time_s = nan(0,1);

    add_metric("mode", NaN, char(string(mode)));
    add_metric("final_optimum_lap_time_s", best.lap_time, "s");
    add_metric("summary_lap_time_s", summary.lap_time_s, "s");

    preferred = {'track_length_m','mean_speed_kph','max_speed_kph','min_speed_kph', ...
        'max_ax_g','min_ax_g','max_abs_ay_g','energy_per_lap_kWh','total_energy_kWh', ...
        'battery_capacity_kWh','peak_power_kW','average_power_kW','baseline_lap_time_s', ...
        'delta_vs_baseline_s','improvement_vs_baseline_pct'};
    for ii = 1:numel(preferred)
        f = preferred{ii};
        if isfield(summary, f)
            add_metric(f, summary.(f), "");
        end
    end

    if ~isempty(sim.study) && ~isempty(best.x)
        for ii = 1:min(numel(sim.study), numel(best.x))
            add_empty_row("best_parameter");
            parameter(end) = string(sim.study(ii).id);
            parameter_value(end) = best.x(ii);
            metric(end) = string(sim.study(ii).name);
            unit(end) = string(sim.study(ii).unit);
        end
    end

    tr = sim.track;
    r = best.result;
    n = min([numel(tr.s), numel(tr.x), numel(tr.y), numel(tr.kappa), numel(r.v), ...
        numel(r.ax_g), numel(r.ay_g), numel(r.rpm), numel(r.P_wheel), numel(r.constraint_code)]);
    for ii = 1:n
        add_empty_row("lap_profile");
        idx(end) = ii;
        s_m(end) = tr.s(ii);
        x_m(end) = tr.x(ii);
        y_m(end) = tr.y(ii);
        curvature_1pm(end) = tr.kappa(ii);
        velocity_kph(end) = r.v(ii) * 3.6;
        ax_g(end) = r.ax_g(ii);
        ay_g(end) = r.ay_g(ii);
        rpm(end) = r.rpm(ii);
        wheel_power_kW(end) = r.P_wheel(ii) / 1000;
        constraint_code(end) = r.constraint_code(ii);
    end

    if istable(sections) && height(sections) > 0
        vars = sections.Properties.VariableNames;
        for ii = 1:height(sections)
            for vv = 1:numel(vars)
                add_empty_row("track_section");
                idx(end) = ii;
                metric(end) = string(vars{vv});
                v = sections.(vars{vv})(ii);
                if isnumeric(v) || islogical(v)
                    value(end) = double(v);
                else
                    unit(end) = string(v);
                end
            end
        end
    end

    if isfield(opt, 'samples_J') && ~isempty(opt.samples_J) && isfield(opt, 'samples_x')
        J = opt.samples_J(:);
        X = opt.samples_x;
        valid = isfinite(J) & all(isfinite(X),2);
        J = J(valid);
        X = X(valid,:);
        phase_valid = strings(numel(J),1);
        if isfield(opt, 'samples_phase') && numel(opt.samples_phase) >= numel(valid)
            tmp = opt.samples_phase(valid);
            phase_valid = string(tmp(:));
        end
        for ii = 1:numel(J)
            for dd = 1:max(1, size(X,2))
                add_empty_row("optimization_sample");
                idx(end) = ii;
                lap_time_s(end) = J(ii);
                phase(end) = phase_valid(ii);
                if size(X,2) >= dd
                    parameter_value(end) = X(ii,dd);
                    if numel(sim.study) >= dd
                        parameter(end) = string(sim.study(dd).id);
                    else
                        parameter(end) = "x" + string(dd);
                    end
                end
            end
        end
    end

    T = table(record_type, idx, metric, value, unit, s_m, x_m, y_m, curvature_1pm, ...
        velocity_kph, ax_g, ay_g, rpm, wheel_power_kW, constraint_code, ...
        parameter, parameter_value, phase, lap_time_s);
    writetable(T, fullfile(cfg.results_folder, 'full_results.csv'));

    function add_empty_row(type_text)
        record_type(end+1,1) = string(type_text);
        idx(end+1,1) = numel(idx) + 1;
        metric(end+1,1) = "";
        value(end+1,1) = NaN;
        unit(end+1,1) = "";
        s_m(end+1,1) = NaN;
        x_m(end+1,1) = NaN;
        y_m(end+1,1) = NaN;
        curvature_1pm(end+1,1) = NaN;
        velocity_kph(end+1,1) = NaN;
        ax_g(end+1,1) = NaN;
        ay_g(end+1,1) = NaN;
        rpm(end+1,1) = NaN;
        wheel_power_kW(end+1,1) = NaN;
        constraint_code(end+1,1) = NaN;
        parameter(end+1,1) = "";
        parameter_value(end+1,1) = NaN;
        phase(end+1,1) = "";
        lap_time_s(end+1,1) = NaN;
    end

    function add_metric(name, val, unit_text)
        add_empty_row("summary");
        metric(end) = string(name);
        value(end) = val;
        unit(end) = string(unit_text);
    end
end

function write_sensitivity_outputs(opt, cfg)

    if ~isfield(opt, 'sensitivity')
        return
    end

    if isfield(opt.sensitivity, 'points') && ~isempty(opt.sensitivity.points)
        writetable(opt.sensitivity.points, fullfile(cfg.results_folder, 'sensitivity_points.csv'));
    end

    if isfield(opt.sensitivity, 'summary') && ~isempty(opt.sensitivity.summary)
        writetable(opt.sensitivity.summary, fullfile(cfg.results_folder, 'sensitivity_summary.csv'));

        fid = fopen(fullfile(cfg.results_folder, 'sensitivity_summary.txt'), 'w');
        if fid >= 0
            cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
            fprintf(fid, 'MSFEUP ONE-AT-A-TIME SENSITIVITY SUMMARY\n');
            fprintf(fid, '============================================================\n');
            S = opt.sensitivity.summary;
            for i = 1:height(S)
                fprintf(fid, '%s: effect %.6g s (%.6g %%) | trend: %s | %s\n', ...
                    char(S.variable(i)), S.range_effect_s(i), S.range_effect_pct(i), ...
                    char(S.monotonicity(i)), char(S.note(i)));
            end
        end
    end

    if isfield(opt, 'diagnostics')
        write_diagnostics_file(opt, cfg, 'sensitivity_diagnostics.txt', 'MSFEUP SENSITIVITY DIAGNOSTICS');
    end
end

function write_optimizer_diagnostics(opt, cfg)

    write_diagnostics_file(opt, cfg, 'optimizer_diagnostics.txt', 'MSFEUP OPTIMIZER DIAGNOSTICS');
end

function write_diagnostics_file(opt, cfg, file_base_name, title_text)

    if ~isfield(opt, 'diagnostics')
        return
    end

    file_name = fullfile(cfg.results_folder, file_base_name);
    fid = fopen(file_name, 'w');
    if fid < 0
        warning('MSFEUP:OutputWrite', 'Could not write diagnostics file: %s.', file_name);
        return
    end

    cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

    fprintf(fid, '%s\n', title_text);
    fprintf(fid, '============================================================\n');

    if isfield(opt.diagnostics, 'warnings') && ~isempty(opt.diagnostics.warnings)
        fprintf(fid, '\nWarnings\n');
        for i = 1:numel(opt.diagnostics.warnings)
            fprintf(fid, '- %s\n', char(opt.diagnostics.warnings(i)));
        end
    else
        fprintf(fid, '\nNo diagnostic warnings.\n');
    end

    if isfield(opt.diagnostics, 'boundary') && ~isempty(opt.diagnostics.boundary)
        fprintf(fid, '\nBoundary-limited candidates\n');
        for i = 1:numel(opt.diagnostics.boundary)
            b = opt.diagnostics.boundary(i);
            fprintf(fid, '- %s at %s boundary: value %.12g, limit %.12g, normalized distance %.6g\n', ...
                b.id, b.side, b.value, b.limit, b.distance_fraction);
            if isfield(b, 'suggested_range') && numel(b.suggested_range) == 2
                fprintf(fid, '  suggested retest range: [%.12g, %.12g]\n', ...
                    b.suggested_range(1), b.suggested_range(2));
            end
        end
    end

    if isfield(opt.diagnostics, 'low_sensitivity') && ~isempty(opt.diagnostics.low_sensitivity)
        fprintf(fid, '\nLow-sensitivity variables\n');
        for i = 1:numel(opt.diagnostics.low_sensitivity)
            s = opt.diagnostics.low_sensitivity(i);
            fprintf(fid, '- %s: quartile median effect %.6g s (%.6g %%)\n', ...
                s.id, s.effect_s, s.effect_pct);
        end
    end

    if isfield(opt.diagnostics, 'improvement') && isfield(opt.diagnostics.improvement, 'delta_s')
        fprintf(fid, '\nBaseline comparison\n');
        fprintf(fid, 'Delta improvement: %.12g s\n', opt.diagnostics.improvement.delta_s);
        fprintf(fid, 'Improvement: %.12g %%\n', opt.diagnostics.improvement.improvement_pct);
    end

    if isfield(opt.diagnostics, 'multistart') && isfield(opt.diagnostics.multistart, 'available') && ...
            opt.diagnostics.multistart.available
        m = opt.diagnostics.multistart;
        fprintf(fid, '\nMulti-start agreement\n');
        fprintf(fid, 'Confidence: %s\n', char(string(m.confidence)));
        fprintf(fid, 'Converged starts: %d / %d within %.12g s\n', m.n_converged, m.n_starts, m.epsilon_s);
        fprintf(fid, 'Refined std: %.12g s\n', m.refined_std_s);
        fprintf(fid, 'Refined range: %.12g s\n', m.refined_range_s);
    end
end

function warn_large_outputs(cfg)

    folders = {cfg.results_folder, cfg.output_folder};
    per_file_limit_bytes = 20 * 1024 * 1024;
    total_limit_bytes = 100 * 1024 * 1024;

    for i = 1:numel(folders)
        folder = folders{i};
        if ~exist(folder, 'dir')
            continue
        end

        files = dir(fullfile(folder, '*'));
        total_bytes = 0;
        for k = 1:numel(files)
            if files(k).isdir
                continue
            end
            total_bytes = total_bytes + files(k).bytes;
            if files(k).bytes > per_file_limit_bytes
                warning('MSFEUP:LargeOutput', 'Large output file: %s (%.1f MB).', ...
                    fullfile(folder, files(k).name), files(k).bytes/1024/1024);
            end
        end

        if total_bytes > total_limit_bytes
            warning('MSFEUP:LargeOutput', 'Output folder is large: %s (%.1f MB).', ...
                folder, total_bytes/1024/1024);
        end
    end
end

function write_summary_metrics(summary, file_name)

    names = fieldnames(summary);
    metric = strings(0,1);
    value = strings(0,1);

    preferred = {'lap_time_s','track_length_m','mean_speed_kph','max_speed_kph','min_speed_kph', ...
        'max_ax_g','min_ax_g','max_abs_ay_g','energy_per_lap_kWh','total_energy_kWh', ...
        'battery_capacity_kWh','peak_power_kW','average_power_kW','baseline_lap_time_s', ...
        'delta_vs_baseline_s','improvement_vs_baseline_pct'};

    for i = 1:numel(preferred)
        f = preferred{i};
        if isfield(summary, f)
            metric(end+1,1) = string(f); %#ok<AGROW>
            value(end+1,1) = string(sprintf('%.12g', summary.(f))); %#ok<AGROW>
        end
    end

    remaining = setdiff(names(:)', preferred, 'stable');
    for i = 1:numel(remaining)
        f = remaining{i};
        v = summary.(f);
        if isnumeric(v) && isscalar(v)
            metric(end+1,1) = string(f); %#ok<AGROW>
            value(end+1,1) = string(sprintf('%.12g', v)); %#ok<AGROW>
        end
    end

    T = table(metric, value);
    writetable(T, file_name);
end

%% =========================================================
% LOCAL FUNCTION: full optimizer sample export
% =========================================================

function write_design_samples(opt, sim, cfg)

    if ~isfield(opt, 'samples_J') || isempty(opt.samples_J)
        return
    end

    X = opt.samples_x;
    J = opt.samples_J(:);
    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);
    if isempty(J)
        return
    end

    T = table(J, 'VariableNames', {'lap_time_s'});
    for d = 1:opt.dimension
        name = matlab.lang.makeValidName(sim.study(d).id);
        T.(name) = X(:,d);
    end

    if isfield(opt, 'samples_phase') && numel(opt.samples_phase) >= numel(valid)
        phase = opt.samples_phase(valid);
        T.phase = phase(:);
    end

    writetable(T, fullfile(cfg.results_folder, 'design_samples.csv'));
end

%% =========================================================
% LOCAL FUNCTION: lap profile table
% =========================================================

function write_lap_profile(track, r, file_name)

    s_m = track.s(:);
    x_m = track.x(:);
    y_m = track.y(:);
    curvature_1pm = track.kappa(:);
    velocity_kph = r.v(:) * 3.6;
    ax_g = r.ax_g(:);
    ay_g = r.ay_g(:);
    rpm = r.rpm(:);
    wheel_power_kW = r.P_wheel(:) / 1000;
    constraint_code = r.constraint_code(:);

    profile = table(s_m, x_m, y_m, curvature_1pm, velocity_kph, ax_g, ay_g, ...
        rpm, wheel_power_kW, constraint_code);

    writetable(profile, file_name);
end

%% =========================================================
% LOCAL FUNCTION: empty optimizer output
% =========================================================

function write_top_candidates(opt, sim, cfg, n_top)

    X = opt.samples_x;
    J = opt.samples_J(:);

    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);

    if isempty(J)
        return
    end

    [J_sorted, idx] = sort(J, 'ascend');
    n_top = min(n_top, numel(J_sorted));
    idx = idx(1:n_top);

    T = table(J_sorted(1:n_top), 'VariableNames', {'lap_time_s'});

    for d = 1:opt.dimension
        name = matlab.lang.makeValidName(sim.study(d).id);
        T.(name) = X(idx,d);
    end

    writetable(T, fullfile(cfg.results_folder, 'top_candidates.csv'));
end

%% =========================================================
% LOCAL FUNCTION: apply axes identity
% =========================================================
