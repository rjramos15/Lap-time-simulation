function ensure_output_folders(cfg)

    if ~exist(cfg.output_folder, 'dir')
        mkdir(cfg.output_folder);
    end
    if ~exist(cfg.results_folder, 'dir')
        mkdir(cfg.results_folder);
    end
end
