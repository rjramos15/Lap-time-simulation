function [xpos, R, theta] = distance(lat, lon, xr, r, pos, rad, ds)

    rt_earth = 6371000;

    lat = lat(:);
    lon = lon(:);
    xr  = xr(:);
    r   = r(:);
    pos = pos(:);
    rad = rad(:);

    latr = deg2rad(lat);
    lonr = deg2rad(lon);

    N = numel(latr);
    d = zeros(N,1);

    for i = 2:N
        dlat = latr(i) - latr(i-1);
        dlon = lonr(i) - lonr(i-1);

        a = sin(dlat/2)^2 + cos(latr(i-1))*cos(latr(i))*sin(dlon/2)^2;
        c = 2 * asin(sqrt(a));
        d(i) = d(i-1) + rt_earth*c;
    end

    xpos = (0:ds:floor(max(d)))';

    r_straight_thr = 1e6;
    r(abs(r) < .1) = inf;
    kappa_raw = zeros(size(r));

    idx_curve = isfinite(r) & abs(r) < r_straight_thr;
    kappa_raw(idx_curve) = 1 ./ r(idx_curve);
    kappa_raw(~isfinite(kappa_raw)) = 0;

    valid_xr = isfinite(xr) & isfinite(kappa_raw);
    xr_k = xr(valid_xr);
    kappa_k = kappa_raw(valid_xr);

    [xr_k, idx_sort] = sort(xr_k);
    kappa_k = kappa_k(idx_sort);

    [xr_k, idx_unique] = unique(xr_k, 'stable');
    kappa_k = kappa_k(idx_unique);

    valid_pos = isfinite(pos) & isfinite(rad);
    pos_t = pos(valid_pos);
    rad_t = rad(valid_pos);

    [pos_t, idx_sort_t] = sort(pos_t);
    rad_t = rad_t(idx_sort_t);

    [pos_t, idx_unique_t] = unique(pos_t, 'stable');
    rad_t = rad_t(idx_unique_t);

    kappa = interp1(xr_k, kappa_k, xpos, 'pchip', 'extrap');
    theta = interp1(pos_t, rad_t, xpos, 'pchip', 'extrap');

    win = max(5, 2*floor(round(5/ds)/2) + 1);

    kappa = smoothdata(kappa, 'sgolay', win);
    theta = smoothdata(theta, 'sgolay', win);

    eps_k = 1e-9;
    R = inf(size(kappa));
    idx_nonzero = abs(kappa) > eps_k;
    R(idx_nonzero) = 1 ./ kappa(idx_nonzero);

    if numel(xpos) ~= numel(R) || numel(R) ~= numel(theta)
        error('Error in Track Parametrization: Different Dimensions');
    end

    disp(' - Original Track Signals Successfully Parametrized');
end
