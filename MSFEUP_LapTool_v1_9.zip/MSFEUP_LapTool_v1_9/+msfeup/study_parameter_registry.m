function info = study_parameter_registry(id)
%STUDY_PARAMETER_REGISTRY  Canonical metadata for tunable study parameters.
%
%   info = msfeup.study_parameter_registry(id) returns the canonical mapping
%   between a study parameter id and the project field it controls. Unknown
%   ids return info.known=false. Keep new study variables centralised here
%   instead of duplicating switch/case logic across solver, optimiser and UI.

    id = char(string(id));

    info = struct;
    info.id = id;
    info.known = true;
    info.owner = '';
    info.field = '';
    info.name = '';
    info.symbol = '';
    info.unit = '';
    info.positive_range = false;
    info.min_range = -inf;
    info.max_range = inf;
    info.warn_abs_range = inf;

    switch id
        case {'gear_ratio','i_total','final_drive'}
            info.id = 'gear_ratio';
            info.owner = 'operating';
            info.field = 'gear_ratio';
            info.name = 'Final Drive Ratio';
            info.symbol = 'i_f';
            info.unit = '-';
            info.positive_range = true;

        case 'mass'
            info.owner = 'vehicle';
            info.field = 'mass';
            info.name = 'Vehicle + Rider Mass';
            info.symbol = 'm';
            info.unit = 'kg';
            info.positive_range = true;

        case 'mu'
            info.owner = 'vehicle';
            info.field = 'mu';
            info.name = 'Tyre Friction Coefficient';
            info.symbol = '\mu';
            info.unit = '-';
            info.positive_range = true;
            info.warn_abs_range = 2;

        case 'Cd'
            info.owner = 'vehicle';
            info.field = 'Cd';
            info.name = 'Drag Coefficient';
            info.symbol = 'C_d';
            info.unit = '-';
            info.min_range = 0;

        case 'Cl'
            info.owner = 'vehicle';
            info.field = 'Cl';
            info.name = 'Lift Coefficient';
            info.symbol = 'C_l';
            info.unit = '-';
            info.warn_abs_range = 5;

        case 'cgx'
            info.owner = 'vehicle';
            info.field = 'cgx';
            info.name = 'CG Longitudinal Position';
            info.symbol = 'x_{cg}';
            info.unit = 'm';
            info.positive_range = true;

        case 'cgh'
            info.owner = 'vehicle';
            info.field = 'cgh';
            info.name = 'CG Vertical Position';
            info.symbol = 'y_{cg}';
            info.unit = 'm';
            info.positive_range = true;

        case 'eta'
            info.owner = 'vehicle';
            info.field = 'eta';
            info.name = 'Drivetrain Efficiency';
            info.symbol = '\eta';
            info.unit = '-';
            info.positive_range = true;
            info.max_range = 1;

        case 'frontA'
            info.owner = 'vehicle';
            info.field = 'frontA';
            info.name = 'Frontal Area';
            info.symbol = 'A_f';
            info.unit = 'm^2';
            info.positive_range = true;

        case 'r_wheel'
            info.owner = 'vehicle';
            info.field = 'r_wheel';
            info.name = 'Wheel Radius';
            info.symbol = 'r_w';
            info.unit = 'm';
            info.positive_range = true;

        case 'wb'
            info.owner = 'vehicle';
            info.field = 'wb';
            info.name = 'Wheelbase';
            info.symbol = 'L';
            info.unit = 'm';
            info.positive_range = true;

        case 'maxrpm'
            info.owner = 'vehicle';
            info.field = 'maxrpm';
            info.name = 'Maximum Motor Speed';
            info.symbol = 'RPM_{max}';
            info.unit = 'rpm';
            info.positive_range = true;

        case 'rho'
            info.owner = 'vehicle';
            info.field = 'rho';
            info.name = 'Air Density';
            info.symbol = '\rho';
            info.unit = 'kg/m^3';
            info.positive_range = true;

        case 'fW'
            info.owner = 'vehicle';
            info.field = 'fW';
            info.name = 'Rolling Coefficient';
            info.symbol = 'f_W';
            info.unit = '-';
            info.min_range = 0;

        otherwise
            info.known = false;
    end
end
