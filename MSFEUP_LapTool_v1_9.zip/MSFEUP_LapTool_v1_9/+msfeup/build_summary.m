function summary = build_summary(best, sim, cfg)

    r = best.result;
    track = sim.track;

    E_lap_J = sum(r.E_seg);
    E_lap_kWh = E_lap_J / 3.6e6;
    E_total_kWh = E_lap_kWh * cfg.energy.n_laps;
    E_battery_kWh = E_total_kWh * cfg.energy.safety_coeff / cfg.energy.usable_fraction;

    summary = struct;
    summary.lap_time_s = best.lap_time;
    summary.track_length_m = track.length;
    summary.mean_speed_kph = track.length / best.lap_time * 3.6;
    summary.max_speed_kph = max(r.v) * 3.6;
    summary.min_speed_kph = min(r.v) * 3.6;
    summary.max_ax_g = max(r.ax_g);
    summary.min_ax_g = min(r.ax_g);
    summary.max_abs_ay_g = max(abs(r.ay_g));
    summary.energy_per_lap_kWh = E_lap_kWh;
    summary.total_energy_kWh = E_total_kWh;
    summary.battery_capacity_kWh = E_battery_kWh;
    summary.peak_power_kW = max(r.P_wheel) / 1000;
    summary.average_power_kW = E_lap_J / best.lap_time / 1000;
    summary.best_x = best.x;

    if isfield(sim, 'baseline') && isfield(sim.baseline, 'lap_time')
        summary.baseline_lap_time_s = sim.baseline.lap_time;
        summary.delta_vs_baseline_s = best.lap_time - sim.baseline.lap_time;
        summary.improvement_vs_baseline_pct = 100 * (sim.baseline.lap_time - best.lap_time) / sim.baseline.lap_time;
    end

    fprintf('\nMECHANICAL AND ENERGETIC EVALUATION\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('Lap-time:                %.3f s\n', summary.lap_time_s);
    if isfield(summary, 'baseline_lap_time_s')
        fprintf('Baseline lap-time:       %.3f s\n', summary.baseline_lap_time_s);
        fprintf('Improvement:             %.3f s / %.2f %%\n', ...
            -summary.delta_vs_baseline_s, summary.improvement_vs_baseline_pct);
    end
    fprintf('Mean speed:              %.2f km/h\n', summary.mean_speed_kph);
    fprintf('Maximum speed:           %.2f km/h\n', summary.max_speed_kph);
    fprintf('Maximum a_x:             %.3f g\n', summary.max_ax_g);
    fprintf('Minimum a_x:             %.3f g\n', summary.min_ax_g);
    fprintf('Maximum |a_y|:           %.3f g\n', summary.max_abs_ay_g);
    fprintf('Energy spent per lap:    %.3f kWh\n', summary.energy_per_lap_kWh);
    fprintf('Total energy %.1f laps:  %.3f kWh\n', cfg.energy.n_laps, summary.total_energy_kWh);
    fprintf('Battery capacity:        %.3f kWh\n', summary.battery_capacity_kWh);
    fprintf('Peak wheel power:        %.2f kW\n', summary.peak_power_kW);
    fprintf('Average wheel power:     %.2f kW\n', summary.average_power_kW);
    fprintf('=======================================================================\n');
end

%% =========================================================
% LOCAL FUNCTION: section analysis
% =========================================================
