function value = get_study_parameter_value(id, vehicle, operating, fallback)
%GET_STUDY_PARAMETER_VALUE  Read a study parameter from canonical registry.

    if nargin < 4
        fallback = NaN;
    end

    info = msfeup.study_parameter_registry(id);
    if ~info.known
        value = fallback;
        return
    end

    switch info.owner
        case 'vehicle'
            if isfield(vehicle, info.field)
                value = vehicle.(info.field);
            else
                value = fallback;
            end
        case 'operating'
            if isfield(operating, info.field)
                value = operating.(info.field);
            else
                value = fallback;
            end
        otherwise
            value = fallback;
    end
end
