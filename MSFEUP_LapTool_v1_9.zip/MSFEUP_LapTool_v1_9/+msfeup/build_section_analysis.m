function sections = build_section_analysis(track, result, cfg)

    k_abs = abs(track.kappa);
    threshold = cfg.analysis.corner_kappa_threshold;
    is_corner = k_abs > threshold;

    min_pts = max(2, round(cfg.analysis.min_section_length / mean(track.ds_vec)));

    is_corner = clean_binary_sections(is_corner, min_pts);

    change_idx = [1; find(diff(is_corner) ~= 0) + 1; track.N + 1];
    n_sec = numel(change_idx) - 1;

    section_id = zeros(n_sec,1);
    type = strings(n_sec,1);
    s_start = zeros(n_sec,1);
    s_end = zeros(n_sec,1);
    length_m = zeros(n_sec,1);
    time_s = zeros(n_sec,1);
    v_min_kph = zeros(n_sec,1);
    v_mean_kph = zeros(n_sec,1);
    v_max_kph = zeros(n_sec,1);
    ay_max_g = zeros(n_sec,1);
    kappa_max = zeros(n_sec,1);

    for i = 1:n_sec
        idx = change_idx(i):(change_idx(i+1)-1);

        section_id(i) = i;
        if is_corner(idx(1))
            type(i) = "corner";
        else
            type(i) = "straight";
        end

        s_start(i) = track.s(idx(1));
        s_end(i) = track.s(idx(end));
        length_m(i) = sum(track.ds_vec(idx));
        time_s(i) = sum(result.dt(idx));
        v_min_kph(i) = min(result.v(idx))*3.6;
        v_mean_kph(i) = mean(result.v(idx))*3.6;
        v_max_kph(i) = max(result.v(idx))*3.6;
        ay_max_g(i) = max(abs(result.ay_g(idx)));
        kappa_max(i) = max(k_abs(idx));
    end

    sections = table(section_id, type, s_start, s_end, length_m, time_s, ...
        v_min_kph, v_mean_kph, v_max_kph, ay_max_g, kappa_max);
end

%% =========================================================
% LOCAL FUNCTION: clean binary sections
% =========================================================

function y = clean_binary_sections(x, min_pts)

    y = x(:);
    N = numel(y);
    change_idx = [1; find(diff(y) ~= 0) + 1; N + 1];

    for i = 1:(numel(change_idx)-1)
        idx = change_idx(i):(change_idx(i+1)-1);
        if numel(idx) < min_pts
            left = idx(1) - 1;
            right = idx(end) + 1;

            if left < 1
                left = N;
            end
            if right > N
                right = 1;
            end

            if y(left) == y(right)
                y(idx) = y(left);
            end
        end
    end
end

%% =========================================================
% LOCAL FUNCTION: write outputs
% =========================================================
