function value = fetch_required_field(payload, preferred_name, file_name)

    if isfield(payload, preferred_name)
        value = payload.(preferred_name);
        return
    end

    fn = fieldnames(payload);
    if numel(fn) == 1
        value = payload.(fn{1});
        warning('Expected variable %s in %s. Using only variable found: %s.', ...
            preferred_name, file_name, fn{1});
        return
    end

    error('Could not find variable %s in file %s.', preferred_name, file_name);
end
