function track = build_gps_track(lat, lon, xpos, theta, R_file, cfg)

    rt_earth = 6371000;

    lat = lat(:);
    lon = lon(:);
    xpos = xpos(:);
    theta = theta(:);
    R_file = R_file(:);

    valid = isfinite(lat) & isfinite(lon);
    lat = lat(valid);
    lon = lon(valid);

    latr = deg2rad(lat);
    lonr = deg2rad(lon);

    lat0 = mean(latr,'omitnan');
    lon0 = mean(lonr,'omitnan');

    x_raw = rt_earth * (lonr - lon0) .* cos(lat0);
    y_raw = rt_earth * (latr - lat0);

    N_raw = numel(latr);
    d_raw = zeros(N_raw,1);

    for i = 2:N_raw
        dlat = latr(i) - latr(i-1);
        dlon = lonr(i) - lonr(i-1);

        a = sin(dlat/2)^2 + cos(latr(i-1))*cos(latr(i))*sin(dlon/2)^2;
        c = 2 * asin(sqrt(a));
        d_raw(i) = d_raw(i-1) + rt_earth*c;
    end

    valid = isfinite(d_raw) & isfinite(x_raw) & isfinite(y_raw);
    d_raw = d_raw(valid);
    x_raw = x_raw(valid);
    y_raw = y_raw(valid);

    [d_raw, idx_sort] = sort(d_raw);
    x_raw = x_raw(idx_sort);
    y_raw = y_raw(idx_sort);

    [d_raw, idx_unique] = unique(d_raw, 'stable');
    x_raw = x_raw(idx_unique);
    y_raw = y_raw(idx_unique);

    x_track = interp1(d_raw, x_raw, xpos, 'pchip', 'extrap');
    y_track = interp1(d_raw, y_raw, xpos, 'pchip', 'extrap');

    x_track = x_track(:);
    y_track = y_track(:);

    closure_gap = hypot(x_track(end)-x_track(1), y_track(end)-y_track(1));
    track_length = xpos(end) - xpos(1);

    if closure_gap > max(cfg.track.max_closure_warning_m, 0.03*track_length)
        warning('GPS closure gap is %.2f m. Check lap start/end alignment.', closure_gap);
    end

    alpha = (xpos - xpos(1)) ./ (xpos(end) - xpos(1));
    x_track = x_track - alpha * (x_track(end) - x_track(1));
    y_track = y_track - alpha * (y_track(end) - y_track(1));

    x_track = x_track - mean(x_track);
    y_track = y_track - mean(y_track);

    ds_num = median(diff(xpos));

    win_xy = local_odd_window(cfg.track.smooth_len_xy, ds_num, numel(x_track));
    x_track = smooth_circular(x_track, win_xy);
    y_track = smooth_circular(y_track, win_xy);

    n_shift = max(2, round(cfg.track.curv_half_len / ds_num));

    x_prev = circshift(x_track,  n_shift);
    y_prev = circshift(y_track,  n_shift);
    x_next = circshift(x_track, -n_shift);
    y_next = circshift(y_track, -n_shift);

    a_len = hypot(x_track - x_prev, y_track - y_prev);
    b_len = hypot(x_next - x_track, y_next - y_track);
    c_len = hypot(x_next - x_prev, y_next - y_prev);

    area2 = (x_track - x_prev) .* (y_next - y_prev) ...
          - (y_track - y_prev) .* (x_next - x_prev);

    kappa = 2 * area2 ./ (a_len .* b_len .* c_len);
    kappa(~isfinite(kappa)) = 0;

    win_k = local_odd_window(cfg.track.smooth_len_k, ds_num, numel(kappa));
    kappa = smooth_circular(kappa, win_k);

    kappa(abs(kappa) < 1/cfg.track.straight_radius_threshold) = 0;

    R = inf(size(kappa));
    idx_curve = abs(kappa) > 0;
    R(idx_curve) = 1 ./ kappa(idx_curve);

    ds_vec = zeros(numel(xpos),1);
    ds_vec(1:end-1) = diff(xpos);
    ds_vec(end) = cfg.ds;

    if any(diff(xpos) <= 0)
        error('Track abscissa is not strictly increasing.');
    end

    if any(~isfinite(theta))
        error('theta contains non-finite values.');
    end

    if any(cos(theta) <= 0)
        error('theta contains physically invalid slope values.');
    end

    if any(~isfinite(kappa)) || any(~isfinite(x_track)) || any(~isfinite(y_track))
        error('GPS track contains non-finite values.');
    end

    track = struct;
    track.s = xpos;
    track.x = x_track;
    track.y = y_track;
    track.theta = theta;
    track.R_file = R_file;
    track.R = R;
    track.kappa = kappa;
    track.ds_vec = ds_vec;
    track.N = numel(xpos);
    track.length = sum(ds_vec);
    track.closure_gap = closure_gap;

    disp(' - GPS Track Successfully Parametrized');
end

%% =========================================================
% LOCAL FUNCTION: distance
% =========================================================

function y = smooth_circular(x, win)

    x = x(:);
    N = numel(x);

    win = round(win);
    win = max(5, 2*floor(win/2) + 1);
    win = min(win, 2*floor((N-1)/2) + 1);

    if win < 5 || N < 2*win
        y = x;
        return
    end

    npad = min(N-1, 2*win);
    x_pad = [x(end-npad+1:end); x; x(1:npad)];
    y_pad = smoothdata(x_pad, 'sgolay', win);
    y = y_pad(npad+1:npad+N);
end

%% =========================================================
% LOCAL FUNCTION: odd window
% =========================================================

function win = local_odd_window(length_m, ds, N)

    win = round(length_m / ds);
    win = max(5, 2*floor(win/2) + 1);
    win = min(win, 2*floor((N-1)/2) + 1);
end
