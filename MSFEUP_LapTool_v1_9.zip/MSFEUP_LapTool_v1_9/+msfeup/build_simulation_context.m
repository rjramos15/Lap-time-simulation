function sim = build_simulation_context(cfg, track, vehicle, operating, power)

    sim = struct;
    sim.cfg = cfg;
    sim.track = track;
    sim.vehicle = vehicle;
    sim.operating = operating;
    sim.power = power;
    sim.study = cfg.study;

    sim.N = track.N;
    sim.ds_vec = track.ds_vec;
    sim.theta = track.theta;
    sim.kappa = track.kappa;
    sim.v_max_global = cfg.sim.v_max_global;
    sim.nIter = cfg.sim.nIter;
    sim.tol = cfg.sim.tol;
end
