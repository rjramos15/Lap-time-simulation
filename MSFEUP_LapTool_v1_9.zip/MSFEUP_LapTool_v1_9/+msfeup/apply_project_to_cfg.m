function cfg = apply_project_to_cfg(cfg, project)

    cfg.ds = project.track.ds;
    cfg.output_folder = project.outputs.figures;
    cfg.results_folder = project.outputs.results;

    if isfield(project, 'outputs')
        output_options = {'export_level','auto_export','write_summary','export_velocity_profile','export_force_profile', ...
            'export_figures','write_csv','write_archive','write_diagnostics_files','figure_content_type'};
        for i = 1:numel(output_options)
            f = output_options{i};
            if isfield(project.outputs, f)
                cfg.outputs.(f) = project.outputs.(f);
            end
        end
    end

    copy_fields = {'sim','track','energy','analysis','optim','sensitivity'};
    for b = 1:numel(copy_fields)
        block = copy_fields{b};
        if isfield(project, block)
            fn = fieldnames(project.(block));
            for i = 1:numel(fn)
                cfg.(block).(fn{i}) = project.(block).(fn{i});
            end
        end
    end

    % Keep the public Advanced sampling control coherent across modes:
    % one-variable optimization and one-at-a-time sensitivity both use this
    % as their per-variable sampling density.
    if isfield(cfg.optim, 'grid_1d_points')
        cfg.sensitivity.points_per_variable = max(2, round(cfg.optim.grid_1d_points));
    end

    if isfield(project, 'track') && isfield(project.track, 'curve_limit_mode') && isfield(project.track, 'curve_limit_value')
        [radius_thr, kappa_thr] = resolve_curve_limit(project.track.curve_limit_mode, project.track.curve_limit_value);
        cfg.track.straight_radius_threshold = radius_thr;
        cfg.analysis.corner_kappa_threshold = kappa_thr;
    end

    if isfield(project, 'visual')
        if isfield(project.visual, 'plot_font_name')
            cfg.visual.font_name = project.visual.plot_font_name;
        elseif isfield(project.visual, 'font_name')
            cfg.visual.font_name = project.visual.font_name;
        end
        if isfield(project.visual, 'primary_green')
            cfg.visual.primary_green = project.visual.primary_green;
        end
    end
end

%% =========================================================
% LOCAL FUNCTION: resolve unified curve/straight limit
% =========================================================

function [radius_threshold, kappa_threshold] = resolve_curve_limit(mode, value)

    value = double(value);
    if ~isfinite(value) || value <= 0
        error('Track curve/straight limit must be a positive finite value.');
    end

    if strcmp(char(string(mode)), 'Curvature threshold [1/m]')
        kappa_threshold = value;
        radius_threshold = 1 / value;
    else
        radius_threshold = value;
        kappa_threshold = 1 / value;
    end
end

%% =========================================================
% LOCAL FUNCTION: required field from MAT payload
% =========================================================
