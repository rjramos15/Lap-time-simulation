function [best, opt, baseline] = run_sensitivity(sim, cfg)
%RUN_SENSITIVITY  One-at-a-time sensitivity study around the baseline.
%
% This is not an optimizer. It evaluates each study variable independently
% over its configured range while all other study variables remain at their
% baseline value.

    D = numel(sim.study);
    if D == 0
        error('Sensitivity mode requires at least one active study parameter.');
    end

    x0 = base_parameter_vector(sim);
    [baseline_lap_time, baseline_result] = msfeup.simulate_lap_case(x0, sim, true);

    baseline = struct;
    baseline.x = x0;
    baseline.lap_time = baseline_lap_time;
    baseline.result = baseline_result;

    n_points = cfg.sensitivity.points_per_variable;
    if ~isfinite(n_points) || n_points < 3
        n_points = 3;
    end
    n_points = round(n_points);

    rows = struct('variable', {}, 'name', {}, 'unit', {}, 'value', {}, ...
        'normalized_value', {}, 'lap_time_s', {}, 'delta_vs_baseline_s', {});

    samples_x = zeros(0, D);
    samples_J = zeros(0, 1);
    samples_phase = strings(0, 1);

    fprintf('\nONE-AT-A-TIME SENSITIVITY STUDY\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('Baseline lap-time: %.6f s\n', baseline_lap_time);

    for d = 1:D
        range = double(sim.study(d).range(:)');
        values = linspace(range(1), range(2), n_points);

        if isfield(cfg.sensitivity, 'include_bounds') && ~cfg.sensitivity.include_bounds && n_points > 2
            values = values(2:end-1);
        end

        values = values(:);
        if ~isempty(values) && isfinite(x0(d))
            [~, idx_baseline] = min(abs(values - x0(d)));
            values(idx_baseline) = x0(d);
        end
        values = unique(sort(values(:)), 'stable');

        fprintf('Sensitivity: %s | %d points\n', sim.study(d).id, numel(values));

        for k = 1:numel(values)
            x = x0;
            x(d) = values(k);
            J = objective_lap_time(x, sim);

            row = struct;
            row.variable = string(sim.study(d).id);
            row.name = string(sim.study(d).name);
            row.unit = string(sim.study(d).unit);
            row.value = values(k);
            row.normalized_value = (values(k) - range(1)) / (range(2) - range(1));
            row.lap_time_s = J;
            row.delta_vs_baseline_s = J - baseline_lap_time;
            rows(end+1) = row; %#ok<AGROW>

            samples_x(end+1,:) = x; %#ok<AGROW>
            samples_J(end+1,1) = J; %#ok<AGROW>
            samples_phase(end+1,1) = "sensitivity_" + string(sim.study(d).id); %#ok<AGROW>
        end

        notify_progress(cfg.progressFcn, 0.55 + 0.25*d/max(D,1), ...
            sprintf('Sensitivity %d/%d | %s', d, D, sim.study(d).id));
    end

    sensitivity = summarize_sensitivity(rows, sim, baseline_lap_time);

    best = struct;
    best.x = x0;
    best.lap_time = baseline_lap_time;
    best.result = baseline_result;

    opt = struct;
    opt.dimension = D;
    opt.lb = arrayfun(@(s) s.range(1), sim.study);
    opt.ub = arrayfun(@(s) s.range(2), sim.study);
    opt.samples_x = samples_x;
    opt.samples_J = samples_J;
    opt.samples_phase = samples_phase;
    opt.local_trace = [];
    opt.grid = [];
    opt.method = 'one_at_a_time_sensitivity';
    opt.sensitivity = sensitivity;
    opt.diagnostics = sensitivity_diagnostics(sensitivity);

    fprintf('=======================================================================\n');
end

function x0 = base_parameter_vector(sim)

    D = numel(sim.study);
    x0 = zeros(1,D);

    for d = 1:D
        id = sim.study(d).id;
        x0(d) = msfeup.get_study_parameter_value(id, sim.vehicle, sim.operating, mean(sim.study(d).range));
    end
end

function J = objective_lap_time(x, sim)

    try
        J = msfeup.simulate_lap_case(x, sim, false);
    catch
        J = inf;
    end

    if ~isfinite(J)
        J = inf;
    end
end

function sensitivity = summarize_sensitivity(rows, sim, baseline_lap_time)

    D = numel(sim.study);
    variable = strings(D,1);
    name = strings(D,1);
    unit = strings(D,1);
    baseline_value = zeros(D,1);
    min_lap_time_s = inf(D,1);
    max_lap_time_s = inf(D,1);
    range_effect_s = zeros(D,1);
    range_effect_pct = zeros(D,1);
    slope_s_per_unit = zeros(D,1);
    monotonicity = strings(D,1);
    best_value_in_sweep = zeros(D,1);
    note = strings(D,1);

    x0 = base_parameter_vector(sim);

    for d = 1:D
        id = string(sim.study(d).id);
        idx = [rows.variable]' == id;
        values = [rows(idx).value]';
        J = [rows(idx).lap_time_s]';
        valid = isfinite(values) & isfinite(J);
        values = values(valid);
        J = J(valid);

        variable(d) = id;
        name(d) = string(sim.study(d).name);
        unit(d) = string(sim.study(d).unit);
        baseline_value(d) = x0(d);

        if isempty(J)
            min_lap_time_s(d) = NaN;
            max_lap_time_s(d) = NaN;
            range_effect_s(d) = NaN;
            range_effect_pct(d) = NaN;
            slope_s_per_unit(d) = NaN;
            best_value_in_sweep(d) = NaN;
            monotonicity(d) = "unknown";
            note(d) = "No valid sensitivity samples.";
            continue
        end

        [min_lap_time_s(d), idx_best] = min(J);
        max_lap_time_s(d) = max(J);
        best_value_in_sweep(d) = values(idx_best);
        range_effect_s(d) = max_lap_time_s(d) - min_lap_time_s(d);
        range_effect_pct(d) = 100 * range_effect_s(d) / baseline_lap_time;
        slope_s_per_unit(d) = linear_slope(values, J);
        monotonicity(d) = classify_monotonicity(values, J);

        if range_effect_s(d) < 0.05 || range_effect_pct(d) < 0.10
            note(d) = "Low sensitivity over tested range.";
        elseif is_boundary_value(best_value_in_sweep(d), sim.study(d).range)
            note(d) = "Best sampled value is at range boundary; do not infer physical optimum.";
        else
            note(d) = "Sensitivity visible over tested range.";
        end
    end

    point_variable = arrayfun(@(r) r.variable, rows(:));
    point_name = arrayfun(@(r) r.name, rows(:));
    point_unit = arrayfun(@(r) r.unit, rows(:));
    point_value = arrayfun(@(r) r.value, rows(:));
    point_normalized_value = arrayfun(@(r) r.normalized_value, rows(:));
    point_lap_time_s = arrayfun(@(r) r.lap_time_s, rows(:));
    point_delta_vs_baseline_s = arrayfun(@(r) r.delta_vs_baseline_s, rows(:));

    sensitivity = struct;
    sensitivity.summary = table(variable, name, unit, baseline_value, min_lap_time_s, ...
        max_lap_time_s, range_effect_s, range_effect_pct, slope_s_per_unit, ...
        monotonicity, best_value_in_sweep, note);
    sensitivity.points = table(point_variable, point_name, point_unit, point_value, ...
        point_normalized_value, point_lap_time_s, point_delta_vs_baseline_s);
end

function slope = linear_slope(x, y)

    x = x(:);
    y = y(:);
    if numel(x) < 2 || max(x) <= min(x)
        slope = NaN;
        return
    end

    X = [ones(numel(x),1) x];
    coeff = X \ y;
    slope = coeff(2);
end

function label = classify_monotonicity(x, y)

    [x, idx] = sort(x(:));
    y = y(idx);
    dy = diff(y);
    tol = max(1e-6, 1e-4 * max(abs(y)));
    n_pos = nnz(dy > tol);
    n_neg = nnz(dy < -tol);

    if n_pos > 0 && n_neg == 0
        label = "increasing";
    elseif n_neg > 0 && n_pos == 0
        label = "decreasing";
    elseif n_pos == 0 && n_neg == 0
        label = "flat";
    else
        label = "non_monotonic";
    end
end

function tf = is_boundary_value(value, range)

    span = range(2) - range(1);
    tol = max(1e-9, 0.005 * span);
    tf = abs(value - range(1)) <= tol || abs(value - range(2)) <= tol;
end

function diagnostics = sensitivity_diagnostics(sensitivity)

    diagnostics = struct;
    diagnostics.warnings = strings(0,1);
    diagnostics.boundary = struct('id', {}, 'side', {}, 'value', {}, 'limit', {}, 'distance_fraction', {});
    diagnostics.low_sensitivity = struct('id', {}, 'effect_s', {}, 'effect_pct', {});
    diagnostics.improvement = struct;

    S = sensitivity.summary;
    for i = 1:height(S)
        if contains(S.note(i), "Low sensitivity")
            item = struct;
            item.id = char(S.variable(i));
            item.effect_s = S.range_effect_s(i);
            item.effect_pct = S.range_effect_pct(i);
            diagnostics.low_sensitivity(end+1) = item; %#ok<AGROW>
            diagnostics.warnings(end+1,1) = "Low OAT sensitivity detected for " + S.variable(i) + ".";
        elseif contains(S.note(i), "boundary")
            diagnostics.warnings(end+1,1) = "Best sampled value for " + S.variable(i) + ...
                " is at a sensitivity range boundary; do not report it as an optimized design.";
        end
    end
end
