function power = load_power_curve(file_name, maxrpm)

    raw = load(file_name);
    fn = fieldnames(raw);

    torque = [];
    rpm = [];

    for i = 1:numel(fn)
        obj = raw.(fn{i});

        if istable(obj)
            names = obj.Properties.VariableNames;
            rpm_name = find_name(names, {'MotorSpeed_rpm_','Speed1','Speed','RPM','rpm'});
            tq_name  = find_name(names, {'Torque_Nm_','Torque1','Torque','Tq','torque'});

            if ~isempty(rpm_name) && ~isempty(tq_name)
                rpm = obj.(rpm_name)(:);
                torque = obj.(tq_name)(:);
                break
            end
        elseif isstruct(obj)
            names = fieldnames(obj);
            rpm_name = find_name(names, {'MotorSpeed_rpm_','Speed1','Speed','RPM','rpm'});
            tq_name  = find_name(names, {'Torque_Nm_','Torque1','Torque','Tq','torque'});

            if ~isempty(rpm_name) && ~isempty(tq_name)
                rpm = obj.(rpm_name)(:);
                torque = obj.(tq_name)(:);
                break
            end
        end
    end

    if isempty(rpm) || isempty(torque)
        error('Could not identify RPM and torque columns in %s.', file_name);
    end

    valid = isfinite(rpm) & isfinite(torque);
    rpm = rpm(valid);
    torque = torque(valid);

    [rpm, idx_sort] = sort(rpm);
    torque = torque(idx_sort);

    [rpm, idx_unique] = unique(rpm, 'stable');
    torque = torque(idx_unique);

    if any(diff(rpm) <= 0)
        error('RPM map is not strictly increasing.');
    end

    power.rpm_step = 0.1;
    power.rpm_grid = (0:power.rpm_step:maxrpm)';
    power.torque_grid = interp1(rpm, torque, power.rpm_grid, 'pchip', 0);
    power.rpm_raw = rpm;
    power.torque_raw = torque;

    omega = power.rpm_grid * 2*pi/60;
    power.power_grid = power.torque_grid .* omega;

    disp(' - Power Curve Successfully Loaded');
end

%% =========================================================
% LOCAL FUNCTION: find table/struct field
% =========================================================

function name = find_name(names, candidates)

    name = '';

    for i = 1:numel(candidates)
        idx = find(strcmp(names, candidates{i}), 1, 'first');
        if ~isempty(idx)
            name = names{idx};
            return
        end
    end
end

%% =========================================================
% LOCAL FUNCTION: optimize lap
% =========================================================
