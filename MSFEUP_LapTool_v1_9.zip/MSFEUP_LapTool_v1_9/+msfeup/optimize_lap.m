function [best, opt] = optimize_lap(sim, cfg)

    stream = RandStream('mt19937ar', 'Seed', cfg.optim.rng_seed);

    D = numel(sim.study);
    lb = zeros(1,D);
    ub = zeros(1,D);

    for i = 1:D
        lb(i) = sim.study(i).range(1);
        ub(i) = sim.study(i).range(2);
    end

    opt = struct;
    opt.dimension = D;
    opt.lb = lb;
    opt.ub = ub;
    opt.samples_x = [];
    opt.samples_J = [];
    opt.samples_phase = strings(0,1);
    opt.local_trace = [];
    opt.local_refinement = struct('start_index', {}, 'seed_J', {}, 'refined_J', {}, 'x', {});
    opt.grid = [];
    opt.method = '';

    if D == 1
        notify_progress(cfg.progressFcn, 0.58, 'Optimization: coarse 1D grid search');
        [opt, best_seed] = coarse_1d_grid_search(sim, cfg, lb, ub, opt);
    elseif D == 2 && cfg.optim.use_grid_if_2d
        notify_progress(cfg.progressFcn, 0.58, 'Optimization: coarse 2D grid search');
        [opt, best_seed] = coarse_grid_search(sim, cfg, lb, ub, opt);
    else
        notify_progress(cfg.progressFcn, 0.58, sprintf('Optimization: global search in %dD', D));
        [opt, best_seed] = coarse_project_global_search(sim, cfg, lb, ub, opt, stream);
    end

    valid_seed = isfinite(opt.samples_J) & all(isfinite(opt.samples_x), 2);
    if ~any(valid_seed)
        error('No valid optimization sample was obtained. Check model constraints and parameter ranges.');
    end

    n_start = min(cfg.optim.top_starts, nnz(valid_seed));
    [~, idx_sort] = sort(opt.samples_J, 'ascend');
    idx_sort = idx_sort(isfinite(opt.samples_J(idx_sort)));
    start_idx = idx_sort(1:n_start);

    best_x = best_seed.x;
    best_J = best_seed.J;

    fprintf('\nLOCAL MULTI-START REFINEMENT\n');
    fprintf('-----------------------------------------------------------------------\n');

    use_waitbar = cfg.optim.waitbar;
    if use_waitbar
        h_ref = waitbar(0, 'Starting local refinement...');
        cleanup_ref = onCleanup(@() safe_close_waitbar(h_ref)); %#ok<NASGU>
    else
        h_ref = [];
    end

    for i = 1:n_start
        x0 = opt.samples_x(start_idx(i),:);

        progress = struct;
        progress.enabled = use_waitbar;
        progress.handle = h_ref;
        progress.start_index = i;
        progress.n_start = n_start;
        progress.base = (i - 1) / n_start;
        progress.pattern_span = 0.72 / n_start;
        progress.simplex_span = 0.25 / n_start;

        [x_pattern, J_pattern, trace_pattern] = local_pattern_search(x0, lb, ub, sim, cfg, progress);
        opt.local_trace = [opt.local_trace; trace_pattern]; %#ok<AGROW>

        x_candidate = x_pattern;
        J_candidate = J_pattern;

        if cfg.optim.simplex_enabled
            if use_waitbar && ishandle(h_ref)
                waitbar(progress.base + progress.pattern_span, h_ref, ...
                    sprintf('Local refinement %d/%d | simplex refinement', i, n_start));
                drawnow limitrate
            end

            [x_simplex, J_simplex] = local_simplex_refinement(x_pattern, lb, ub, sim, cfg);
            opt.local_trace = [opt.local_trace; [size(trace_pattern,1)+1 J_simplex x_simplex]]; %#ok<AGROW>
            if J_simplex < J_candidate
                x_candidate = x_simplex;
                J_candidate = J_simplex;
            end
        end

        if use_waitbar && ishandle(h_ref)
            waitbar(i/n_start, h_ref, ...
                sprintf('Local refinement: %d%%', round(100*i/n_start)));
            drawnow limitrate
        end

        fprintf('Start %02d | seed %.6f s | refined %.6f s\n', ...
            i, opt.samples_J(start_idx(i)), J_candidate);

        opt.local_refinement(end+1) = struct( ...
            'start_index', start_idx(i), ...
            'seed_J', opt.samples_J(start_idx(i)), ...
            'refined_J', J_candidate, ...
            'x', x_candidate); %#ok<AGROW>

        if J_candidate < best_J
            best_x = x_candidate;
            best_J = J_candidate;
        end

        notify_progress(cfg.progressFcn, 0.74 + 0.08*i/max(n_start,1), ...
            sprintf('Local refinement %d/%d | best %.4f s', i, n_start, best_J));
    end

    if use_waitbar && ishandle(h_ref)
        close(h_ref);
    end

    [lap_time, result] = msfeup.simulate_lap_case(best_x, sim, true);

    best = struct;
    best.x = best_x;
    best.lap_time = lap_time;
    best.result = result;

    opt.diagnostics = build_optimizer_diagnostics(best, opt, sim, cfg);
    emit_optimizer_diagnostics(opt.diagnostics);

    fprintf('=======================================================================\n');
end

%% =========================================================
% LOCAL FUNCTION: optimizer diagnostics
% =========================================================

function diagnostics = build_optimizer_diagnostics(best, opt, sim, cfg)

    diagnostics = struct;
    diagnostics.warnings = strings(0,1);
    diagnostics.boundary = struct('id', {}, 'side', {}, 'value', {}, 'limit', {}, ...
        'distance_fraction', {}, 'suggested_range', {});
    diagnostics.low_sensitivity = struct('id', {}, 'effect_s', {}, 'effect_pct', {});
    diagnostics.improvement = struct;
    diagnostics.multistart = struct;

    lb = opt.lb;
    ub = opt.ub;
    span = ub - lb;
    tol_z = max(1e-4, 5*cfg.optim.local_tol_step);

    for d = 1:numel(best.x)
        if span(d) <= 0 || ~isfinite(span(d))
            continue
        end

        z = (best.x(d) - lb(d)) / span(d);
        if z <= tol_z
            diagnostics.boundary(end+1) = make_boundary_flag(sim.study(d), 'lower', best.x(d), lb(d), z); %#ok<AGROW>
            diagnostics.warnings(end+1,1) = "Best " + string(sim.study(d).id) + ...
                " is at/near the lower study boundary. Treat optimum as boundary-limited, not physically confirmed.";
        elseif (1 - z) <= tol_z
            diagnostics.boundary(end+1) = make_boundary_flag(sim.study(d), 'upper', best.x(d), ub(d), 1-z); %#ok<AGROW>
            diagnostics.warnings(end+1,1) = "Best " + string(sim.study(d).id) + ...
                " is at/near the upper study boundary. Treat optimum as boundary-limited, not physically confirmed.";
        end
    end

    if isfield(sim, 'baseline') && isfield(sim.baseline, 'lap_time') && isfinite(sim.baseline.lap_time)
        delta_s = sim.baseline.lap_time - best.lap_time;
        improvement_pct = 100 * delta_s / sim.baseline.lap_time;
        diagnostics.improvement.delta_s = delta_s;
        diagnostics.improvement.improvement_pct = improvement_pct;

        if delta_s < 0
            diagnostics.warnings(end+1,1) = "Best candidate is slower than baseline; do not report this as an improvement.";
        elseif delta_s < 0.05 || improvement_pct < 0.10
            diagnostics.warnings(end+1,1) = "Improvement versus baseline is very small; it may not be conclusive.";
        end
    end

    if isfield(opt, 'samples_x') && isfield(opt, 'samples_J') && ~isempty(opt.samples_J)
        diagnostics = add_sensitivity_diagnostics(diagnostics, opt, sim);
    end

    diagnostics = add_multistart_diagnostics(diagnostics, opt, best);
end

function diagnostics = add_multistart_diagnostics(diagnostics, opt, best)

    diagnostics.multistart.available = false;
    diagnostics.multistart.n_starts = 0;
    diagnostics.multistart.n_converged = 0;
    diagnostics.multistart.epsilon_s = NaN;
    diagnostics.multistart.refined_std_s = NaN;
    diagnostics.multistart.refined_range_s = NaN;
    diagnostics.multistart.confidence = "unknown";

    if ~isfield(opt, 'local_refinement') || isempty(opt.local_refinement)
        return
    end

    refined = [opt.local_refinement.refined_J]';
    refined = refined(isfinite(refined));
    if isempty(refined)
        return
    end

    eps_s = max(0.01, 1e-4 * max(abs(best.lap_time), 1));
    n_conv = nnz(abs(refined - best.lap_time) <= eps_s);
    frac = n_conv / numel(refined);

    diagnostics.multistart.available = true;
    diagnostics.multistart.n_starts = numel(refined);
    diagnostics.multistart.n_converged = n_conv;
    diagnostics.multistart.epsilon_s = eps_s;
    diagnostics.multistart.refined_std_s = std(refined);
    diagnostics.multistart.refined_range_s = max(refined) - min(refined);

    if frac >= 0.80
        diagnostics.multistart.confidence = "high";
    elseif frac >= 0.50
        diagnostics.multistart.confidence = "medium";
        diagnostics.warnings(end+1,1) = "Multi-start refinement has only medium agreement; inspect candidate spread.";
    else
        diagnostics.multistart.confidence = "low";
        diagnostics.warnings(end+1,1) = "Multi-start refinement has low agreement; optimum may be sensitive to starting point.";
    end
end

function flag = make_boundary_flag(study, side, value, limit, distance_fraction)

    flag = struct;
    flag.id = char(string(study.id));
    flag.side = char(string(side));
    flag.value = value;
    flag.limit = limit;
    flag.distance_fraction = distance_fraction;
    flag.suggested_range = suggest_expanded_range(study, side);
end

function range_new = suggest_expanded_range(study, side)

    range_old = double(study.range(:)');
    span = range_old(2) - range_old(1);
    pad = 0.25 * span;
    range_new = range_old;

    if strcmp(char(string(side)), 'lower')
        range_new(1) = range_old(1) - pad;
    else
        range_new(2) = range_old(2) + pad;
    end

    info = msfeup.study_parameter_registry(study.id);
    if info.known
        if info.positive_range
            range_new(1) = max(range_new(1), eps);
        end
        if isfinite(info.min_range)
            range_new(1) = max(range_new(1), info.min_range);
        end
        if isfinite(info.max_range)
            range_new(2) = min(range_new(2), info.max_range);
        end
    end
end

function diagnostics = add_sensitivity_diagnostics(diagnostics, opt, sim)

    X = opt.samples_x;
    J = opt.samples_J(:);
    valid = isfinite(J) & all(isfinite(X), 2);
    X = X(valid,:);
    J = J(valid);

    if numel(J) < 12
        return
    end

    J_ref = median(J);
    if ~isfinite(J_ref) || J_ref <= 0
        J_ref = min(J);
    end

    for d = 1:size(X,2)
        xd = X(:,d);
        if max(xd) <= min(xd)
            continue
        end

        q_low = local_quantile(xd, 0.25);
        q_high = local_quantile(xd, 0.75);
        idx_low = xd <= q_low;
        idx_high = xd >= q_high;

        if nnz(idx_low) < 3 || nnz(idx_high) < 3
            continue
        end

        effect_s = median(J(idx_high)) - median(J(idx_low));
        effect_pct = 100 * abs(effect_s) / J_ref;

        if abs(effect_s) < 0.03 || effect_pct < 0.05
            item = struct;
            item.id = char(string(sim.study(d).id));
            item.effect_s = effect_s;
            item.effect_pct = effect_pct;
            diagnostics.low_sensitivity(end+1) = item; %#ok<AGROW>
            diagnostics.warnings(end+1,1) = "Low sampled sensitivity detected for " + string(sim.study(d).id) + ...
                "; range effect is small relative to lap-time noise/resolution.";
        end
    end
end

function q = local_quantile(x, p)

    x = sort(x(:));
    n = numel(x);
    if n == 0
        q = NaN;
        return
    end

    pos = 1 + (n - 1) * p;
    lo = floor(pos);
    hi = ceil(pos);
    if lo == hi
        q = x(lo);
    else
        q = x(lo) + (pos - lo) * (x(hi) - x(lo));
    end
end

function emit_optimizer_diagnostics(diagnostics)

    if ~isfield(diagnostics, 'warnings')
        return
    end

    for i = 1:numel(diagnostics.warnings)
        warning('MSFEUP:OptimizerDiagnostic', '%s', char(diagnostics.warnings(i)));
    end
end

%% =========================================================
% LOCAL FUNCTION: coarse 1D grid search
% =========================================================

function [opt, best_seed] = coarse_1d_grid_search(sim, cfg, lb, ub, opt)

    if isfield(cfg.optim, 'grid_1d_points')
        p = max(2, round(cfg.optim.grid_1d_points));
    else
        p = max(2, round(cfg.optim.precision));
    end

    x1 = linspace(lb(1), ub(1), p)';
    samples_x = x1;
    samples_J = inf(p, 1);

    best_seed.x = NaN;
    best_seed.J = inf;

    fprintf('\nCOARSE 1D GRID SEARCH\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('Grid: %d simulations\n', p);

    use_waitbar = cfg.optim.waitbar;
    if use_waitbar
        h = waitbar(0, 'Starting coarse 1D grid search...');
    end

    for i = 1:p
        x = samples_x(i,:);
        poll_abort(cfg.progressFcn);
        J = objective_lap_time(x, sim);

        samples_J(i) = J;
        if J < best_seed.J
            best_seed.x = x;
            best_seed.J = J;
        end

        if use_waitbar
            waitbar(i/p, h, sprintf('Coarse 1D grid: %d%%', round(100*i/p)));
        end
        if i == 1 || i == p || mod(i, max(1, round(p/40))) == 0
            notify_progress(cfg.progressFcn, 0.58 + 0.14*i/p, ...
                sprintf('Coarse 1D grid %d/%d | best %.4f s', i, p, best_seed.J));
        end
    end

    if use_waitbar
        close(h);
    end

    opt.samples_x = samples_x;
    opt.samples_J = samples_J;
    opt.samples_phase = repmat("grid_1d", size(samples_J));
    opt.grid.x1 = x1;
    opt.grid.J = samples_J;
    opt.method = 'grid_1d';

    fprintf('Best coarse lap-time: %.6f s\n', best_seed.J);
    fprintf('=======================================================================\n');
end

%% =========================================================
% LOCAL FUNCTION: coarse grid search
% =========================================================

function [opt, best_seed] = coarse_grid_search(sim, cfg, lb, ub, opt)

    p = cfg.optim.precision;
    x1 = linspace(lb(1), ub(1), p);
    x2 = linspace(lb(2), ub(2), p);

    Jgrid = inf(p,p);
    samples_x = zeros(p*p, 2);
    samples_J = inf(p*p, 1);

    best_seed.x = [NaN NaN];
    best_seed.J = inf;

    fprintf('\nCOARSE GRID SEARCH\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('Grid: %d x %d = %d simulations\n', p, p, p*p);

    use_waitbar = cfg.optim.waitbar;
    if use_waitbar
        h = waitbar(0, 'Starting coarse grid search...');
    end

    count = 0;

    for j = 1:p
        for i = 1:p
            count = count + 1;
            x = [x1(i) x2(j)];
            poll_abort(cfg.progressFcn);
            J = objective_lap_time(x, sim);

            Jgrid(j,i) = J;
            samples_x(count,:) = x;
            samples_J(count) = J;

            if J < best_seed.J
                best_seed.x = x;
                best_seed.J = J;
            end

            if use_waitbar
                waitbar(count/(p*p), h, sprintf('Coarse grid: %d%%', round(100*count/(p*p))));
            end
            if count == 1 || count == p*p || mod(count, max(1, round((p*p)/40))) == 0
                notify_progress(cfg.progressFcn, 0.58 + 0.14*count/(p*p), ...
                    sprintf('Coarse grid %d/%d | best %.4f s', count, p*p, best_seed.J));
            end
        end
    end

    if use_waitbar
        close(h);
    end

    opt.samples_x = samples_x;
    opt.samples_J = samples_J;
    opt.grid.x1 = x1;
    opt.grid.x2 = x2;
    opt.grid.J = Jgrid;

    fprintf('Best coarse lap-time: %.6f s\n', best_seed.J);
    fprintf('=======================================================================\n');
end

%% =========================================================
% LOCAL FUNCTION: coarse LHS search
% =========================================================

function [opt, best_seed] = coarse_project_global_search(sim, cfg, lb, ub, opt, stream)

    D = numel(lb);
    n0 = max(1, cfg.optim.random_samples);
    n_halton = ceil(0.65*n0);
    n_lhs = n0 - n_halton;

    Z = [halton_unit(n_halton, D, cfg.optim.halton_skip); ...
         lhs_unit(n_lhs, D, stream); ...
         0.5*ones(1,D); ...
         normalize_x(base_parameter_vector(sim), lb, ub); ...
         bound_probe_unit(D)];

    Z = unique_rows_unit(Z);
    X = denormalize_z(Z, lb, ub);

    fprintf('\nPROJECT GLOBAL SEARCH\n');
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('Initial samples: %d | Dimension: %d\n', size(X,1), D);
    fprintf('Sampler: Halton + Latin hypercube + baseline + bound probes\n');

    [J, best_seed] = evaluate_candidate_set(X, sim, cfg, 'global', 'Project global search');

    samples_x = X;
    samples_J = J;
    samples_phase = repmat("global", size(J));

    radius = cfg.optim.adaptive_radius;

    for round_id = 1:cfg.optim.adaptive_rounds
        valid = isfinite(samples_J);
        if ~any(valid)
            break
        end

        [~, idx_sort] = sort(samples_J, 'ascend');
        idx_sort = idx_sort(isfinite(samples_J(idx_sort)));

        n_elite = max(3, ceil(cfg.optim.adaptive_elite_fraction * numel(idx_sort)));
        n_elite = min(n_elite, numel(idx_sort));
        elite_idx = idx_sort(1:n_elite);

        Z_all = normalize_x(samples_x, lb, ub);
        Z_elite = Z_all(elite_idx,:);

        n_round = cfg.optim.adaptive_samples;
        Z_new = zeros(n_round, D);

        for k = 1:n_round
            e = Z_elite(1 + mod(k-1,n_elite),:);

            if rand(stream) < 0.60
                z = e + radius * (2*rand(stream, 1, D)-1);
            else
                z = e + 0.50 * radius * randn(stream, 1, D);
            end

            Z_new(k,:) = min(max(z, 0), 1);
        end

        z_best = Z_all(idx_sort(1),:);
        Z_axis = axis_zoom_probe_unit(z_best, radius, D);
        Z_new = unique_rows_unit([Z_new; Z_axis]);
        X_new = denormalize_z(Z_new, lb, ub);

        label = sprintf('Elite zoom round %d/%d', round_id, cfg.optim.adaptive_rounds);
        fprintf('Adaptive round %d: %d samples | radius %.4f\n', round_id, size(X_new,1), radius);

        [J_new, round_best] = evaluate_candidate_set(X_new, sim, cfg, ...
            sprintf('zoom_%d', round_id), label);

        samples_x = [samples_x; X_new]; %#ok<AGROW>
        samples_J = [samples_J; J_new]; %#ok<AGROW>
        samples_phase = [samples_phase; repmat(string(sprintf('zoom_%d', round_id)), size(J_new))]; %#ok<AGROW>

        if round_best.J < best_seed.J
            best_seed = round_best;
        end

        radius = radius * cfg.optim.adaptive_radius_decay;
    end

    opt.samples_x = samples_x;
    opt.samples_J = samples_J;
    opt.samples_phase = samples_phase;
    opt.method = 'halton_lhs_elite_zoom';

    fprintf('Best global lap-time: %.6f s\n', best_seed.J);
    fprintf('Total global samples: %d\n', numel(samples_J));
    fprintf('=======================================================================\n');
end

%% =========================================================
% LOCAL FUNCTION: evaluate candidate set
% =========================================================

function [J, best_seed] = evaluate_candidate_set(X, sim, cfg, phase, label)

    n = size(X,1);
    J = inf(n,1);
    best_seed.x = X(1,:);
    best_seed.J = inf;

    use_waitbar = cfg.optim.waitbar;
    if use_waitbar
        h = waitbar(0, sprintf('%s...', label));
        cleanup_h = onCleanup(@() safe_close_waitbar(h)); %#ok<NASGU>
    else
        h = [];
    end

    for i = 1:n
        poll_abort(cfg.progressFcn);
        J(i) = objective_lap_time(X(i,:), sim);

        if J(i) < best_seed.J
            best_seed.x = X(i,:);
            best_seed.J = J(i);
        end

        if cfg.optim.checkpoint_enabled && mod(i, cfg.optim.checkpoint_interval) == 0
            write_optimizer_checkpoint(X, J, i, phase, cfg);
        end

        if use_waitbar && ishandle(h)
            waitbar(i/n, h, sprintf('%s: %d%% | best %.3f s', ...
                label, round(100*i/n), best_seed.J));
            drawnow limitrate
        end
        if i == 1 || i == n || mod(i, max(1, round(n/40))) == 0
            [base, span] = progress_range_for_phase(phase);
            notify_progress(cfg.progressFcn, base + span*i/n, ...
                sprintf('%s %d/%d | best %.4f s', label, i, n, best_seed.J));
        end
    end

    if cfg.optim.checkpoint_enabled
        write_optimizer_checkpoint(X, J, n, phase, cfg);
    end

    if use_waitbar && ishandle(h)
        close(h);
    end
end

%% =========================================================
% LOCAL FUNCTION: progress range for optimizer phase
% =========================================================

function [base, span] = progress_range_for_phase(phase)

    phase = char(string(phase));
    if strcmp(phase, 'global')
        base = 0.58;
        span = 0.10;
    elseif startsWith(phase, 'zoom_')
        base = 0.68;
        span = 0.06;
    else
        base = 0.58;
        span = 0.12;
    end
end

%% =========================================================
% LOCAL FUNCTION: optimizer checkpoint
% =========================================================

function write_optimizer_checkpoint(X, J, last_index, phase, cfg)

    if ~exist(cfg.results_folder, 'dir')
        mkdir(cfg.results_folder);
    end

    checkpoint = struct;
    checkpoint.X = X;
    checkpoint.J = J;
    checkpoint.last_index = last_index;
    checkpoint.phase = phase;
    checkpoint.timestamp = datestr(now, 31);

    save(fullfile(cfg.results_folder, 'optimizer_checkpoint.mat'), 'checkpoint');
end

%% =========================================================
% LOCAL FUNCTION: latin hypercube in unit space
% =========================================================

function Z = lhs_unit(n, D, stream)

    if n <= 0
        Z = zeros(0,D);
        return
    end

    Z = zeros(n,D);

    for d = 1:D
        Z(:,d) = (randperm(stream, n)' - rand(stream, n, 1)) / n;
    end
end

%% =========================================================
% LOCAL FUNCTION: Halton sequence in unit space
% =========================================================

function Z = halton_unit(n, D, skip)

    if n <= 0
        Z = zeros(0,D);
        return
    end

    bases = first_primes_local(D);
    Z = zeros(n,D);

    for d = 1:D
        for i = 1:n
            Z(i,d) = radical_inverse(i + skip, bases(d));
        end
    end
end

%% =========================================================
% LOCAL FUNCTION: radical inverse
% =========================================================

function y = radical_inverse(index, base)

    y = 0;
    f = 1 / base;
    i = index;

    while i > 0
        y = y + f * mod(i, base);
        i = floor(i / base);
        f = f / base;
    end
end

%% =========================================================
% LOCAL FUNCTION: first primes
% =========================================================

function p = first_primes_local(D)

    p = zeros(1,D);
    n = 2;
    count = 0;

    while count < D
        is_p = true;
        for k = 2:floor(sqrt(n))
            if mod(n,k) == 0
                is_p = false;
                break
            end
        end

        if is_p
            count = count + 1;
            p(count) = n;
        end

        n = n + 1;
    end
end

%% =========================================================
% LOCAL FUNCTION: bound probes in unit space
% =========================================================

function Z = bound_probe_unit(D)

    Z = 0.5*ones(1,D);

    for d = 1:D
        z_low = 0.5*ones(1,D);
        z_high = 0.5*ones(1,D);
        z_low(d) = 0;
        z_high(d) = 1;
        Z = [Z; z_low; z_high]; %#ok<AGROW>
    end
end

%% =========================================================
% LOCAL FUNCTION: axis zoom probes
% =========================================================

function Z = axis_zoom_probe_unit(z_best, radius, D)

    Z = z_best;

    for d = 1:D
        z_low = z_best;
        z_high = z_best;
        z_low(d) = max(0, z_low(d) - radius);
        z_high(d) = min(1, z_high(d) + radius);
        Z = [Z; z_low; z_high]; %#ok<AGROW>
    end
end

%% =========================================================
% LOCAL FUNCTION: unique unit rows
% =========================================================

function Z = unique_rows_unit(Z)

    Z = min(max(Z, 0), 1);
    Zq = round(Z * 1e10) / 1e10;
    [~, idx] = unique(Zq, 'rows', 'stable');
    Z = Z(idx,:);
end

%% =========================================================
% LOCAL FUNCTION: baseline study vector
% =========================================================

function x0 = base_parameter_vector(sim)

    D = numel(sim.study);
    x0 = zeros(1,D);

    for d = 1:D
        id = sim.study(d).id;
        x0(d) = msfeup.get_study_parameter_value(id, sim.vehicle, sim.operating, mean(sim.study(d).range));
    end

    for d = 1:D
        x0(d) = min(max(x0(d), sim.study(d).range(1)), sim.study(d).range(2));
    end
end

%% =========================================================
% LOCAL FUNCTION: baseline evaluation
% =========================================================

function baseline = evaluate_baseline(sim)

    x0 = base_parameter_vector(sim);
    [lap_time, result] = msfeup.simulate_lap_case(x0, sim, true);

    baseline = struct;
    baseline.x = x0;
    baseline.lap_time = lap_time;
    baseline.result = result;
end

%% =========================================================
% LOCAL FUNCTION: objective
% =========================================================

function J = objective_lap_time(x, sim)

    try
        J = msfeup.simulate_lap_case(x, sim, false);
    catch ME
        if isfield(sim, 'cfg') && isfield(sim.cfg, 'optim') && isfield(sim.cfg.optim, 'debug_objective') ...
                && sim.cfg.optim.debug_objective
            warning('MSFEUP:ObjectiveFailure', 'Objective evaluation failed: %s', ME.message);
        end
        J = inf;
    end

    if ~isfinite(J)
        J = inf;
    end
end

%% =========================================================
% LOCAL FUNCTION: bounded pattern search
% =========================================================

function [x_best, J_best, trace] = local_pattern_search(x0, lb, ub, sim, cfg, progress)

    if nargin < 6 || isempty(progress)
        progress = struct;
        progress.enabled = false;
    end

    D = numel(x0);

    z_best = normalize_x(x0, lb, ub);
    z_best = min(max(z_best, 0), 1);
    x_best = denormalize_z(z_best, lb, ub);
    J_best = objective_lap_time(x_best, sim);

    step = cfg.optim.local_initial_step;
    eval_count = 1;
    trace = zeros(cfg.optim.local_max_eval, D + 2);
    trace(eval_count,:) = [eval_count J_best x_best];

    update_refinement_waitbar(progress, eval_count, cfg.optim.local_max_eval, J_best);

    while step > cfg.optim.local_tol_step && eval_count < cfg.optim.local_max_eval
        improved = false;

        for d = 1:D
            for direction = [-1 1]
                z_try = z_best;
                z_try(d) = z_try(d) + direction*step;
                z_try = min(max(z_try, 0), 1);

                x_try = denormalize_z(z_try, lb, ub);
                poll_abort(cfg.progressFcn);
                J_try = objective_lap_time(x_try, sim);

                eval_count = eval_count + 1;
                trace(eval_count,:) = [eval_count J_try x_try];

                if J_try < J_best
                    z_best = z_try;
                    x_best = x_try;
                    J_best = J_try;
                    improved = true;
                end

                update_refinement_waitbar(progress, eval_count, cfg.optim.local_max_eval, J_best);

                if eval_count >= cfg.optim.local_max_eval
                    break
                end
            end

            if eval_count >= cfg.optim.local_max_eval
                break
            end
        end

        if ~improved
            step = step * cfg.optim.local_step_reduction;
        end
    end

    trace = trace(1:eval_count,:);
end

%% =========================================================
% LOCAL FUNCTION: refinement waitbar update
% =========================================================

function update_refinement_waitbar(progress, eval_count, max_eval, J_best)

    if ~isfield(progress, 'enabled') || ~progress.enabled
        return
    end

    if ~isfield(progress, 'handle') || isempty(progress.handle) || ~ishandle(progress.handle)
        return
    end

    if eval_count ~= 1 && mod(eval_count, 4) ~= 0 && eval_count < max_eval
        return
    end

    local_fraction = min(eval_count / max_eval, 1);
    global_fraction = progress.base + progress.pattern_span * local_fraction;
    global_fraction = min(max(global_fraction, 0), 1);

    waitbar(global_fraction, progress.handle, sprintf( ...
        'Local refinement %d/%d | pattern %d/%d | %.4f s', ...
        progress.start_index, progress.n_start, eval_count, max_eval, J_best));
    drawnow limitrate
end

%% =========================================================
% LOCAL FUNCTION: safe waitbar close
% =========================================================

function safe_close_waitbar(h)

    if ~isempty(h) && ishandle(h)
        close(h);
    end
end

%% =========================================================
% LOCAL FUNCTION: simplex refinement
% =========================================================

function [x_best, J_best] = local_simplex_refinement(x0, lb, ub, sim, cfg)

    z0 = normalize_x(x0, lb, ub);
    z0 = min(max(z0, 0), 1);

    options = optimset('Display','off',...
        'MaxFunEvals',cfg.optim.simplex_max_eval,...
        'MaxIter',cfg.optim.simplex_max_eval,...
        'TolX',1e-5,...
        'TolFun',1e-5);

    [z_best, J_best] = fminsearch(@(z) bounded_simplex_objective(z, lb, ub, sim), z0, options);

    z_best = min(max(z_best, 0), 1);
    x_best = denormalize_z(z_best, lb, ub);
    J_best = objective_lap_time(x_best, sim);
end

%% =========================================================
% LOCAL FUNCTION: bounded simplex objective
% =========================================================

function J = bounded_simplex_objective(z, lb, ub, sim)

    z = z(:)';

    penalty = 1e5 * sum(max(0, -z).^2 + max(0, z - 1).^2);
    z = min(max(z, 0), 1);

    x = denormalize_z(z, lb, ub);
    J = objective_lap_time(x, sim) + penalty;
end

%% =========================================================
% LOCAL FUNCTION: normalize
% =========================================================

function z = normalize_x(x, lb, ub)
    z = (x - lb) ./ (ub - lb);
end

%% =========================================================
% LOCAL FUNCTION: denormalize
% =========================================================

function x = denormalize_z(z, lb, ub)
    x = lb + z .* (ub - lb);
end

%% =========================================================
% LOCAL FUNCTION: apply study parameters
% =========================================================
