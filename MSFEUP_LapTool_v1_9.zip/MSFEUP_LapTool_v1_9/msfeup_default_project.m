function project = msfeup_default_project()
%MSFEUP_DEFAULT_PROJECT  Default MSFEUP lap-simulation project structure.

    if isdeployed
        root = ctfroot;
        output_root = fullfile(prefdir, 'MSFEUP_LapTool');
    else
        root = fileparts(mfilename('fullpath'));
        output_root = root;
    end

    project = struct;
    project.name = 'MSFEUP Motorcycle Lap Simulation';
    project.version = '1.9';
    project.root = root;

    project.files = struct;
    project.files.track = fullfile(root, 'MSFEUP_track_input.mat');
    % Legacy source files are retained for automatic rebuilding of the combined track MAT.
    project.files.data = fullfile(root, 'data.mat');
    project.files.theta = fullfile(root, 'Theta.mat');
    project.files.radius = fullfile(root, 'radius.mat');
    project.files.power = fullfile(root, 'MSFEUP_power_curve.mat');

    project.assets = struct;
    project.assets.logo_header = fullfile(root, 'assets', 'logo_header.png');
    project.assets.logo_report = fullfile(root, 'assets', 'logo_report.png');

    project.outputs = struct;
    project.outputs.figures = fullfile(output_root, 'outputs', 'figures');
    project.outputs.results = fullfile(output_root, 'outputs', 'results');
    project.outputs.export_level = 'light';
    project.outputs.auto_export = false;
    project.outputs.write_summary = false;
    project.outputs.export_velocity_profile = false;
    project.outputs.export_force_profile = true;
    project.outputs.export_figures = false;
    project.outputs.write_csv = false;
    project.outputs.write_archive = false;
    project.outputs.write_diagnostics_files = false;

    project.vehicle = struct;
    project.vehicle.g       = 9.81;
    project.vehicle.rho     = 1.164;
    project.vehicle.mass    = 220;
    project.vehicle.wb      = 1.3;
    project.vehicle.cgx     = 0.600;
    project.vehicle.cgh     = 0.500;
    project.vehicle.r_wheel = 0.3;
    project.vehicle.frontA  = 0.47;
    project.vehicle.Cd      = 0.4;
    project.vehicle.Cl      = -0.05;
    project.vehicle.mu      = 0.95;
    project.vehicle.fW      = 0.015;
    project.vehicle.eta     = 1;
    project.vehicle.maxrpm  = 7000;

    project.operating = struct;
    project.operating.gear_ratio = 4.0;

    project.track = struct;
    project.track.ds = 0.5;
    project.track.smooth_len_xy = 10;
    project.track.curv_half_len = 15;
    project.track.smooth_len_k = 10;
    project.track.straight_radius_threshold = 2000;
    project.track.curve_limit_mode = 'Radius threshold [m]';
    project.track.curve_limit_value = 2000;
    project.track.max_closure_warning_m = 30;

    project.sim = struct;
    project.sim.v_max_global = 300/3.6;
    project.sim.nIter = 70;
    project.sim.tol = 1e-4;

    project.energy = struct;
    project.energy.n_laps = 6;
    project.energy.safety_coeff = 1.25;
    project.energy.usable_fraction = 0.8;
    project.energy.eta_regen = 0.0;
    project.energy.plot_capacity_kWh = 6.5;

    project.analysis = struct;
    project.analysis.corner_kappa_threshold = 1/2000;
    project.analysis.min_section_length = 10;

    project.sensitivity = struct;
    project.sensitivity.points_per_variable = 80;
    project.sensitivity.include_bounds = true;

    project.optim = struct;
    project.optim.grid_1d_points = 80;
    project.optim.precision = 36;
    project.optim.use_grid_if_2d = true;
    project.optim.random_samples = 1800;
    project.optim.top_starts = 12;
    project.optim.local_initial_step = 0.18;
    project.optim.local_step_reduction = 0.52;
    project.optim.local_tol_step = 2.5e-4;
    project.optim.local_max_eval = 260;
    project.optim.simplex_enabled = true;
    project.optim.simplex_max_eval = 180;
    project.optim.rng_seed = 7;
    project.optim.waitbar = false;
    project.optim.adaptive_rounds = 3;
    project.optim.adaptive_samples = 560;
    project.optim.adaptive_elite_fraction = 0.08;
    project.optim.adaptive_radius = 0.22;
    project.optim.adaptive_radius_decay = 0.55;
    project.optim.halton_skip = 120;
    project.optim.checkpoint_enabled = false;
    project.optim.checkpoint_interval = 250;

    project.visual = struct;
    project.visual.font_name = 'Cambria';
    project.visual.plot_font_name = 'Times';
    project.visual.primary_green = [0 154 0] / 255;

    project.study = msfeup_empty_study();
    project.study(1)  = make_registered_study('gear_ratio', [3.0 4.2]);
    project.study(2)  = make_registered_study('mass',       [170 270]);
    project.study(3)  = make_registered_study('mu',         [0.85 1.10]);
    project.study(4)  = make_registered_study('Cd',         [0.32 0.64]);
    project.study(5)  = make_registered_study('Cl',         [-0.255 0.02]);
    project.study(6)  = make_registered_study('cgx',        [0.455 0.663]);
    project.study(7)  = make_registered_study('cgh',        [0.390 0.520]);
    project.study(8)  = make_registered_study('eta',        [0.85 1.00]);
    project.study(9)  = make_registered_study('frontA',     [0.35 0.60]);
    project.study(10) = make_registered_study('r_wheel',    [0.28 0.32]);
    project.study(11) = make_registered_study('wb',         [1.20 1.40]);
    project.study(12) = make_registered_study('maxrpm',     [6000 8000]);
    project.study(13) = make_registered_study('rho',        [1.10 1.25]);
    project.study(14) = make_registered_study('fW',         [0.010 0.030]);
end

function study = make_registered_study(id, range)

    info = msfeup.study_parameter_registry(id);
    if ~info.known
        error('Default study id is not registered: %s.', char(string(id)));
    end
    study = msfeup_make_study(info.id, info.name, info.symbol, info.unit, range);
end
