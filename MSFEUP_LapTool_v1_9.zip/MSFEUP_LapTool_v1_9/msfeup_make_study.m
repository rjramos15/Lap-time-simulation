function st = msfeup_make_study(id, name, symbol, unit, range)
%MSFEUP_MAKE_STUDY  Create a parametric/optimization study definition.

    st = struct;
    st.id = char(id);
    st.name = char(name);
    st.symbol = char(symbol);
    st.unit = char(unit);
    st.range = range(:)';

    if numel(st.range) ~= 2 || any(~isfinite(st.range)) || st.range(2) <= st.range(1)
        error('Invalid range for study parameter %s.', st.id);
    end
end
