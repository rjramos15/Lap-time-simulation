function msfeup_build_track_input_mat(output_file, data_file, theta_file, radius_file)
%MSFEUP_BUILD_TRACK_INPUT_MAT Combine legacy track inputs into one MAT file.
%
% The combined MAT stores the three variables expected by the simulator:
%   M         - GPS table/struct, including LATITUDE and LONGITUDE
%   thetadata - longitudinal slope data, including xPosition_m_ and Theta_rad_
%   teste     - legacy radius data, including distance and rad
%
% This function does not change the physical model. It only consolidates file
% loading so the UI needs one track-input path instead of three.

    if nargin < 4
        error('Usage: msfeup_build_track_input_mat(output_file, data_file, theta_file, radius_file)');
    end

    if ~isfile(data_file)
        error('Missing legacy data file: %s', data_file);
    end
    if ~isfile(theta_file)
        error('Missing legacy theta file: %s', theta_file);
    end
    if ~isfile(radius_file)
        error('Missing legacy radius file: %s', radius_file);
    end

    rawData = load(data_file);
    rawTheta = load(theta_file);
    rawRadius = load(radius_file);

    M = local_fetch_required_field(rawData, 'M', data_file);
    thetadata = local_fetch_required_field(rawTheta, 'thetadata', theta_file);
    teste = local_fetch_required_field(rawRadius, 'teste', radius_file);

    [folder,~,~] = fileparts(output_file);
    if ~isempty(folder) && ~exist(folder, 'dir')
        mkdir(folder);
    end

    source_files = struct;
    source_files.data = data_file;
    source_files.theta = theta_file;
    source_files.radius = radius_file;
    created_on = datestr(now, 30); %#ok<NASGU>

    save(output_file, 'M', 'thetadata', 'teste', 'source_files', 'created_on', '-v7.3');
    fprintf(' - Combined track input MAT created: %s\n', output_file);
end

function value = local_fetch_required_field(payload, preferred_name, file_name)

    if isfield(payload, preferred_name)
        value = payload.(preferred_name);
        return
    end

    fn = fieldnames(payload);
    if numel(fn) == 1
        value = payload.(fn{1});
        warning('Expected variable %s in %s. Using only variable found: %s.', ...
            preferred_name, file_name, fn{1});
        return
    end

    error('Could not find variable %s in file %s.', preferred_name, file_name);
end
