function project = msfeup_load_project(file_name)
%MSFEUP_LOAD_PROJECT  Load project configuration from MAT file.

    if nargin < 1 || isempty(file_name)
        [f, p] = uigetfile('*.mat', 'Load MSFEUP project');
        if isequal(f,0)
            project = [];
            return
        end
        file_name = fullfile(p, f);
    end

    raw = load(file_name, 'project');
    if ~isfield(raw, 'project')
        error('The selected file does not contain a variable named project.');
    end
    project = raw.project;
end
